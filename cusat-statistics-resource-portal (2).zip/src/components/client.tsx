"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useState, type FormEvent, type ReactNode } from "react";
import { cn } from "@/lib/utils";

type ApiFormProps = {
  action: string;
  method?: string;
  children: ReactNode;
  className?: string;
  resetOnSuccess?: boolean;
  successMessage?: string;
  redirectTo?: string;
  confirmMessage?: string;
};

/** A form that submits FormData to a route handler with fetch and refreshes the page. */
export function ApiForm({
  action,
  method = "POST",
  children,
  className,
  resetOnSuccess = false,
  successMessage = "Saved.",
  redirectTo,
  confirmMessage,
}: ApiFormProps) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);

  async function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (confirmMessage && !window.confirm(confirmMessage)) return;
    const form = e.currentTarget;
    const body = new FormData(form);
    setBusy(true);
    setMsg(null);
    try {
      const res = await fetch(action, { method, body, credentials: "same-origin" });
      const data = (await res.json().catch(() => ({}))) as { error?: string; message?: string };
      if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
      if (resetOnSuccess) form.reset();
      setMsg({ ok: true, text: data.message || successMessage });
      if (redirectTo) router.push(redirectTo);
      router.refresh();
    } catch (err) {
      setMsg({ ok: false, text: err instanceof Error ? err.message : "Something went wrong." });
    } finally {
      setBusy(false);
    }
  }

  return (
    <form onSubmit={onSubmit} className={className} aria-busy={busy}>
      <fieldset disabled={busy} className="contents">
        {children}
      </fieldset>
      {msg && (
        <p role="status" className={cn("col-span-full text-sm font-medium", msg.ok ? "text-emerald-600" : "text-rose-600")}>
          {msg.text}
        </p>
      )}
    </form>
  );
}

type ApiButtonProps = {
  endpoint: string;
  method?: string;
  confirmMessage?: string;
  children: ReactNode;
  className?: string;
  redirectTo?: string;
  title?: string;
};

/** A button that calls a route handler (e.g. DELETE) then refreshes the page. */
export function ApiButton({ endpoint, method = "POST", confirmMessage, children, className, redirectTo, title }: ApiButtonProps) {
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  return (
    <button
      type="button"
      title={title}
      aria-label={title}
      disabled={busy}
      className={className}
      onClick={async () => {
        if (confirmMessage && !window.confirm(confirmMessage)) return;
        setBusy(true);
        try {
          const res = await fetch(endpoint, { method, credentials: "same-origin" });
          const data = (await res.json().catch(() => ({}))) as { error?: string };
          if (!res.ok) {
            window.alert(data.error || `Request failed (${res.status})`);
            return;
          }
          if (redirectTo) router.push(redirectTo);
          router.refresh();
        } finally {
          setBusy(false);
        }
      }}
    >
      {children}
    </button>
  );
}

export function AdminNav({ links }: { links: Array<{ href: string; label: string }> }) {
  const pathname = usePathname();
  return (
    <nav className="flex gap-1 overflow-x-auto rounded-xl bg-white p-1 ring-1 ring-slate-200">
      {links.map((l) => {
        const active = l.href === "/admin" ? pathname === "/admin" : pathname.startsWith(l.href);
        return (
          <Link
            key={l.href}
            href={l.href}
            className={cn(
              "shrink-0 rounded-lg px-3 py-1.5 text-sm font-medium transition",
              active ? "bg-indigo-600 text-white shadow-sm" : "text-slate-600 hover:bg-slate-100",
            )}
          >
            {l.label}
          </Link>
        );
      })}
    </nav>
  );
}
