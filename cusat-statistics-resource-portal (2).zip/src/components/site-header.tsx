import Link from "next/link";
import { GraduationCap, Lock, Search, ShieldCheck } from "lucide-react";
import { SITE } from "@/lib/site";
import { cn } from "@/lib/utils";

const navLink = "shrink-0 rounded-lg px-3 py-2 text-sm font-medium text-slate-600 transition hover:bg-slate-100 hover:text-slate-900";

export function SiteHeader({ programs, admin }: { programs: Array<{ slug: string; name: string; shortName: string }>; admin: boolean }) {
  return (
    <header className="sticky top-0 z-40 border-b border-slate-200/80 bg-white/85 backdrop-blur">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-3 px-4 sm:px-6">
        <Link href="/" className="flex shrink-0 items-center gap-2.5">
          <span className="inline-flex h-9 w-9 items-center justify-center rounded-xl bg-linear-to-br from-indigo-500 to-violet-600 text-white shadow-sm">
            <GraduationCap className="h-5 w-5" aria-hidden />
          </span>
          <span className="leading-tight">
            <span className="block text-base font-bold text-slate-900">{SITE.name}</span>
            <span className="block text-[11px] font-medium text-slate-500">{SITE.institutionShort} · Statistics</span>
          </span>
        </Link>

        <nav className="ml-4 hidden items-center gap-0.5 md:flex">
          {programs.map((p) => (
            <Link key={p.slug} href={`/p/${p.slug}`} className={navLink}>
              <span className="xl:hidden">{p.shortName || p.name}</span>
              <span className="hidden xl:inline">{p.name}</span>
            </Link>
          ))}
          <Link href="/browse" className={navLink}>
            Browse
          </Link>
          <Link href="/timetable" className={navLink}>
            Timetables
          </Link>
        </nav>

        <form action="/browse" className="ml-auto hidden lg:block" role="search">
          <label className="relative block">
            <span className="sr-only">Search study material</span>
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden />
            <input
              name="q"
              placeholder="Search notes, PYQs, papers..."
              className="w-56 rounded-xl border-0 bg-slate-100 py-2 pl-9 pr-3 text-sm text-slate-900 placeholder:text-slate-400 focus:bg-white focus:outline-none focus:ring-2 focus:ring-indigo-500 xl:w-64"
            />
          </label>
        </form>

        <Link
          href="/admin"
          className={cn(
            "btn btn-sm ml-auto lg:ml-0",
            admin ? "bg-emerald-50 text-emerald-700 ring-1 ring-inset ring-emerald-200 hover:bg-emerald-100" : "btn-secondary",
          )}
        >
          {admin ? <ShieldCheck className="h-4 w-4" aria-hidden /> : <Lock className="h-4 w-4" aria-hidden />}
          {admin ? "Admin" : "Admin login"}
        </Link>
      </div>

      <nav className="flex gap-1 overflow-x-auto border-t border-slate-100 px-3 py-1.5 md:hidden">
        {programs.map((p) => (
          <Link key={p.slug} href={`/p/${p.slug}`} className={navLink}>
            {p.name}
          </Link>
        ))}
        <Link href="/browse" className={navLink}>
          Browse
        </Link>
        <Link href="/timetable" className={navLink}>
          Timetables
        </Link>
      </nav>
    </header>
  );
}
