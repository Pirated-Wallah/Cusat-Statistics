import Link from "next/link";
import type { ReactNode } from "react";
import {
  BookOpen,
  CalendarDays,
  ChevronRight,
  ClipboardCheck,
  FileText,
  FolderOpen,
  History,
  ListChecks,
  type LucideIcon,
} from "lucide-react";
import { SUBJECT_KINDS, TYPE_META, type ResourceType } from "@/lib/site";
import { cn } from "@/lib/utils";

export const TYPE_ICONS: Record<ResourceType, LucideIcon> = {
  notes: FileText,
  pyq: History,
  internal: ClipboardCheck,
  textbook: BookOpen,
  syllabus: ListChecks,
  timetable: CalendarDays,
};

export function TypeIcon({ type, size = "md", className }: { type: ResourceType; size?: "sm" | "md" | "lg"; className?: string }) {
  const Icon = TYPE_ICONS[type];
  const box = size === "sm" ? "h-8 w-8 rounded-lg" : size === "lg" ? "h-12 w-12 rounded-2xl" : "h-10 w-10 rounded-xl";
  const icon = size === "sm" ? "h-4 w-4" : size === "lg" ? "h-6 w-6" : "h-5 w-5";
  return (
    <span className={cn("inline-flex shrink-0 items-center justify-center", box, TYPE_META[type].iconWrap, className)}>
      <Icon className={icon} aria-hidden />
    </span>
  );
}

export function Badge({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 whitespace-nowrap rounded-full px-2 py-0.5 text-[11px] font-medium ring-1 ring-inset",
        className ?? "bg-slate-50 text-slate-600 ring-slate-500/20",
      )}
    >
      {children}
    </span>
  );
}

export function KindBadge({ kind }: { kind: string }) {
  const k = SUBJECT_KINDS[kind] ?? SUBJECT_KINDS.core;
  return <Badge className={k.badge}>{k.label}</Badge>;
}

export function InSessionBadge() {
  return (
    <Badge className="bg-emerald-50 text-emerald-700 ring-emerald-600/20">
      <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" aria-hidden />
      In session
    </Badge>
  );
}

export function EmptyState({ icon: Icon = FolderOpen, title, children }: { icon?: LucideIcon; title: string; children?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-slate-300 bg-white/60 px-6 py-12 text-center">
      <span className="mb-3 inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-slate-100 text-slate-400">
        <Icon className="h-6 w-6" aria-hidden />
      </span>
      <p className="font-semibold text-slate-700">{title}</p>
      {children ? <div className="mt-1 max-w-md text-sm text-slate-500">{children}</div> : null}
    </div>
  );
}

export function Breadcrumbs({ items }: { items: Array<{ label: string; href?: string }> }) {
  return (
    <nav aria-label="Breadcrumb" className="flex flex-wrap items-center gap-1 text-sm text-slate-500">
      {items.map((item, i) => (
        <span key={`${item.label}-${i}`} className="inline-flex items-center gap-1">
          {i > 0 && <ChevronRight className="h-3.5 w-3.5 text-slate-400" aria-hidden />}
          {item.href ? (
            <Link href={item.href} className="hover:text-indigo-600">
              {item.label}
            </Link>
          ) : (
            <span className="font-medium text-slate-700">{item.label}</span>
          )}
        </span>
      ))}
    </nav>
  );
}

/** Horizontal pill navigation (semester switcher etc.). */
export function PillNav({
  items,
}: {
  items: Array<{ href: string; label: string; active?: boolean; hint?: string; activeClass?: string }>;
}) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1">
      {items.map((it) => (
        <Link
          key={it.href}
          href={it.href}
          className={cn(
            "shrink-0 rounded-full px-4 py-1.5 text-sm font-semibold transition",
            it.active ? cn("text-white shadow-sm", it.activeClass ?? "bg-slate-900") : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50",
          )}
        >
          {it.label}
          {it.hint ? <span className={cn("ml-1.5 text-[11px] font-medium", it.active ? "text-white/80" : "text-slate-400")}>{it.hint}</span> : null}
        </Link>
      ))}
    </div>
  );
}

export function SectionHeading({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="mb-5 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h2 className="text-xl font-bold tracking-tight text-slate-900 sm:text-2xl">{title}</h2>
        {subtitle ? <p className="mt-1 text-sm text-slate-500">{subtitle}</p> : null}
      </div>
      {action}
    </div>
  );
}

/** Splits "Semester 1 - Foundations" into its subtitle part. */
export function semesterSubtitle(title: string) {
  const idx = title.indexOf(" - ");
  return idx >= 0 ? title.slice(idx + 3) : title;
}
