"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useRef, useState, type DragEvent, type FormEvent } from "react";
import { CircleAlert, CircleCheck, FileText, Upload, X } from "lucide-react";
import { RESOURCE_TYPES, TYPE_META, type ResourceType } from "@/lib/site";
import { cn, formatBytes } from "@/lib/utils";

type Sem = { id: number; label: string; group: string };
type Sub = { id: number; semesterId: number; code: string; name: string; kind: string };
type Mode = "file" | "link" | "none";

const ACCEPT = ".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt,.png,.jpg,.jpeg,.webp,.zip";

export function UploadForm({
  semesters,
  subjects,
  defaults,
  maxMb,
}: {
  semesters: Sem[];
  subjects: Sub[];
  defaults?: { type?: ResourceType; semesterId?: number; subjectId?: number };
  maxMb: number;
}) {
  const router = useRouter();
  const [type, setType] = useState<ResourceType>(defaults?.type ?? "notes");
  const [semesterId, setSemesterId] = useState<number>(defaults?.semesterId ?? semesters[0]?.id ?? 0);
  const [subjectId, setSubjectId] = useState<string>(defaults?.subjectId ? String(defaults.subjectId) : "");
  const [mode, setMode] = useState<Mode>("file");
  const [file, setFile] = useState<File | null>(null);
  const [dragging, setDragging] = useState(false);
  const [progress, setProgress] = useState<number | null>(null);
  const [result, setResult] = useState<{ ok: boolean; text: string; id?: number } | null>(null);
  const formRef = useRef<HTMLFormElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const semSubjects = subjects.filter((s) => s.semesterId === semesterId);
  const needsSubject = type !== "syllabus" && type !== "timetable";
  const effectiveMode: Mode = mode === "none" && type !== "textbook" ? "file" : mode;
  const year = new Date().getFullYear();
  const modes: Array<{ value: Mode; label: string }> = [
    { value: "file", label: "Upload file" },
    { value: "link", label: "Paste link" },
    ...(type === "textbook" ? [{ value: "none" as Mode, label: "No PDF yet" }] : []),
  ];

  function pickFile(f: File | null | undefined) {
    if (!f) return;
    if (f.size > maxMb * 1024 * 1024) {
      setResult({ ok: false, text: `"${f.name}" is larger than ${maxMb} MB.` });
      return;
    }
    setFile(f);
    setResult(null);
  }

  function clearFile() {
    setFile(null);
    if (inputRef.current) inputRef.current.value = "";
  }

  function onDrop(e: DragEvent<HTMLLabelElement>) {
    e.preventDefault();
    setDragging(false);
    pickFile(e.dataTransfer.files?.[0]);
  }

  function onSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (needsSubject && !subjectId) {
      setResult({ ok: false, text: "Select the paper this material belongs to." });
      return;
    }
    if (effectiveMode === "file" && !file) {
      setResult({ ok: false, text: "Choose a file to upload (or switch to 'Paste link')." });
      return;
    }
    const fd = new FormData(e.currentTarget);
    fd.set("type", type);
    fd.set("semesterId", String(semesterId));
    fd.set("subjectId", subjectId);
    fd.set("mode", effectiveMode);
    if (effectiveMode === "file" && file) fd.set("file", file);

    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/admin/resources");
    xhr.upload.onprogress = (ev) => {
      if (ev.lengthComputable) setProgress(Math.round((ev.loaded / ev.total) * 100));
    };
    xhr.onload = () => {
      setProgress(null);
      let data: { id?: number; error?: string } = {};
      try {
        data = JSON.parse(xhr.responseText);
      } catch {
        /* ignore */
      }
      if (xhr.status >= 200 && xhr.status < 300) {
        setResult({ ok: true, text: "Uploaded successfully!", id: data.id });
        formRef.current?.reset();
        clearFile();
        router.refresh();
      } else {
        setResult({ ok: false, text: data.error || `Upload failed (${xhr.status}).` });
      }
    };
    xhr.onerror = () => {
      setProgress(null);
      setResult({ ok: false, text: "Network error - please try again." });
    };
    setResult(null);
    setProgress(0);
    xhr.send(fd);
  }

  return (
    <form ref={formRef} onSubmit={onSubmit} className="space-y-5">
      <div>
        <span className="label">What are you uploading?</span>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
          {RESOURCE_TYPES.map((t) => (
            <button
              type="button"
              key={t}
              onClick={() => setType(t)}
              className={cn(
                "rounded-xl border px-3 py-2.5 text-left text-sm transition",
                type === t ? "border-indigo-500 bg-indigo-50 ring-2 ring-indigo-500/20" : "border-slate-200 bg-white hover:border-slate-300",
              )}
            >
              <span className="block font-semibold text-slate-900">{TYPE_META[t].plural}</span>
              <span className="line-clamp-1 block text-xs text-slate-500">{TYPE_META[t].description}</span>
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <label className="block">
          <span className="label">Semester</span>
          <select
            className="input"
            value={semesterId}
            onChange={(e) => {
              setSemesterId(Number(e.target.value));
              setSubjectId("");
            }}
          >
            {Array.from(new Set(semesters.map((s) => s.group))).map((group) => (
              <optgroup key={group} label={group}>
                {semesters
                  .filter((s) => s.group === group)
                  .map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.label}
                    </option>
                  ))}
              </optgroup>
            ))}
          </select>
        </label>
        <label className="block">
          <span className="label">Paper {needsSubject ? "" : "(optional)"}</span>
          <select className="input" value={subjectId} onChange={(e) => setSubjectId(e.target.value)}>
            <option value="">{needsSubject ? "Select a paper..." : "Whole semester"}</option>
            {semSubjects.map((s) => (
              <option key={s.id} value={s.id}>
                {s.code} - {s.name}
              </option>
            ))}
          </select>
        </label>
      </div>

      {type === "notes" && (
        <label className="block sm:max-w-xs">
          <span className="label">Module (optional)</span>
          <select name="unitNo" className="input" defaultValue="">
            <option value="">All modules / general</option>
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <option key={n} value={n}>
                Module {n}
              </option>
            ))}
          </select>
        </label>
      )}

      {(type === "pyq" || type === "internal") && (
        <div className="grid gap-4 sm:grid-cols-2">
          <label className="block">
            <span className="label">Exam year</span>
            <input name="year" type="number" min={2000} max={2100} defaultValue={year} className="input" />
          </label>
          <label className="block">
            <span className="label">Exam</span>
            {type === "internal" ? (
              <select key="internal" name="examLabel" className="input" defaultValue="Internal Test I">
                <option>Internal Test I</option>
                <option>Internal Test II</option>
                <option>Model Exam</option>
                <option>Assignment</option>
              </select>
            ) : (
              <select key="pyq" name="examLabel" className="input" defaultValue="End Semester (Nov/Dec)">
                <option>End Semester (Nov/Dec)</option>
                <option>End Semester (Apr/May)</option>
                <option>Supplementary Exam</option>
                <option>Practical Exam (Nov/Dec)</option>
                <option>Practical Exam (Apr/May)</option>
              </select>
            )}
          </label>
        </div>
      )}

      {type === "textbook" && (
        <div className="grid gap-4 sm:grid-cols-3">
          <label className="block">
            <span className="label">Author(s)</span>
            <input name="author" className="input" placeholder="e.g. W.G. Cochran" />
          </label>
          <label className="block">
            <span className="label">Publisher</span>
            <input name="publisher" className="input" placeholder="e.g. Wiley" />
          </label>
          <label className="block">
            <span className="label">Edition</span>
            <input name="edition" className="input" placeholder="e.g. 3rd ed." />
          </label>
          <label className="flex items-center gap-2 text-sm text-slate-600 sm:col-span-3">
            <input type="checkbox" name="isOpenAccess" className="h-4 w-4 rounded border-slate-300 text-indigo-600" />
            This is a free / open-access book
          </label>
        </div>
      )}

      <div className="grid gap-4">
        <label className="block">
          <span className="label">{type === "textbook" ? "Book title" : "Title (optional)"}</span>
          <input
            name="title"
            className="input"
            required={type === "textbook"}
            maxLength={200}
            placeholder={type === "textbook" ? "e.g. Sampling Techniques" : "Leave blank to auto-generate (e.g. 'Probability Theory - I - Module II Notes')"}
          />
        </label>
        <label className="block">
          <span className="label">Description (optional)</span>
          <textarea name="description" rows={2} maxLength={500} className="input" placeholder="e.g. Handwritten notes by the class topper, covers all 4 modules" />
        </label>
      </div>

      <div>
        <span className="label">File</span>
        <div className="mb-3 inline-flex rounded-xl bg-slate-100 p-1 text-sm">
          {modes.map((m) => (
            <button
              type="button"
              key={m.value}
              onClick={() => setMode(m.value)}
              className={cn(
                "rounded-lg px-3 py-1.5 font-medium transition",
                effectiveMode === m.value ? "bg-white text-slate-900 shadow-sm" : "text-slate-500 hover:text-slate-700",
              )}
            >
              {m.label}
            </button>
          ))}
        </div>

        {effectiveMode === "file" && (
          <label
            onDragOver={(e) => {
              e.preventDefault();
              setDragging(true);
            }}
            onDragLeave={() => setDragging(false)}
            onDrop={onDrop}
            className={cn(
              "relative flex cursor-pointer flex-col items-center justify-center gap-2 rounded-2xl border-2 border-dashed px-6 py-8 text-center transition",
              dragging ? "border-indigo-500 bg-indigo-50" : "border-slate-300 bg-slate-50 hover:border-indigo-400 hover:bg-indigo-50/40",
            )}
          >
            <input ref={inputRef} type="file" className="sr-only" accept={ACCEPT} onChange={(e) => pickFile(e.target.files?.[0])} />
            {file ? (
              <>
                <FileText className="h-8 w-8 text-indigo-600" aria-hidden />
                <span className="max-w-full truncate font-semibold text-slate-800">{file.name}</span>
                <span className="text-xs text-slate-500">{formatBytes(file.size)} · click to choose a different file</span>
                <button
                  type="button"
                  onClick={(e) => {
                    e.preventDefault();
                    clearFile();
                  }}
                  className="absolute right-3 top-3 rounded-lg p-1 text-slate-400 hover:bg-white hover:text-slate-600"
                  aria-label="Remove file"
                >
                  <X className="h-4 w-4" />
                </button>
              </>
            ) : (
              <>
                <Upload className="h-8 w-8 text-indigo-500" aria-hidden />
                <span className="font-semibold text-slate-700">Drop a file here or click to browse</span>
                <span className="text-xs text-slate-500">PDF preferred · Word, PowerPoint, Excel, images and ZIP also work · max {maxMb} MB</span>
              </>
            )}
          </label>
        )}
        {effectiveMode === "link" && (
          <input name="url" type="url" required className="input" placeholder="https://drive.google.com/file/d/... or any PDF link" />
        )}
        {effectiveMode === "none" && (
          <p className="rounded-xl bg-slate-50 p-3 text-sm text-slate-600 ring-1 ring-inset ring-slate-200">
            The book will be listed as a recommended textbook. You can attach its PDF later from the book&apos;s page.
          </p>
        )}
      </div>

      {progress !== null && (
        <div>
          <div className="h-2 overflow-hidden rounded-full bg-slate-100">
            <div className="h-full rounded-full bg-indigo-600 transition-all" style={{ width: `${progress}%` }} />
          </div>
          <p className="mt-1 text-xs text-slate-500">{progress < 100 ? `Uploading... ${progress}%` : "Processing..."}</p>
        </div>
      )}

      {result && (
        <div className={cn("flex items-start gap-2 rounded-xl p-3 text-sm", result.ok ? "bg-emerald-50 text-emerald-800" : "bg-rose-50 text-rose-700")}>
          {result.ok ? <CircleCheck className="mt-0.5 h-4 w-4 shrink-0" /> : <CircleAlert className="mt-0.5 h-4 w-4 shrink-0" />}
          <span>
            {result.text}{" "}
            {result.ok && result.id ? (
              <Link href={`/view/${result.id}`} className="font-semibold underline">
                View it
              </Link>
            ) : null}
          </span>
        </div>
      )}

      <button type="submit" disabled={progress !== null} className="btn btn-primary w-full sm:w-auto">
        <Upload className="h-4 w-4" aria-hidden />
        {progress !== null ? "Uploading..." : "Publish material"}
      </button>
    </form>
  );
}
