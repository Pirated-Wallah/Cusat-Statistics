import { SUBJECT_KINDS } from "@/lib/site";

type PaperDefaults = {
  code?: string;
  name?: string;
  shortName?: string;
  kind?: string;
  credits?: number;
  faculty?: string;
  description?: string;
  sortOrder?: number;
};

export function PaperFields({ defaults = {}, withOrder = false }: { defaults?: PaperDefaults; withOrder?: boolean }) {
  return (
    <>
      <label className="block">
        <span className="label">Course code</span>
        <input name="code" required defaultValue={defaults.code} placeholder="e.g. 24-322-0101" className="input uppercase" />
      </label>
      <label className="block">
        <span className="label">Short name</span>
        <input name="shortName" defaultValue={defaults.shortName} placeholder="Shown in timetable, e.g. MMS" maxLength={20} className="input" />
      </label>
      <label className="block sm:col-span-2">
        <span className="label">Paper name</span>
        <input name="name" required defaultValue={defaults.name} placeholder="e.g. Mathematical Methods for Statistics" className="input" />
      </label>
      <label className="block">
        <span className="label">Type</span>
        <select name="kind" defaultValue={defaults.kind ?? "core"} className="input">
          {Object.entries(SUBJECT_KINDS).map(([k, v]) => (
            <option key={k} value={k}>
              {v.label}
            </option>
          ))}
        </select>
      </label>
      <label className="block">
        <span className="label">Credits</span>
        <input name="credits" type="number" min={0} max={20} defaultValue={defaults.credits ?? 4} className="input" />
      </label>
      <label className={withOrder ? "block" : "block sm:col-span-2"}>
        <span className="label">Faculty</span>
        <input name="faculty" defaultValue={defaults.faculty} placeholder="Teacher handling the paper" className="input" />
      </label>
      {withOrder && (
        <label className="block">
          <span className="label">Display order</span>
          <input name="sortOrder" type="number" min={0} max={99} defaultValue={defaults.sortOrder ?? 0} className="input" />
        </label>
      )}
      <label className="block sm:col-span-2">
        <span className="label">Description</span>
        <textarea name="description" rows={2} defaultValue={defaults.description} placeholder="One or two lines about the paper" className="input" />
      </label>
    </>
  );
}

export function UnitFields({ defaults = {} }: { defaults?: { unitNo?: number; title?: string; hours?: number; topics?: string } }) {
  return (
    <>
      <label className="block">
        <span className="label">Module no.</span>
        <input name="unitNo" type="number" min={1} max={50} defaultValue={defaults.unitNo} className="input" />
      </label>
      <label className="block">
        <span className="label">Title</span>
        <input name="title" required defaultValue={defaults.title} placeholder="e.g. Convergence of Random Variables" className="input" />
      </label>
      <label className="block">
        <span className="label">Hours</span>
        <input name="hours" type="number" min={0} max={300} defaultValue={defaults.hours ?? 15} className="input" />
      </label>
      <label className="block sm:col-span-3">
        <span className="label">Topics (one per line)</span>
        <textarea
          name="topics"
          rows={Math.min(10, Math.max(4, (defaults.topics?.split("\n").length ?? 3) + 1))}
          defaultValue={defaults.topics}
          placeholder={"Convergence in probability\nAlmost sure convergence\nDominated convergence theorem"}
          className="input font-mono text-[13px]"
        />
      </label>
    </>
  );
}

type SemesterCreate = {
  programs: Array<{ id: number; name: string }>;
  linkOptions: Array<{ id: number; label: string }>;
  defaultProgramId?: number;
};

export function SemesterFields({
  defaults = {},
  create,
}: {
  defaults?: { title?: string; session?: string; description?: string };
  create?: SemesterCreate;
}) {
  return (
    <>
      {create && (
        <>
          <label className="block">
            <span className="label">Programme</span>
            <select name="programId" required defaultValue={create.defaultProgramId ?? create.programs[0]?.id} className="input">
              {create.programs.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </label>
          <label className="block">
            <span className="label">Semester no.</span>
            <input name="number" type="number" min={1} max={12} required placeholder="e.g. 5" className="input" />
          </label>
        </>
      )}
      <label className="block sm:col-span-2">
        <span className="label">Title</span>
        <input name="title" required={!create} defaultValue={defaults.title} placeholder="e.g. Semester 5 - Designs, Models and Quality" className="input" />
      </label>
      <label className="block sm:col-span-2">
        <span className="label">Session</span>
        <input name="session" defaultValue={defaults.session} placeholder="e.g. Odd semester | AY 2026-27" className="input" />
      </label>
      <label className="block sm:col-span-2">
        <span className="label">Description</span>
        <textarea name="description" rows={2} defaultValue={defaults.description} className="input" />
      </label>
      {create && (
        <label className="block sm:col-span-2">
          <span className="label">Shares classes with (optional)</span>
          <select name="linkedSemesterId" defaultValue="" className="input">
            <option value="">No - this semester has its own papers</option>
            {create.linkOptions.map((o) => (
              <option key={o.id} value={o.id}>
                {o.label}
              </option>
            ))}
          </select>
          <span className="mt-1 block text-xs text-slate-500">
            Choose a semester when students attend the same classes - e.g. Integrated M.Sc. Semester 7 = M.Sc. Semester 1. Papers, files,
            timetable and exams are then shared.
          </span>
        </label>
      )}
    </>
  );
}
