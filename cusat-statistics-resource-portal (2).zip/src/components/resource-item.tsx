import Link from "next/link";
import { BookOpen, CircleAlert, Download, ExternalLink, Eye, Trash2 } from "lucide-react";
import type { ResourceItem } from "@/lib/data";
import { TYPE_META, isResourceType } from "@/lib/site";
import { formatBytes, timeAgo, toRoman } from "@/lib/utils";
import { ApiButton } from "./client";
import { Badge, TypeIcon } from "./ui";

export const fileHref = (id: number, download = false) => `/api/files/${id}${download ? "?download=1" : ""}`;

export function fileKind(r: Pick<ResourceItem, "source" | "externalUrl" | "fileName">) {
  if (r.source === "generated") return "PDF";
  if (r.source === "link") return r.externalUrl?.toLowerCase().split("?")[0].endsWith(".pdf") ? "PDF link" : "Web link";
  if (r.source === "upload") {
    const ext = r.fileName?.split(".").pop()?.toUpperCase();
    return ext && ext.length <= 5 ? ext : "File";
  }
  return null;
}

function Actions({ item, isAdmin }: { item: ResourceItem; isAdmin?: boolean }) {
  return (
    <div className="flex shrink-0 items-center gap-1.5">
      {item.source === "link" ? (
        <a href={fileHref(item.id)} target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm">
          <ExternalLink className="h-3.5 w-3.5" aria-hidden />
          Open
        </a>
      ) : item.source === "none" ? (
        <Link
          href={`/view/${item.id}`}
          className="inline-flex items-center gap-1 rounded-lg bg-slate-50 px-2.5 py-1.5 text-xs font-medium text-slate-500 ring-1 ring-inset ring-slate-200 hover:bg-slate-100"
        >
          <CircleAlert className="h-3.5 w-3.5" aria-hidden />
          {isAdmin ? "Attach PDF" : "PDF not uploaded"}
        </Link>
      ) : (
        <>
          <Link href={`/view/${item.id}`} className="btn btn-secondary btn-sm" title="View">
            <Eye className="h-3.5 w-3.5" aria-hidden />
            <span className="hidden sm:inline">View</span>
          </Link>
          <a href={fileHref(item.id, true)} className="btn btn-primary btn-sm" title="Download">
            <Download className="h-3.5 w-3.5" aria-hidden />
            <span className="hidden sm:inline">Download</span>
          </a>
        </>
      )}
      {isAdmin && (
        <ApiButton
          endpoint={`/api/admin/resources/${item.id}`}
          method="DELETE"
          confirmMessage={`Delete "${item.title}"? This cannot be undone.`}
          className="btn btn-ghost btn-sm text-rose-600 hover:bg-rose-50 hover:text-rose-700"
          title="Delete"
        >
          <Trash2 className="h-3.5 w-3.5" aria-hidden />
        </ApiButton>
      )}
    </div>
  );
}

export function ResourceRow({
  item,
  showSubject = false,
  showSemester = false,
  showType = true,
  isAdmin = false,
}: {
  item: ResourceItem;
  showSubject?: boolean;
  showSemester?: boolean;
  showType?: boolean;
  isAdmin?: boolean;
}) {
  const type = isResourceType(item.type) ? item.type : "notes";
  const meta: string[] = [];
  if (showSemester) meta.push(`${item.programShort} Sem ${item.semesterNumber}${item.aliasLabel ? ` / ${item.aliasLabel}` : ""}`);
  if (showSubject && item.subjectCode) meta.push(item.subjectCode);
  const kind = fileKind(item);
  if (kind) meta.push(kind);
  const size = formatBytes(item.fileSize);
  if (size) meta.push(size);
  if (item.downloads > 0) meta.push(`${item.downloads} view${item.downloads === 1 ? "" : "s"}`);
  if (item.source === "upload" || item.source === "link") meta.push(timeAgo(item.createdAt));

  return (
    <div className="flex items-start gap-3 rounded-xl border border-slate-200/80 bg-white p-3 transition hover:border-indigo-200 hover:shadow-sm sm:items-center sm:p-4">
      <TypeIcon type={type} />
      <div className="min-w-0 flex-1">
        <Link href={`/view/${item.id}`} className="line-clamp-2 font-semibold text-slate-900 hover:text-indigo-600">
          {item.title}
        </Link>
        <div className="mt-1 flex flex-wrap items-center gap-1.5">
          {showType && <Badge className={TYPE_META[type].badge}>{TYPE_META[type].label}</Badge>}
          {item.unitNo ? <Badge>Module {toRoman(item.unitNo)}</Badge> : null}
          {item.year ? <Badge>{item.year}</Badge> : null}
          {item.examLabel && type === "internal" ? <Badge>{item.examLabel}</Badge> : null}
          {item.isOpenAccess && <Badge className="bg-emerald-50 text-emerald-700 ring-emerald-600/20">Free book</Badge>}
          {item.isSample && <Badge className="bg-amber-50 text-amber-700 ring-amber-600/20">Sample</Badge>}
          {meta.length > 0 && <span className="text-xs text-slate-500">{meta.join(" · ")}</span>}
        </div>
        {showSubject && item.subjectName ? <p className="mt-1 truncate text-xs text-slate-500">{item.subjectName}</p> : null}
      </div>
      <Actions item={item} isAdmin={isAdmin} />
    </div>
  );
}

export function BookCard({ item, isAdmin = false }: { item: ResourceItem; isAdmin?: boolean }) {
  const details = [item.publisher, item.edition].filter(Boolean).join(" · ");
  return (
    <div className="flex gap-4 rounded-2xl border border-slate-200/80 bg-white p-4 transition hover:border-sky-200 hover:shadow-sm">
      <div
        className={`flex h-24 w-[72px] shrink-0 flex-col justify-between rounded-lg p-2 text-white shadow-md ${
          item.isOpenAccess ? "bg-linear-to-br from-emerald-500 to-teal-600" : "bg-linear-to-br from-sky-500 to-indigo-600"
        }`}
      >
        <BookOpen className="h-4 w-4 opacity-80" aria-hidden />
        <span className="line-clamp-3 text-[9px] font-semibold leading-tight">{item.title}</span>
      </div>
      <div className="flex min-w-0 flex-1 flex-col">
        <Link href={`/view/${item.id}`} className="line-clamp-2 font-semibold text-slate-900 hover:text-sky-700">
          {item.title}
        </Link>
        {item.author ? <p className="mt-0.5 line-clamp-1 text-sm text-slate-600">{item.author}</p> : null}
        {details ? <p className="text-xs text-slate-500">{details}</p> : null}
        <div className="mt-2 flex flex-wrap gap-1.5">
          {item.isOpenAccess ? (
            <Badge className="bg-emerald-50 text-emerald-700 ring-emerald-600/20">Free & open access</Badge>
          ) : item.description ? (
            <Badge className="bg-sky-50 text-sky-700 ring-sky-600/20">{item.description}</Badge>
          ) : null}
          {item.source === "upload" ? <Badge>{fileKind(item)} uploaded</Badge> : null}
        </div>
        <div className="mt-auto pt-3">
          <Actions item={item} isAdmin={isAdmin} />
        </div>
      </div>
    </div>
  );
}
