import { CalendarClock, CalendarDays, Clock, MapPin, Trash2 } from "lucide-react";
import type { TimetableData } from "@/lib/data";
import { DAYS, EXAM_TYPES, SLOT_KINDS, SUBJECT_COLORS } from "@/lib/site";
import { activeDays, breakLabel, buildColumns, dayCells } from "@/lib/timetable";
import { cn, daysBetween, formatDate, formatTime, relativeDay, weekdayName } from "@/lib/utils";
import { ApiButton } from "./client";
import { Badge, EmptyState } from "./ui";

type Subject = TimetableData["subjects"][number];

const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function colorFor(subjects: Subject[], id: number | null) {
  const idx = subjects.findIndex((s) => s.id === id);
  return idx < 0 ? "bg-slate-50 border-slate-200 text-slate-700" : SUBJECT_COLORS[idx % SUBJECT_COLORS.length];
}

export function WeeklyGrid({ data, today }: { data: TimetableData; today: number }) {
  const { slots, subjects } = data;
  if (!slots.length) {
    return (
      <EmptyState icon={CalendarDays} title="Class timetable not published yet">
        The weekly schedule will appear here once it is added from the admin panel.
      </EmptyState>
    );
  }
  const cols = buildColumns(slots);
  const days = activeDays(slots);
  const byId = new Map(subjects.map((s) => [s.id, s]));

  return (
    <div className="overflow-x-auto rounded-2xl border border-slate-200 bg-white shadow-sm">
      <table className="w-full min-w-[820px] border-collapse text-sm">
        <thead>
          <tr className="bg-slate-50">
            <th className="sticky left-0 z-10 w-24 border-b border-slate-200 bg-slate-50 px-3 py-2 text-left text-xs font-semibold uppercase tracking-wide text-slate-500">
              Day
            </th>
            {cols.map((c) => (
              <th
                key={c.start}
                className={cn(
                  "border-b border-l border-slate-200 px-2 py-2 text-center text-[11px] font-semibold text-slate-500",
                  !c.used && "w-9 bg-slate-100",
                )}
              >
                {c.used ? (
                  <>
                    <span className="block text-slate-700">{formatTime(c.start)}</span>
                    <span className="block font-normal">{formatTime(c.end)}</span>
                  </>
                ) : (
                  <span className="sr-only">{breakLabel(c)}</span>
                )}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {days.map((day, rowIdx) => {
            const cells = dayCells(
              cols,
              slots.filter((s) => s.day === day),
            );
            const isToday = day === today;
            return (
              <tr key={day} className={cn(isToday && "bg-indigo-50/40")}>
                <th
                  className={cn(
                    "sticky left-0 z-10 border-b border-slate-200 px-3 py-2 text-left font-semibold",
                    isToday ? "bg-indigo-50 text-indigo-700" : "bg-white text-slate-700",
                  )}
                >
                  <span className="block">{DAYS[day].slice(0, 3)}</span>
                  {isToday && <span className="mt-0.5 inline-block rounded-full bg-indigo-600 px-1.5 py-0.5 text-[10px] font-semibold text-white">Today</span>}
                </th>
                {cells.map((cell) => {
                  if (cell.type === "break") {
                    return rowIdx === 0 ? (
                      <td key={cell.col.start} rowSpan={days.length} className="border-b border-l border-slate-200 bg-slate-100 text-center align-middle">
                        <span className="inline-block rotate-180 text-[10px] font-semibold uppercase tracking-[0.25em] text-slate-400 [writing-mode:vertical-rl]">
                          {breakLabel(cell.col)}
                        </span>
                      </td>
                    ) : null;
                  }
                  if (cell.type === "empty") return <td key={cell.col.start} className="border-b border-l border-slate-200 p-1.5" />;
                  const s = cell.slot;
                  const sub = s.subjectId ? byId.get(s.subjectId) : undefined;
                  return (
                    <td key={cell.col.start} colSpan={cell.span} className="border-b border-l border-slate-200 p-1.5 align-top">
                      <div className={cn("h-full min-h-[64px] rounded-lg border px-2 py-1.5", colorFor(subjects, s.subjectId))}>
                        <div className="flex items-start justify-between gap-1">
                          <span className="font-semibold leading-tight">{sub?.shortName || sub?.code || s.label || "-"}</span>
                          {s.kind !== "theory" && (
                            <span className="rounded bg-white/70 px-1 text-[10px] font-semibold uppercase">{SLOT_KINDS[s.kind] ?? s.kind}</span>
                          )}
                        </div>
                        {sub && <div className="mt-0.5 truncate text-[11px] opacity-80">{sub.code}</div>}
                        {s.room && (
                          <div className="mt-0.5 flex items-center gap-1 text-[11px] opacity-80">
                            <MapPin className="h-3 w-3" aria-hidden />
                            {s.room}
                          </div>
                        )}
                      </div>
                    </td>
                  );
                })}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export function SubjectLegend({ data }: { data: TimetableData }) {
  if (!data.subjects.length) return null;
  return (
    <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-3">
      {data.subjects.map((s) => (
        <div key={s.id} className={cn("rounded-xl border px-3 py-2 text-sm", colorFor(data.subjects, s.id))}>
          <div className="flex items-center justify-between gap-2">
            <span className="font-semibold">{s.shortName || s.code}</span>
            <span className="text-[11px] font-medium opacity-70">{s.code}</span>
          </div>
          <div className="truncate text-xs opacity-80">{s.name}</div>
          {s.faculty && <div className="truncate text-xs opacity-70">{s.faculty}</div>}
        </div>
      ))}
    </div>
  );
}

export function ExamSchedule({ data, today, isAdmin = false }: { data: TimetableData; today: string; isAdmin?: boolean }) {
  const byId = new Map(data.subjects.map((s) => [s.id, s]));
  const groups = Object.entries(EXAM_TYPES)
    .sort((a, b) => a[1].order - b[1].order)
    .map(([key, meta]) => ({ key, meta, items: data.exams.filter((e) => e.examType === key) }))
    .filter((g) => g.items.length);
  const known = new Set(Object.keys(EXAM_TYPES));
  const other = data.exams.filter((e) => !known.has(e.examType));
  if (other.length) groups.push({ key: "other", meta: { label: "Other exams", order: 99, badge: "bg-slate-50 text-slate-600 ring-slate-500/20" }, items: other });

  if (!groups.length) {
    return (
      <EmptyState icon={CalendarClock} title="No exams scheduled yet">
        Internal tests, practicals and end-semester exams will be listed here.
      </EmptyState>
    );
  }

  return (
    <div className="space-y-5">
      {groups.map((g) => {
        const sorted = g.items.slice().sort((a, b) => (a.examDate + a.startTime).localeCompare(b.examDate + b.startTime));
        const upcoming = sorted.filter((e) => e.examDate >= today).length;
        const status = upcoming === 0 ? "Completed" : upcoming === sorted.length ? "Upcoming" : "Ongoing";
        const first = sorted[0].examDate;
        const last = sorted[sorted.length - 1].examDate;
        return (
          <section key={g.key} className="card overflow-hidden">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-100 bg-slate-50/60 px-4 py-3">
              <div className="flex flex-wrap items-center gap-2">
                <Badge className={g.meta.badge}>{g.meta.label}</Badge>
                <span className="text-sm text-slate-500">
                  {first === last ? formatDate(first) : `${formatDate(first, "short")} - ${formatDate(last)}`}
                </span>
              </div>
              <span
                className={cn(
                  "rounded-full px-2.5 py-0.5 text-xs font-semibold",
                  status === "Completed" ? "bg-slate-100 text-slate-500" : status === "Ongoing" ? "bg-amber-100 text-amber-800" : "bg-indigo-100 text-indigo-700",
                )}
              >
                {status}
              </span>
            </div>
            <ul className="divide-y divide-slate-100">
              {sorted.map((e) => {
                const sub = e.subjectId ? byId.get(e.subjectId) : undefined;
                const diff = daysBetween(today, e.examDate);
                const [, mm, dd] = e.examDate.split("-");
                return (
                  <li key={e.id} className={cn("flex items-center gap-3 px-4 py-3", diff < 0 && "opacity-60")}>
                    <div className="flex w-14 shrink-0 flex-col items-center rounded-xl bg-white py-1.5 ring-1 ring-slate-200">
                      <span className="text-[10px] font-semibold uppercase text-rose-600">{MONTHS[Number(mm) - 1]}</span>
                      <span className="text-lg font-bold leading-none text-slate-900">{Number(dd)}</span>
                      <span className="text-[10px] text-slate-500">{weekdayName(e.examDate, "short")}</span>
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-semibold text-slate-900">{sub?.name ?? (e.title || "Exam")}</p>
                      <p className="flex flex-wrap items-center gap-x-3 gap-y-0.5 text-xs text-slate-500">
                        {sub && <span className="font-medium text-slate-600">{sub.code}</span>}
                        <span className="inline-flex items-center gap-1">
                          <Clock className="h-3 w-3" aria-hidden />
                          {formatTime(e.startTime)} - {formatTime(e.endTime)}
                        </span>
                        {e.venue && (
                          <span className="inline-flex items-center gap-1">
                            <MapPin className="h-3 w-3" aria-hidden />
                            {e.venue}
                          </span>
                        )}
                      </p>
                    </div>
                    <span
                      className={cn(
                        "shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold",
                        diff === 0 ? "bg-rose-600 text-white" : diff > 0 ? "bg-indigo-50 text-indigo-700" : "bg-slate-100 text-slate-500",
                      )}
                    >
                      {diff < 0 ? "Done" : relativeDay(e.examDate, today)}
                    </span>
                    {isAdmin && (
                      <ApiButton
                        endpoint={`/api/admin/exams/${e.id}`}
                        method="DELETE"
                        confirmMessage="Delete this exam from the timetable?"
                        className="btn btn-ghost btn-sm text-rose-600 hover:bg-rose-50"
                        title="Delete exam"
                      >
                        <Trash2 className="h-3.5 w-3.5" aria-hidden />
                      </ApiButton>
                    )}
                  </li>
                );
              })}
            </ul>
          </section>
        );
      })}
    </div>
  );
}

export function TodayClasses({ data, weekday }: { data: TimetableData; weekday: number }) {
  const byId = new Map(data.subjects.map((s) => [s.id, s]));
  const list = data.slots.filter((s) => s.day === weekday).sort((a, b) => a.startTime.localeCompare(b.startTime));
  if (weekday === 0 || !list.length) {
    return <p className="text-sm text-slate-500">{weekday === 0 ? "It's Sunday - no classes today." : "No classes scheduled today."}</p>;
  }
  return (
    <ul className="space-y-2">
      {list.map((s) => {
        const sub = s.subjectId ? byId.get(s.subjectId) : undefined;
        return (
          <li key={s.id} className={cn("flex items-center gap-3 rounded-xl border px-3 py-2", colorFor(data.subjects, s.subjectId))}>
            <span className="w-[70px] shrink-0 text-xs font-semibold">{formatTime(s.startTime)}</span>
            <span className="min-w-0 flex-1">
              <span className="block truncate text-sm font-semibold">{sub?.name ?? s.label}</span>
              <span className="block truncate text-xs opacity-75">
                {SLOT_KINDS[s.kind] ?? s.kind}
                {s.room ? ` · ${s.room}` : ""}
              </span>
            </span>
          </li>
        );
      })}
    </ul>
  );
}
