import Link from "next/link";
import { ArrowRight, Link as LinkIcon } from "lucide-react";
import type { ProgramWithSemesters, SemesterNode, SemesterStats } from "@/lib/data";
import { programTheme, semTheme } from "@/lib/site";
import { cn, semesterInSession, yearOfSemester } from "@/lib/utils";
import { Badge, InSessionBadge, semesterSubtitle } from "./ui";

export const programHref = (slug: string) => `/p/${slug}`;
export const semesterHref = (slug: string, n: number) => `/p/${slug}/semester/${n}`;
export const timetableHref = (slug: string, n: number) => `/p/${slug}/semester/${n}/timetable`;

/** "M.Sc. Sem 1 / Int. M.Sc. Sem 7" */
export function semesterTag(programShort: string, number: number, alias?: string | null) {
  return `${programShort} Sem ${number}${alias ? ` / ${alias}` : ""}`;
}

export function SemesterCard({ slug, sem, stats, today }: { slug: string; sem: SemesterNode; stats?: SemesterStats; today: string }) {
  const theme = semTheme(sem.number);
  const inSession = semesterInSession(sem.number, today);
  const items = [
    { label: "Papers", value: stats?.subjectCount ?? 0 },
    { label: "Notes", value: stats?.counts.notes ?? 0 },
    { label: "PYQs", value: stats?.counts.pyq ?? 0 },
    { label: "Internals", value: stats?.counts.internal ?? 0 },
  ];
  return (
    <Link
      href={semesterHref(slug, sem.number)}
      className="card group flex flex-col overflow-hidden transition hover:-translate-y-0.5 hover:shadow-md"
    >
      <div className={cn("flex items-center justify-between gap-2 bg-linear-to-r px-4 py-3 text-white", theme.gradient)}>
        <div>
          <p className="text-[11px] font-semibold uppercase tracking-widest text-white/80">Semester</p>
          <p className="text-3xl font-black leading-none">{sem.number}</p>
        </div>
        {sem.linked ? (
          <span className="inline-flex items-center gap-1 rounded-full bg-white/20 px-2 py-0.5 text-[11px] font-semibold">
            <LinkIcon className="h-3 w-3" aria-hidden /> Joint
          </span>
        ) : null}
      </div>
      <div className="flex flex-1 flex-col p-4">
        <p className="line-clamp-2 text-sm font-semibold text-slate-900">{semesterSubtitle(sem.title)}</p>
        <div className="mt-1.5 flex flex-wrap gap-1.5">
          {inSession && <InSessionBadge />}
          {sem.linked && (
            <Badge className="bg-violet-50 text-violet-700 ring-violet-600/20">
              Same as {sem.linked.programShort} Sem {sem.linked.number}
            </Badge>
          )}
        </div>
        <dl className="mt-3 grid grid-cols-4 gap-1 text-center">
          {items.map((i) => (
            <div key={i.label} className="flex flex-col-reverse rounded-lg bg-slate-50 py-1.5">
              <dt className="text-[10px] text-slate-500">{i.label}</dt>
              <dd className="text-sm font-bold text-slate-900">{i.value}</dd>
            </div>
          ))}
        </dl>
        <span className="mt-auto inline-flex items-center gap-1 pt-3 text-sm font-semibold text-indigo-600">
          Open <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" aria-hidden />
        </span>
      </div>
    </Link>
  );
}

/**
 * Timeline of every programme. Semesters that are linked line up with the semester
 * they share, e.g. Integrated Sem 7-10 sit directly under M.Sc. Sem 1-4.
 */
export function ProgramPathway({ programs, today }: { programs: ProgramWithSemesters[]; today: string }) {
  const offsets = new Map<number, number>();
  for (const p of programs) offsets.set(p.id, 0);
  for (const p of programs)
    for (const s of p.semesters)
      if (s.linked) offsets.set(s.linked.programId, Math.max(offsets.get(s.linked.programId) ?? 0, s.number - s.linked.number));
  const cols = Math.max(1, ...programs.map((p) => (offsets.get(p.id) ?? 0) + Math.max(p.totalSemesters, p.semesters.length)));
  const years = Math.ceil(cols / 2);

  return (
    <div className="overflow-x-auto">
      <div className="min-w-[720px] space-y-3">
        <div className="grid gap-1.5" style={{ gridTemplateColumns: `180px repeat(${cols}, minmax(0, 1fr))` }}>
          <span />
          {Array.from({ length: years }, (_, i) => (
            <span
              key={i}
              className="rounded-md bg-slate-100 py-1 text-center text-[11px] font-semibold uppercase tracking-wide text-slate-500"
              style={{ gridColumn: `${i * 2 + 2} / span ${Math.min(2, cols - i * 2)}` }}
            >
              Year {i + 1}
            </span>
          ))}
        </div>
        {programs.map((p) => {
          const theme = programTheme(p.sortOrder);
          const offset = offsets.get(p.id) ?? 0;
          return (
            <div key={p.id} className="grid items-stretch gap-1.5" style={{ gridTemplateColumns: `180px repeat(${cols}, minmax(0, 1fr))` }}>
              <Link href={programHref(p.slug)} className="flex flex-col justify-center pr-2">
                <span className={cn("text-sm font-bold", theme.text)}>{p.name}</span>
                <span className="text-xs text-slate-500">
                  {p.durationYears} years · {p.totalSemesters} semesters
                </span>
              </Link>
              {p.semesters.map((s) => {
                const joint = !!s.linked;
                const shared = programs.some((q) => q.semesters.some((x) => x.linkedSemesterId === s.id));
                const live = semesterInSession(s.number, today);
                return (
                  <Link
                    key={s.id}
                    href={semesterHref(p.slug, s.number)}
                    title={joint ? `Joint with ${s.linked?.programName} Semester ${s.linked?.number}` : s.title}
                    style={{ gridColumnStart: offset + s.number + 1 }}
                    className={cn(
                      "relative flex flex-col items-center justify-center rounded-xl border px-1 py-2 text-center transition hover:-translate-y-0.5 hover:shadow-sm",
                      joint
                        ? "border-violet-300 bg-violet-50 text-violet-800"
                        : shared
                          ? cn("bg-white", theme.border, theme.text)
                          : "border-slate-200 bg-white text-slate-700",
                    )}
                  >
                    {live && <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-emerald-500" aria-label="In session" />}
                    <span className="text-[10px] font-semibold uppercase tracking-wide opacity-70">Sem</span>
                    <span className="text-lg font-black leading-none">{s.number}</span>
                    <span className="mt-0.5 text-[10px] opacity-70">
                      {joint ? `= ${s.linked?.programShort} ${s.linked?.number}` : `Year ${yearOfSemester(s.number)}`}
                    </span>
                  </Link>
                );
              })}
            </div>
          );
        })}
        <p className="flex flex-wrap items-center gap-x-4 gap-y-1 pl-[188px] text-xs text-slate-500">
          <span className="inline-flex items-center gap-1.5">
            <span className="h-3 w-3 rounded border border-violet-300 bg-violet-50" /> Joint semester (same classes, papers and exams)
          </span>
          <span className="inline-flex items-center gap-1.5">
            <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" /> In session now
          </span>
        </p>
      </div>
    </div>
  );
}
