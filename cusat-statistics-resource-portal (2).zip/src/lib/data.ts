import { cache } from "react";
import { and, asc, desc, eq, gte, ilike, inArray, ne, or, sql, type AnyColumn, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { ensureDb } from "@/db/bootstrap";
import { classSlots, exams, files, programs, resources, semesters, subjects, syllabusUnits, type Program, type Semester } from "@/db/schema";
import { isResourceType, type ResourceType } from "./site";
import { todayISO } from "./utils";

export type TypeCounts = Record<ResourceType, number>;
export const emptyCounts = (): TypeCounts => ({ notes: 0, pyq: 0, internal: 0, textbook: 0, syllabus: 0, timetable: 0 });

/** "Int. M.Sc. Sem 7" for every semester that shares (links to) the given semester. */
const aliasLabelSql = (semesterCol: AnyColumn) =>
  sql<string | null>`(select string_agg(p2.short_name || ' Sem ' || s2.number::text, ', ' order by p2.sort_order, s2.number) from semesters s2 join programs p2 on p2.id = s2.program_id where s2.linked_semester_id = ${semesterCol})`;

/* ---------------- Programmes & semesters ---------------- */

export type LinkedInfo = { id: number; number: number; programId: number; programSlug: string; programName: string; programShort: string };
export type SemesterNode = Semester & { contentId: number; linked: LinkedInfo | null };
export type ProgramWithSemesters = Program & { semesters: SemesterNode[] };
export type SharedRef = { programSlug: string; programName: string; programShort: string; number: number };

export const listProgramsWithSemesters = cache(async (): Promise<ProgramWithSemesters[]> => {
  await ensureDb();
  const [progs, sems] = await Promise.all([
    db.select().from(programs).orderBy(asc(programs.sortOrder), asc(programs.id)),
    db.select().from(semesters).orderBy(asc(semesters.number), asc(semesters.id)),
  ]);
  const semById = new Map(sems.map((s) => [s.id, s]));
  const progById = new Map(progs.map((p) => [p.id, p]));
  return progs.map((p) => ({
    ...p,
    semesters: sems
      .filter((s) => s.programId === p.id)
      .map((s) => {
        const target = s.linkedSemesterId ? semById.get(s.linkedSemesterId) : undefined;
        const tp = target ? progById.get(target.programId) : undefined;
        return {
          ...s,
          contentId: target?.id ?? s.id,
          linked:
            target && tp
              ? { id: target.id, number: target.number, programId: tp.id, programSlug: tp.slug, programName: tp.name, programShort: tp.shortName }
              : null,
        };
      }),
  }));
});

/** Semesters (of any programme) that link to - i.e. share - the given semester. */
export function sharedWithOf(all: ProgramWithSemesters[], semesterId: number): SharedRef[] {
  return all.flatMap((p) =>
    p.semesters
      .filter((s) => s.linkedSemesterId === semesterId)
      .map((s) => ({ programSlug: p.slug, programName: p.name, programShort: p.shortName, number: s.number })),
  );
}

/** Semesters that hold their own content (not linked) - used for uploads and timetable editing. */
export function contentSemesters(all: ProgramWithSemesters[]) {
  return all.flatMap((p) =>
    p.semesters
      .filter((s) => !s.linked)
      .map((s) => ({ ...s, program: p, sharedWith: sharedWithOf(all, s.id) })),
  );
}

export async function getProgramBySlug(slug: string) {
  const all = await listProgramsWithSemesters();
  return all.find((p) => p.slug === slug) ?? null;
}

export async function getSemesterView(slug: string, number: number) {
  const all = await listProgramsWithSemesters();
  const program = all.find((p) => p.slug === slug);
  const semester = program?.semesters.find((s) => s.number === number);
  if (!program || !semester) return null;
  const contentProgram = semester.linked ? (all.find((p) => p.id === semester.linked?.programId) ?? program) : program;
  const contentSemester = semester.linked ? (contentProgram.semesters.find((s) => s.id === semester.linked?.id) ?? semester) : semester;
  return { all, program, semester, contentProgram, contentSemester, sharedWith: sharedWithOf(all, contentSemester.id) };
}

export type SemesterStats = { subjectCount: number; credits: number; counts: TypeCounts };

/** Paper / credit / material counts for the given (content) semester ids. */
export async function getSemesterStats(semesterIds: number[]) {
  await ensureDb();
  const ids = Array.from(new Set(semesterIds));
  const out = new Map<number, SemesterStats>();
  if (!ids.length) return out;
  const [subjectRows, typeRows] = await Promise.all([
    db
      .select({ semesterId: subjects.semesterId, n: sql<number>`count(*)::int`, credits: sql<number>`coalesce(sum(${subjects.credits}),0)::int` })
      .from(subjects)
      .where(inArray(subjects.semesterId, ids))
      .groupBy(subjects.semesterId),
    db
      .select({ semesterId: resources.semesterId, type: resources.type, n: sql<number>`count(*)::int` })
      .from(resources)
      .where(inArray(resources.semesterId, ids))
      .groupBy(resources.semesterId, resources.type),
  ]);
  for (const id of ids) out.set(id, { subjectCount: 0, credits: 0, counts: emptyCounts() });
  for (const r of subjectRows) {
    const s = out.get(r.semesterId);
    if (s) {
      s.subjectCount = r.n;
      s.credits = r.credits;
    }
  }
  for (const r of typeRows) {
    const s = out.get(r.semesterId);
    if (s && isResourceType(r.type)) s.counts[r.type] = r.n;
  }
  return out;
}

export async function getTotals() {
  await ensureDb();
  const [typeRows, [{ papers }]] = await Promise.all([
    db.select({ type: resources.type, n: sql<number>`count(*)::int` }).from(resources).groupBy(resources.type),
    db.select({ papers: sql<number>`count(*)::int` }).from(subjects),
  ]);
  const counts = emptyCounts();
  for (const row of typeRows) if (isResourceType(row.type)) counts[row.type] = row.n;
  return { counts, papers };
}

export async function getSubjectsWithCounts(semesterId: number) {
  await ensureDb();
  const [subs, typeRows, unitRows] = await Promise.all([
    db.select().from(subjects).where(eq(subjects.semesterId, semesterId)).orderBy(asc(subjects.sortOrder), asc(subjects.id)),
    db
      .select({ subjectId: resources.subjectId, type: resources.type, n: sql<number>`count(*)::int` })
      .from(resources)
      .where(eq(resources.semesterId, semesterId))
      .groupBy(resources.subjectId, resources.type),
    db
      .select({ subjectId: syllabusUnits.subjectId, n: sql<number>`count(*)::int` })
      .from(syllabusUnits)
      .innerJoin(subjects, eq(syllabusUnits.subjectId, subjects.id))
      .where(eq(subjects.semesterId, semesterId))
      .groupBy(syllabusUnits.subjectId),
  ]);
  return subs.map((s) => {
    const counts = emptyCounts();
    for (const row of typeRows) if (row.subjectId === s.id && isResourceType(row.type)) counts[row.type] = row.n;
    return { ...s, counts, unitCount: unitRows.find((u) => u.subjectId === s.id)?.n ?? 0 };
  });
}

export async function listAllSubjects() {
  await ensureDb();
  return db
    .select({
      id: subjects.id,
      semesterId: subjects.semesterId,
      code: subjects.code,
      name: subjects.name,
      kind: subjects.kind,
      semesterNumber: semesters.number,
      programId: programs.id,
      programSlug: programs.slug,
      programName: programs.name,
      programShort: programs.shortName,
    })
    .from(subjects)
    .innerJoin(semesters, eq(subjects.semesterId, semesters.id))
    .innerJoin(programs, eq(semesters.programId, programs.id))
    .orderBy(asc(programs.sortOrder), asc(semesters.number), asc(subjects.sortOrder), asc(subjects.id));
}

export async function getSubjectDetail(id: number) {
  await ensureDb();
  const [row] = await db
    .select({ subject: subjects, semester: semesters, program: programs })
    .from(subjects)
    .innerJoin(semesters, eq(subjects.semesterId, semesters.id))
    .innerJoin(programs, eq(semesters.programId, programs.id))
    .where(eq(subjects.id, id))
    .limit(1);
  if (!row) return null;
  const units = await db
    .select()
    .from(syllabusUnits)
    .where(eq(syllabusUnits.subjectId, id))
    .orderBy(asc(syllabusUnits.unitNo), asc(syllabusUnits.id));
  return { ...row, units };
}

/* ---------------- Resources ---------------- */

function resourceQuery() {
  return db
    .select({
      id: resources.id,
      type: resources.type,
      title: resources.title,
      description: resources.description,
      source: resources.source,
      externalUrl: resources.externalUrl,
      unitNo: resources.unitNo,
      year: resources.year,
      examLabel: resources.examLabel,
      author: resources.author,
      publisher: resources.publisher,
      edition: resources.edition,
      isSample: resources.isSample,
      isOpenAccess: resources.isOpenAccess,
      downloads: resources.downloads,
      createdAt: resources.createdAt,
      fileId: resources.fileId,
      semesterId: resources.semesterId,
      subjectId: resources.subjectId,
      semesterNumber: semesters.number,
      programSlug: programs.slug,
      programName: programs.name,
      programShort: programs.shortName,
      aliasLabel: aliasLabelSql(resources.semesterId),
      subjectName: subjects.name,
      subjectCode: subjects.code,
      subjectKind: subjects.kind,
      fileMime: files.mimeType,
      fileSize: files.size,
      fileName: files.filename,
    })
    .from(resources)
    .innerJoin(semesters, eq(resources.semesterId, semesters.id))
    .innerJoin(programs, eq(semesters.programId, programs.id))
    .leftJoin(subjects, eq(resources.subjectId, subjects.id))
    .leftJoin(files, eq(resources.fileId, files.id))
    .$dynamic();
}

export type ResourceItem = Awaited<ReturnType<typeof resourceQuery>>[number];

export type ResourceFilters = {
  q?: string;
  type?: ResourceType;
  /** Content semester ids (linked semesters already resolved). */
  semesterIds?: number[];
  subjectId?: number;
  sort?: "new" | "popular" | "title";
  limit?: number;
  offset?: number;
};

export async function searchResources(f: ResourceFilters) {
  await ensureDb();
  if (f.semesterIds && !f.semesterIds.length) return { items: [] as ResourceItem[], total: 0 };
  const conds: SQL[] = [];
  if (f.type) conds.push(eq(resources.type, f.type));
  if (f.semesterIds) conds.push(inArray(resources.semesterId, f.semesterIds));
  if (f.subjectId) conds.push(eq(resources.subjectId, f.subjectId));
  const q = f.q?.trim();
  if (q) {
    const like = `%${q.replace(/[%_\\]/g, (m) => `\\${m}`)}%`;
    const match = or(
      ilike(resources.title, like),
      ilike(resources.description, like),
      ilike(resources.author, like),
      ilike(resources.examLabel, like),
      ilike(subjects.name, like),
      ilike(subjects.code, like),
    );
    if (match) conds.push(match);
  }
  const where = conds.length ? and(...conds) : undefined;
  const order =
    f.sort === "popular"
      ? [desc(resources.downloads), desc(resources.id)]
      : f.sort === "title"
        ? [asc(resources.title), asc(resources.id)]
        : [desc(resources.createdAt), desc(resources.id)];
  const [items, totalRows] = await Promise.all([
    resourceQuery()
      .where(where)
      .orderBy(...order)
      .limit(f.limit ?? 25)
      .offset(f.offset ?? 0),
    db
      .select({ n: sql<number>`count(*)::int` })
      .from(resources)
      .leftJoin(subjects, eq(resources.subjectId, subjects.id))
      .where(where),
  ]);
  return { items, total: totalRows[0]?.n ?? 0 };
}

export async function getResourcesForSubject(subjectId: number) {
  await ensureDb();
  return resourceQuery()
    .where(eq(resources.subjectId, subjectId))
    .orderBy(desc(resources.year), asc(resources.unitNo), asc(resources.examLabel), asc(resources.id));
}

export async function getResourcesForSemester(semesterId: number, type?: ResourceType) {
  await ensureDb();
  const where = type ? and(eq(resources.semesterId, semesterId), eq(resources.type, type)) : eq(resources.semesterId, semesterId);
  return resourceQuery()
    .where(where)
    .orderBy(asc(subjects.sortOrder), desc(resources.year), asc(resources.unitNo), asc(resources.examLabel), asc(resources.id));
}

export async function getSemesterLevelResources(semesterId: number) {
  await ensureDb();
  return resourceQuery()
    .where(and(eq(resources.semesterId, semesterId), sql`${resources.subjectId} is null`))
    .orderBy(asc(resources.type), desc(resources.id));
}

export async function getRecentResources(limit = 8, opts: { uploadsOnly?: boolean } = {}) {
  await ensureDb();
  const where = opts.uploadsOnly ? or(eq(resources.source, "upload"), eq(resources.source, "link")) : ne(resources.source, "generated");
  return resourceQuery().where(where).orderBy(desc(resources.createdAt), desc(resources.id)).limit(limit);
}

export async function getResourceById(id: number) {
  await ensureDb();
  const [row] = await resourceQuery().where(eq(resources.id, id)).limit(1);
  return row ?? null;
}

/* ---------------- Timetable & exams ---------------- */

export async function getUpcomingExams(limit = 6, semesterIds?: number[]) {
  await ensureDb();
  if (semesterIds && !semesterIds.length) return [];
  const conds: SQL[] = [gte(exams.examDate, todayISO())];
  if (semesterIds) conds.push(inArray(exams.semesterId, semesterIds));
  return db
    .select({
      id: exams.id,
      examType: exams.examType,
      examDate: exams.examDate,
      startTime: exams.startTime,
      endTime: exams.endTime,
      venue: exams.venue,
      title: exams.title,
      subjectId: exams.subjectId,
      subjectName: subjects.name,
      subjectCode: subjects.code,
      semesterNumber: semesters.number,
      programSlug: programs.slug,
      programShort: programs.shortName,
      programSort: programs.sortOrder,
      aliasLabel: aliasLabelSql(exams.semesterId),
    })
    .from(exams)
    .innerJoin(semesters, eq(exams.semesterId, semesters.id))
    .innerJoin(programs, eq(semesters.programId, programs.id))
    .leftJoin(subjects, eq(exams.subjectId, subjects.id))
    .where(and(...conds))
    .orderBy(asc(exams.examDate), asc(exams.startTime), asc(programs.sortOrder), asc(semesters.number), asc(subjects.sortOrder))
    .limit(limit);
}

export async function getTimetableData(semesterId: number) {
  await ensureDb();
  const [subs, slots, examRows] = await Promise.all([
    db.select().from(subjects).where(eq(subjects.semesterId, semesterId)).orderBy(asc(subjects.sortOrder), asc(subjects.id)),
    db
      .select({
        id: classSlots.id,
        day: classSlots.day,
        startTime: classSlots.startTime,
        endTime: classSlots.endTime,
        subjectId: classSlots.subjectId,
        label: classSlots.label,
        kind: classSlots.kind,
        room: classSlots.room,
      })
      .from(classSlots)
      .where(eq(classSlots.semesterId, semesterId))
      .orderBy(asc(classSlots.day), asc(classSlots.startTime)),
    db
      .select({
        id: exams.id,
        examType: exams.examType,
        examDate: exams.examDate,
        startTime: exams.startTime,
        endTime: exams.endTime,
        venue: exams.venue,
        title: exams.title,
        subjectId: exams.subjectId,
      })
      .from(exams)
      .where(eq(exams.semesterId, semesterId))
      .orderBy(asc(exams.examDate), asc(exams.startTime)),
  ]);
  return { subjects: subs, slots, exams: examRows };
}

export type TimetableData = Awaited<ReturnType<typeof getTimetableData>>;
