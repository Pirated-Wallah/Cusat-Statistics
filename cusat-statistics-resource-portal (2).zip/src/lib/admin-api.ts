import { NextResponse, type NextRequest } from "next/server";
import { and, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureDb } from "@/db/bootstrap";
import { classSlots, exams, files, programs, resources, semesters, subjects, syllabusUnits } from "@/db/schema";
import { ADMIN_COOKIE, adminCookieOptions, adminToken, checkPassword, isAdminRequest } from "./auth";
import { EXAM_TYPES, PAPER_TYPES, SITE, SLOT_KINDS, SUBJECT_KINDS, isResourceType, type ResourceType } from "./site";
import { toRoman } from "./utils";

type Tx = Parameters<Parameters<typeof db.transaction>[0]>[0];
type Subject = typeof subjects.$inferSelect;

class HttpError extends Error {
  constructor(
    message: string,
    readonly status = 400,
  ) {
    super(message);
  }
}

const ok = (data: Record<string, unknown> = {}) => NextResponse.json({ ok: true, ...data });
const fail = (error: string, status = 400) => NextResponse.json({ error }, { status });

const str = (fd: FormData, key: string, max = 500) => {
  const v = fd.get(key);
  return typeof v === "string" ? v.trim().slice(0, max) : "";
};
const int = (fd: FormData, key: string) => {
  const v = str(fd, key, 20);
  if (!v) return null;
  const n = Number(v);
  return Number.isFinite(n) ? Math.trunc(n) : null;
};
const fileFrom = (fd: FormData, key = "file") => {
  const v = fd.get(key);
  return v && typeof v !== "string" && v.size > 0 ? v : null;
};

const TIME_RE = /^([01]\d|2[0-3]):[0-5]\d$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;

/** MIME type is derived from the extension (never trusted from the client). */
const MIME_BY_EXT: Record<string, string> = {
  pdf: "application/pdf",
  doc: "application/msword",
  docx: "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ppt: "application/vnd.ms-powerpoint",
  pptx: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  xls: "application/vnd.ms-excel",
  xlsx: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  txt: "text/plain; charset=utf-8",
  png: "image/png",
  jpg: "image/jpeg",
  jpeg: "image/jpeg",
  webp: "image/webp",
  zip: "application/zip",
};

async function storeFile(tx: Tx, file: File) {
  if (file.size > SITE.maxUploadMb * 1024 * 1024) throw new HttpError(`File is larger than ${SITE.maxUploadMb} MB.`);
  const name = (file.name || "file").slice(-200);
  const ext = name.includes(".") ? (name.split(".").pop() ?? "").toLowerCase() : "";
  const mimeType = MIME_BY_EXT[ext];
  if (!mimeType) throw new HttpError("Unsupported file type. Upload a PDF, Word, PowerPoint, Excel, image, text or ZIP file.");
  const data = Buffer.from(await file.arrayBuffer());
  const [row] = await tx.insert(files).values({ filename: name, mimeType, size: data.length, data }).returning({ id: files.id });
  return row.id;
}

function validUrl(raw: string) {
  try {
    const u = new URL(raw);
    if (u.protocol !== "http:" && u.protocol !== "https:") throw new Error("bad protocol");
    return u.toString();
  } catch {
    throw new HttpError("Paste a valid link starting with http:// or https://");
  }
}

async function cleanupOrphanFiles() {
  await db.execute(sql`DELETE FROM files f WHERE NOT EXISTS (SELECT 1 FROM resources r WHERE r.file_id = f.id)`);
}

function autoTitle(
  type: ResourceType,
  semLabel: string,
  sub: Subject | undefined,
  o: { unitNo: number | null; year: number | null; examLabel: string | null },
) {
  const name = sub?.name ?? semLabel;
  switch (type) {
    case "notes":
      return `${name} - ${o.unitNo ? `Module ${toRoman(o.unitNo)} ` : ""}Notes`;
    case "pyq":
      return `${name} - ${o.examLabel ?? "End Semester"}${o.year ? ` ${o.year}` : ""}`;
    case "internal":
      return `${sub?.code ?? name} ${o.examLabel ?? "Internal Test"}${o.year ? ` - ${o.year}` : ""}`;
    case "syllabus":
      return sub ? `${sub.code} ${sub.name} - Official Syllabus` : `${semLabel} - Official Syllabus`;
    case "timetable":
      return `${semLabel} - ${o.examLabel || "Official Timetable"}`;
    default:
      return name;
  }
}

async function loadSemester(id: number) {
  const [row] = await db
    .select({ sem: semesters, programName: programs.name })
    .from(semesters)
    .innerJoin(programs, eq(semesters.programId, programs.id))
    .where(eq(semesters.id, id))
    .limit(1);
  return row ? { ...row.sem, programName: row.programName } : null;
}

/**
 * Returns the semester that holds the content. Linked semesters (e.g. Integrated
 * M.Sc. Sem 7) resolve to their target (M.Sc. Sem 1) so material is stored once.
 */
async function getSemester(id: number | null) {
  if (!id) throw new HttpError("Choose a semester.");
  const sem = await loadSemester(id);
  if (!sem) throw new HttpError("That semester no longer exists.", 404);
  if (sem.linkedSemesterId) {
    const target = await loadSemester(sem.linkedSemesterId);
    if (target) return target;
  }
  return sem;
}

async function getSubjectInSemester(subjectId: number, semesterId: number) {
  const [sub] = await db
    .select()
    .from(subjects)
    .where(and(eq(subjects.id, subjectId), eq(subjects.semesterId, semesterId)))
    .limit(1);
  if (!sub) throw new HttpError("That paper does not belong to the selected semester.");
  return sub;
}

/* ---------------- Resources ---------------- */

async function createResource(fd: FormData) {
  const type = str(fd, "type", 20);
  if (!isResourceType(type)) throw new HttpError("Choose what kind of material this is.");
  const sem = await getSemester(int(fd, "semesterId"));
  const subjectId = int(fd, "subjectId");
  const sub = subjectId ? await getSubjectInSemester(subjectId, sem.id) : undefined;
  if (!sub && PAPER_TYPES.includes(type)) throw new HttpError("Select the paper this material belongs to.");

  const mode = str(fd, "mode", 10) || "file";
  const unitNo = type === "notes" ? int(fd, "unitNo") : null;
  const year = type === "pyq" || type === "internal" ? int(fd, "year") : null;
  if (year !== null && (year < 1990 || year > 2100)) throw new HttpError("Enter a valid exam year.");
  const examLabel = type === "pyq" || type === "internal" || type === "timetable" ? str(fd, "examLabel", 120) || null : null;
  const isBook = type === "textbook";
  const author = isBook ? str(fd, "author", 200) || null : null;
  const publisher = isBook ? str(fd, "publisher", 120) || null : null;
  const edition = isBook ? str(fd, "edition", 60) || null : null;
  const isOpenAccess = isBook && fd.get("isOpenAccess") === "on";
  const description = str(fd, "description", 500);
  let title = str(fd, "title", 200);
  if (!title) {
    if (isBook) throw new HttpError("Enter the book title.");
    title = autoTitle(type, `${sem.programName} Semester ${sem.number}`, sub, { unitNo, year, examLabel });
  }

  const file = mode === "file" ? fileFrom(fd) : null;
  if (mode === "file" && !file) throw new HttpError("Choose a file to upload.");
  const url = mode === "link" ? validUrl(str(fd, "url", 2000)) : null;
  if (mode === "none" && !isBook) throw new HttpError("Upload a file or paste a link.");

  const id = await db.transaction(async (tx) => {
    const fileId = file ? await storeFile(tx, file) : null;
    const [row] = await tx
      .insert(resources)
      .values({
        semesterId: sem.id,
        subjectId: sub?.id ?? null,
        type,
        title,
        description,
        source: fileId ? "upload" : url ? "link" : "none",
        fileId,
        externalUrl: url,
        unitNo,
        year,
        examLabel,
        author,
        publisher,
        edition,
        isOpenAccess,
      })
      .returning({ id: resources.id });
    return row.id;
  });
  return ok({ id, message: "Published." });
}

async function attachFile(id: number, fd: FormData) {
  if (!Number.isInteger(id)) throw new HttpError("Invalid item.");
  const [r] = await db.select().from(resources).where(eq(resources.id, id)).limit(1);
  if (!r) throw new HttpError("This item no longer exists.", 404);
  const file = fileFrom(fd);
  const rawUrl = str(fd, "url", 2000);
  if (!file && !rawUrl) throw new HttpError("Choose a file or paste a link.");
  const url = file ? null : validUrl(rawUrl);
  await db.transaction(async (tx) => {
    const fileId = file ? await storeFile(tx, file) : null;
    await tx
      .update(resources)
      .set({ source: fileId ? "upload" : "link", fileId, externalUrl: url, isSample: false })
      .where(eq(resources.id, id));
    if (r.fileId && r.fileId !== fileId) await tx.delete(files).where(eq(files.id, r.fileId));
  });
  return ok({ message: "File saved." });
}

async function clearSamples() {
  const rows = await db.delete(resources).where(eq(resources.isSample, true)).returning({ id: resources.id });
  await cleanupOrphanFiles();
  return ok({ message: `Removed ${rows.length} sample items.` });
}

/* ---------------- Semesters & papers ---------------- */

async function saveSemester(id: number | null, fd: FormData) {
  const title = str(fd, "title", 150);
  const session = str(fd, "session", 100);
  const description = str(fd, "description", 500);
  if (id === null) {
    const programId = int(fd, "programId");
    const [prog] = programId ? await db.select().from(programs).where(eq(programs.id, programId)).limit(1) : [];
    if (!prog) throw new HttpError("Choose the programme.");
    const number = int(fd, "number");
    if (!number || number < 1 || number > 12) throw new HttpError("Enter a semester number between 1 and 12.");
    const [exists] = await db
      .select({ id: semesters.id })
      .from(semesters)
      .where(and(eq(semesters.programId, prog.id), eq(semesters.number, number)))
      .limit(1);
    if (exists) throw new HttpError(`${prog.name} already has a Semester ${number}.`);
    const linkId = int(fd, "linkedSemesterId");
    let linkedSemesterId: number | null = null;
    if (linkId) {
      const target = await loadSemester(linkId);
      if (!target || target.linkedSemesterId) throw new HttpError("Pick a semester that has its own papers to share with.");
      linkedSemesterId = target.id;
    }
    const [row] = await db
      .insert(semesters)
      .values({ programId: prog.id, number, title: title || `Semester ${number}`, session, description, linkedSemesterId })
      .returning({ id: semesters.id });
    if (!linkedSemesterId) {
      const label = `${prog.name} Semester ${number}`;
      await db.insert(resources).values([
        {
          semesterId: row.id,
          type: "syllabus",
          title: `${label} - Complete Syllabus (all papers)`,
          description: "Every paper of the semester with module-wise topics and textbooks, in one PDF.",
          source: "generated",
        },
        {
          semesterId: row.id,
          type: "timetable",
          title: `${label} - Class & Exam Timetable`,
          description: "Weekly class schedule plus internal tests, practicals and end-semester exam dates.",
          source: "generated",
        },
      ]);
    }
    return ok({ id: row.id, message: `Semester ${number} created.` });
  }
  if (!title) throw new HttpError("Title is required.");
  await db.update(semesters).set({ title, session, description }).where(eq(semesters.id, id));
  return ok({ message: "Semester updated." });
}

async function saveSubject(id: number | null, fd: FormData) {
  const code = str(fd, "code", 30).toUpperCase();
  const name = str(fd, "name", 150);
  const shortName = str(fd, "shortName", 20);
  const kind = str(fd, "kind", 20) || "core";
  const credits = int(fd, "credits") ?? 4;
  const faculty = str(fd, "faculty", 100);
  const description = str(fd, "description", 600);
  if (!code || !name) throw new HttpError("Paper code and name are required.");
  if (!SUBJECT_KINDS[kind]) throw new HttpError("Choose a valid paper type.");
  if (credits < 0 || credits > 20) throw new HttpError("Credits must be between 0 and 20.");

  if (id === null) {
    const sem = await getSemester(int(fd, "semesterId"));
    const [{ maxOrder }] = await db
      .select({ maxOrder: sql<number>`coalesce(max(${subjects.sortOrder}), 0)::int` })
      .from(subjects)
      .where(eq(subjects.semesterId, sem.id));
    const [row] = await db
      .insert(subjects)
      .values({ semesterId: sem.id, code, name, shortName: shortName || code, kind, credits, faculty, description, sortOrder: maxOrder + 1 })
      .returning({ id: subjects.id });
    await db.insert(resources).values({
      semesterId: sem.id,
      subjectId: row.id,
      type: "syllabus",
      title: `${code} ${name} - Syllabus`,
      description: "Module-wise syllabus with prescribed textbooks.",
      source: "generated",
    });
    return ok({ id: row.id, message: "Paper added." });
  }

  const sortOrder = int(fd, "sortOrder");
  const [updated] = await db
    .update(subjects)
    .set({ code, name, shortName: shortName || code, kind, credits, faculty, description, ...(sortOrder !== null ? { sortOrder } : {}) })
    .where(eq(subjects.id, id))
    .returning({ id: subjects.id });
  if (!updated) throw new HttpError("This paper no longer exists.", 404);
  await db
    .update(resources)
    .set({ title: `${code} ${name} - Syllabus` })
    .where(and(eq(resources.subjectId, id), eq(resources.type, "syllabus"), eq(resources.source, "generated")));
  return ok({ message: "Paper updated." });
}

function unitFields(fd: FormData) {
  const title = str(fd, "title", 200);
  if (!title) throw new HttpError("Module title is required.");
  const topics = str(fd, "topics", 6000)
    .split(/\r?\n/)
    .map((t) => t.replace(/^\s*(?:[-*\u2022]|\d+[.)])\s*/, "").trim())
    .filter(Boolean)
    .join("\n");
  const hours = Math.max(0, Math.min(300, int(fd, "hours") ?? 0));
  const unitNo = int(fd, "unitNo");
  if (unitNo !== null && (unitNo < 1 || unitNo > 50)) throw new HttpError("Module number must be between 1 and 50.");
  return { title, topics, hours, unitNo };
}

async function addUnit(subjectId: number, fd: FormData) {
  if (!Number.isInteger(subjectId)) throw new HttpError("Invalid paper.");
  const [sub] = await db.select({ id: subjects.id }).from(subjects).where(eq(subjects.id, subjectId)).limit(1);
  if (!sub) throw new HttpError("This paper no longer exists.", 404);
  const f = unitFields(fd);
  let unitNo = f.unitNo;
  if (!unitNo) {
    const [{ maxNo }] = await db
      .select({ maxNo: sql<number>`coalesce(max(${syllabusUnits.unitNo}), 0)::int` })
      .from(syllabusUnits)
      .where(eq(syllabusUnits.subjectId, subjectId));
    unitNo = maxNo + 1;
  }
  await db.insert(syllabusUnits).values({ subjectId, unitNo, title: f.title, topics: f.topics, hours: f.hours });
  return ok({ message: "Module added." });
}

async function updateUnit(id: number, fd: FormData) {
  if (!Number.isInteger(id)) throw new HttpError("Invalid module.");
  const f = unitFields(fd);
  await db
    .update(syllabusUnits)
    .set({ title: f.title, topics: f.topics, hours: f.hours, ...(f.unitNo ? { unitNo: f.unitNo } : {}) })
    .where(eq(syllabusUnits.id, id));
  return ok({ message: "Module saved." });
}

/* ---------------- Timetable ---------------- */

async function addSlot(fd: FormData) {
  const sem = await getSemester(int(fd, "semesterId"));
  const day = int(fd, "day");
  if (!day || day < 1 || day > 6) throw new HttpError("Choose a day (Monday to Saturday).");
  const startTime = str(fd, "startTime", 5);
  const endTime = str(fd, "endTime", 5);
  if (!TIME_RE.test(startTime) || !TIME_RE.test(endTime) || startTime >= endTime) throw new HttpError("Enter a valid start and end time.");
  const subjectId = int(fd, "subjectId");
  const label = str(fd, "label", 60);
  if (subjectId) await getSubjectInSemester(subjectId, sem.id);
  if (!subjectId && !label) throw new HttpError("Choose a paper or enter a label (e.g. Library).");
  const kind = str(fd, "kind", 20) || "theory";
  if (!SLOT_KINDS[kind]) throw new HttpError("Choose a valid class type.");
  const room = str(fd, "room", 60);
  const overlap = await db
    .select({ id: classSlots.id })
    .from(classSlots)
    .where(
      and(
        eq(classSlots.semesterId, sem.id),
        eq(classSlots.day, day),
        sql`${classSlots.startTime} < ${endTime}`,
        sql`${classSlots.endTime} > ${startTime}`,
      ),
    )
    .limit(1);
  if (overlap.length) throw new HttpError("This time overlaps another class on the same day. Delete that class first.");
  await db.insert(classSlots).values({ semesterId: sem.id, day, startTime, endTime, subjectId: subjectId ?? null, label, kind, room });
  return ok({ message: "Class added to the timetable." });
}

async function addExam(fd: FormData) {
  const sem = await getSemester(int(fd, "semesterId"));
  const examType = str(fd, "examType", 20);
  if (!EXAM_TYPES[examType]) throw new HttpError("Choose the exam type.");
  const examDate = str(fd, "examDate", 10);
  if (!DATE_RE.test(examDate)) throw new HttpError("Choose the exam date.");
  const startTime = str(fd, "startTime", 5);
  const endTime = str(fd, "endTime", 5);
  if (!TIME_RE.test(startTime) || !TIME_RE.test(endTime) || startTime >= endTime) throw new HttpError("Enter a valid start and end time.");
  const subjectId = int(fd, "subjectId");
  const title = str(fd, "title", 120);
  if (subjectId) await getSubjectInSemester(subjectId, sem.id);
  if (!subjectId && !title) throw new HttpError("Choose a paper or enter a title for the exam.");
  const venue = str(fd, "venue", 80);
  await db.insert(exams).values({ semesterId: sem.id, examType, subjectId: subjectId ?? null, title, examDate, startTime, endTime, venue });
  return ok({ message: "Exam scheduled." });
}

/* ---------------- Dispatchers (used by /api/admin/* route files) ---------------- */

export async function handleAdminPost(req: NextRequest, path: string[]) {
  const [a, b, c] = path;
  try {
    await ensureDb();
    if (a === "login") {
      const fd = await req.formData().catch(() => new FormData());
      const password = str(fd, "password", 200);
      if (!password || !checkPassword(password)) return fail("Incorrect password.", 401);
      const res = ok({ message: "Logged in." });
      res.cookies.set(ADMIN_COOKIE, adminToken(), adminCookieOptions(req, 60 * 60 * 24 * 30));
      return res;
    }
    if (a === "logout") {
      const res = ok({ message: "Logged out." });
      res.cookies.set(ADMIN_COOKIE, "", adminCookieOptions(req, 0));
      return res;
    }
    if (!isAdminRequest(req)) return fail("Your admin session has expired. Please log in again.", 401);

    const fd = await req.formData().catch(() => new FormData());
    if (a === "resources" && !b) return await createResource(fd);
    if (a === "resources" && b === "clear-samples") return await clearSamples();
    if (a === "resources" && b && c === "file") return await attachFile(Number(b), fd);
    if (a === "semesters" && !c) return await saveSemester(b ? Number(b) : null, fd);
    if (a === "subjects" && b && c === "units") return await addUnit(Number(b), fd);
    if (a === "subjects" && !c) return await saveSubject(b ? Number(b) : null, fd);
    if (a === "units" && b && !c) return await updateUnit(Number(b), fd);
    if (a === "slots" && !b) return await addSlot(fd);
    if (a === "exams" && !b) return await addExam(fd);
    return fail("Not found", 404);
  } catch (err) {
    if (err instanceof HttpError) return fail(err.message, err.status);
    console.error("Admin API error", err);
    return fail("Something went wrong on the server.", 500);
  }
}

export async function handleAdminDelete(req: NextRequest, path: string[]) {
  const [a, b] = path;
  const id = Number(b);
  try {
    await ensureDb();
    if (!isAdminRequest(req)) return fail("Your admin session has expired. Please log in again.", 401);
    if (!Number.isInteger(id)) return fail("Invalid id.");
    switch (a) {
      case "resources": {
        const [r] = await db.delete(resources).where(eq(resources.id, id)).returning({ fileId: resources.fileId });
        if (!r) return fail("This item no longer exists.", 404);
        if (r.fileId) await db.delete(files).where(eq(files.id, r.fileId));
        return ok({ message: "Deleted." });
      }
      case "semesters":
        await db.delete(semesters).where(eq(semesters.id, id));
        await cleanupOrphanFiles();
        return ok({ message: "Semester deleted." });
      case "subjects":
        // Remove the paper's timetable entries too, so no unlabeled slots/exams are left behind.
        await db.delete(classSlots).where(eq(classSlots.subjectId, id));
        await db.delete(exams).where(eq(exams.subjectId, id));
        await db.delete(subjects).where(eq(subjects.id, id));
        await cleanupOrphanFiles();
        return ok({ message: "Paper deleted." });
      case "units":
        await db.delete(syllabusUnits).where(eq(syllabusUnits.id, id));
        return ok({ message: "Module deleted." });
      case "slots":
        await db.delete(classSlots).where(eq(classSlots.id, id));
        return ok({ message: "Class removed." });
      case "exams":
        await db.delete(exams).where(eq(exams.id, id));
        return ok({ message: "Exam removed." });
      default:
        return fail("Not found", 404);
    }
  } catch (err) {
    console.error("Admin API error", err);
    return fail("Something went wrong on the server.", 500);
  }
}
