import { createHmac, timingSafeEqual } from "node:crypto";
import { cookies } from "next/headers";
import type { NextRequest } from "next/server";

export const ADMIN_COOKIE = "semhub_admin";

export function adminPassword() {
  return process.env.ADMIN_PASSWORD?.trim() || "admin123";
}

export function usingDefaultPassword() {
  return !process.env.ADMIN_PASSWORD?.trim();
}

function secret() {
  return process.env.ADMIN_SECRET || `semhub-v1:${adminPassword()}`;
}

export function adminToken() {
  return createHmac("sha256", secret()).update("semhub-admin-session").digest("hex");
}

function safeEqual(a: string, b: string) {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && timingSafeEqual(x, y);
}

export function isValidToken(token?: string | null) {
  return !!token && safeEqual(token, adminToken());
}

export function checkPassword(password: string) {
  return safeEqual(password, adminPassword());
}

/** For server components / pages. */
export async function isAdmin() {
  const store = await cookies();
  return isValidToken(store.get(ADMIN_COOKIE)?.value);
}

/** For route handlers. */
export function isAdminRequest(req: NextRequest) {
  return isValidToken(req.cookies.get(ADMIN_COOKIE)?.value);
}

/**
 * Over HTTPS we use SameSite=None + Partitioned so that admin login also works
 * when the portal is embedded in an iframe (e.g. a preview pane).
 */
export function adminCookieOptions(req: NextRequest, maxAge: number) {
  const proto = (req.headers.get("x-forwarded-proto") ?? req.nextUrl.protocol.replace(":", ""))
    .split(",")[0]
    .trim();
  const https = proto === "https";
  return {
    httpOnly: true,
    path: "/",
    maxAge,
    sameSite: https ? ("none" as const) : ("lax" as const),
    secure: https,
    partitioned: https,
  };
}
