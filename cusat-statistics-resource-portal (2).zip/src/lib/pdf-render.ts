import { and, asc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { classSlots, exams, programs, resources, semesters, subjects, syllabusUnits, type Resource } from "@/db/schema";
import {
  hashSeed,
  notesPdf,
  programmeSyllabusPdf,
  questionPaperPdf,
  semesterSyllabusPdf,
  syllabusPdf,
  timetablePdf,
  type SemesterInfo,
  type SyllabusSubject,
} from "./pdf-docs";
import { SITE } from "./site";
import { slugify, toRoman } from "./utils";

export type PdfFile = { bytes: Uint8Array<ArrayBuffer>; filename: string };

/**
 * Header info for a semester plus the id of the semester that holds its content
 * (a linked semester - e.g. Integrated Sem 7 - resolves to M.Sc. Sem 1).
 */
async function semesterContext(semesterId: number): Promise<{ info: SemesterInfo; contentId: number } | null> {
  const [row] = await db
    .select({ semester: semesters, program: programs })
    .from(semesters)
    .innerJoin(programs, eq(semesters.programId, programs.id))
    .where(eq(semesters.id, semesterId))
    .limit(1);
  if (!row) return null;
  let contentId = row.semester.id;
  let note: string | undefined;
  if (row.semester.linkedSemesterId) {
    const [target] = await db
      .select({ semester: semesters, program: programs })
      .from(semesters)
      .innerJoin(programs, eq(semesters.programId, programs.id))
      .where(eq(semesters.id, row.semester.linkedSemesterId))
      .limit(1);
    if (target) {
      contentId = target.semester.id;
      note = `Joint semester - same papers and exams as ${target.program.name} Semester ${toRoman(target.semester.number)}`;
    }
  } else {
    const shared = await db
      .select({ number: semesters.number, name: programs.name })
      .from(semesters)
      .innerJoin(programs, eq(semesters.programId, programs.id))
      .where(eq(semesters.linkedSemesterId, row.semester.id))
      .orderBy(asc(programs.sortOrder));
    if (shared.length) note = `Common to ${shared.map((s) => `${s.name} Semester ${toRoman(s.number)}`).join(", ")}`;
  }
  return {
    contentId,
    info: {
      programName: row.program.name,
      programShort: row.program.shortName || row.program.name,
      number: row.semester.number,
      title: row.semester.title,
      session: row.semester.session,
      institution: row.program.institution || SITE.institution,
      department: row.program.department || SITE.department,
      note,
    },
  };
}

/** Papers (with modules and textbooks) of the given content semesters. */
async function loadPapers(contentIds: number[]) {
  const out = new Map<number, SyllabusSubject[]>();
  const ids = Array.from(new Set(contentIds));
  if (!ids.length) return out;
  const subs = await db
    .select()
    .from(subjects)
    .where(inArray(subjects.semesterId, ids))
    .orderBy(asc(subjects.sortOrder), asc(subjects.id));
  const subjectIds = subs.map((s) => s.id);
  const [units, books] = subjectIds.length
    ? await Promise.all([
        db.select().from(syllabusUnits).where(inArray(syllabusUnits.subjectId, subjectIds)).orderBy(asc(syllabusUnits.unitNo), asc(syllabusUnits.id)),
        db
          .select()
          .from(resources)
          .where(and(inArray(resources.subjectId, subjectIds), eq(resources.type, "textbook")))
          .orderBy(asc(resources.id)),
      ])
    : [[], []];
  for (const id of ids) out.set(id, []);
  for (const s of subs) {
    out.get(s.semesterId)?.push({
      code: s.code,
      name: s.name,
      kind: s.kind,
      credits: s.credits,
      faculty: s.faculty,
      description: s.description,
      units: units.filter((u) => u.subjectId === s.id),
      books: books.filter((b) => b.subjectId === s.id),
    });
  }
  return out;
}

const semFile = (info: SemesterInfo, what: string) => `${slugify(`${info.programShort} semester ${info.number} ${what}`)}.pdf`;

export async function renderSubjectSyllabus(subjectId: number): Promise<PdfFile | null> {
  const [sub] = await db.select().from(subjects).where(eq(subjects.id, subjectId)).limit(1);
  if (!sub) return null;
  const ctx = await semesterContext(sub.semesterId);
  if (!ctx) return null;
  const paper = (await loadPapers([sub.semesterId])).get(sub.semesterId)?.find((p) => p.code === sub.code && p.name === sub.name);
  if (!paper) return null;
  const bytes = await syllabusPdf(ctx.info, paper);
  return { bytes, filename: `${slugify(`${sub.code} ${sub.name} syllabus`)}.pdf` };
}

export async function renderSemesterSyllabus(semesterId: number): Promise<PdfFile | null> {
  const ctx = await semesterContext(semesterId);
  if (!ctx) return null;
  const papers = (await loadPapers([ctx.contentId])).get(ctx.contentId) ?? [];
  const bytes = await semesterSyllabusPdf(ctx.info, papers);
  return { bytes, filename: semFile(ctx.info, "complete syllabus") };
}

export async function renderProgrammeSyllabus(slug: string): Promise<PdfFile | null> {
  const [prog] = await db.select().from(programs).where(eq(programs.slug, slug)).limit(1);
  if (!prog) return null;
  const sems = await db.select().from(semesters).where(eq(semesters.programId, prog.id)).orderBy(asc(semesters.number));
  const contexts = (await Promise.all(sems.map((s) => semesterContext(s.id)))).filter((c): c is NonNullable<typeof c> => !!c);
  const papers = await loadPapers(contexts.map((c) => c.contentId));
  const bytes = await programmeSyllabusPdf(
    {
      name: prog.name,
      shortName: prog.shortName,
      institution: prog.institution || SITE.institution,
      department: prog.department || SITE.department,
      description: prog.description,
      durationYears: prog.durationYears,
      totalSemesters: prog.totalSemesters,
    },
    contexts.map((c) => ({ info: c.info, papers: papers.get(c.contentId) ?? [] })),
  );
  return { bytes, filename: `${slugify(`${prog.name} programme syllabus`)}.pdf` };
}

export async function renderTimetable(semesterId: number): Promise<PdfFile | null> {
  const ctx = await semesterContext(semesterId);
  if (!ctx) return null;
  const id = ctx.contentId;
  const [subs, slots, examRows] = await Promise.all([
    db.select().from(subjects).where(eq(subjects.semesterId, id)).orderBy(asc(subjects.sortOrder), asc(subjects.id)),
    db.select().from(classSlots).where(eq(classSlots.semesterId, id)).orderBy(asc(classSlots.day), asc(classSlots.startTime)),
    db.select().from(exams).where(eq(exams.semesterId, id)).orderBy(asc(exams.examDate), asc(exams.startTime)),
  ]);
  const bytes = await timetablePdf({ semester: ctx.info, subjects: subs, slots, exams: examRows });
  return { bytes, filename: semFile(ctx.info, "timetable") };
}

/** Renders the PDF for a resource whose source is "generated". */
export async function renderResourcePdf(r: Resource): Promise<PdfFile | null> {
  if (r.type === "syllabus") return r.subjectId ? renderSubjectSyllabus(r.subjectId) : renderSemesterSyllabus(r.semesterId);
  if (r.type === "timetable") return renderTimetable(r.semesterId);
  if (!r.subjectId) return null;
  const [sub] = await db.select().from(subjects).where(eq(subjects.id, r.subjectId)).limit(1);
  if (!sub) return null;
  const ctx = await semesterContext(sub.semesterId);
  if (!ctx) return null;
  const units = await db
    .select()
    .from(syllabusUnits)
    .where(eq(syllabusUnits.subjectId, sub.id))
    .orderBy(asc(syllabusUnits.unitNo), asc(syllabusUnits.id));
  const filename = `${slugify(r.title)}.pdf`;
  if (r.type === "notes") {
    const unit = units.find((u) => u.unitNo === r.unitNo) ?? units[0];
    if (!unit) return null;
    const bytes = await notesPdf({ semester: ctx.info, subject: sub, unit, seed: hashSeed("notes", r.id), sample: r.isSample });
    return { bytes, filename };
  }
  if (r.type === "pyq" || r.type === "internal") {
    const bytes = await questionPaperPdf({
      kind: r.type,
      semester: ctx.info,
      subject: sub,
      units,
      year: r.year,
      examLabel: r.examLabel,
      seed: hashSeed(r.type, r.subjectId, r.year, r.examLabel, r.id),
      sample: r.isSample,
    });
    return { bytes, filename };
  }
  return null;
}

export function fileResponse(body: Uint8Array<ArrayBuffer>, mime: string, filename: string, download: boolean) {
  const ascii = filename.replace(/[^\w.\- ]+/g, "_");
  return new Response(body, {
    headers: {
      "Content-Type": mime,
      "Content-Length": String(body.byteLength),
      "Content-Disposition": `${download ? "attachment" : "inline"}; filename="${ascii}"; filename*=UTF-8''${encodeURIComponent(filename)}`,
      "Cache-Control": "private, no-cache",
      "X-Content-Type-Options": "nosniff",
    },
  });
}
