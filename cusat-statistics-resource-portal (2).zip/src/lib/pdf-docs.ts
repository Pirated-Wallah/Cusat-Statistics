import { C, PdfWriter } from "./pdf";
import { DAYS, EXAM_TYPES, SITE, SLOT_KINDS, SUBJECT_KINDS } from "./site";
import { activeDays, buildColumns } from "./timetable";
import { formatDate, formatTime, internalTestNo, internalUnitRange, splitTopics, toRoman, weekdayName } from "./utils";

/* ------------------------------------------------------------------ */
/* Shared types & helpers                                              */
/* ------------------------------------------------------------------ */

export type SemesterInfo = {
  programName: string;
  programShort: string;
  number: number;
  title: string;
  session: string;
  institution: string;
  department: string;
  /** e.g. "Common to Integrated M.Sc. Statistics Semester VII" */
  note?: string;
};
export type UnitLike = { unitNo: number; title: string; topics: string; hours: number };
export type BookLike = {
  title: string;
  author: string | null;
  publisher: string | null;
  edition: string | null;
  isOpenAccess: boolean;
  externalUrl: string | null;
};
export type SyllabusSubject = {
  code: string;
  name: string;
  kind: string;
  credits: number;
  faculty: string;
  description: string;
  units: UnitLike[];
  books: BookLike[];
};
export type ProgrammeInfo = {
  name: string;
  shortName: string;
  institution: string;
  department: string;
  description: string;
  durationYears: number;
  totalSemesters: number;
};

const kindLabel = (kind: string) => SUBJECT_KINDS[kind]?.label ?? kind;
const semLine = (sem: SemesterInfo) => `${sem.programName} | Semester ${toRoman(sem.number)}`;
const bookLine = (b: BookLike) => [b.title, b.author, b.publisher, b.edition].filter(Boolean).join(", ");

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function hashSeed(...parts: Array<string | number | null | undefined>) {
  let h = 2166136261;
  for (const ch of parts.join("|")) {
    h ^= ch.charCodeAt(0);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function shuffle<T>(arr: T[], r: () => number) {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(r() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const pick = <T,>(arr: T[], r: () => number) => arr[Math.floor(r() * arr.length)];
const range = (n: number) => Array.from({ length: n }, (_, i) => i);

const SHORT_Q = ["Define {a}.", "What is meant by {a}?", "Write a short note on {a}.", "Briefly explain {a}.", "Give one application of {a}."];
const MID_Q = [
  "Explain {a} with a suitable example.",
  "Describe {a} in detail.",
  "Discuss {a} and illustrate it with an example.",
  "State and explain the main results on {a}.",
  "Write short notes on: (i) {a}  (ii) {b}",
];
const LONG_Q = [
  "Explain {a} in detail. Illustrate with a numerical example.",
  "Discuss {a}. State the assumptions involved and derive the main results.",
  "(i) Explain {a}.  (ii) Discuss {b}.",
  "Describe {a} and {b}. Compare them.",
];
const PROG_Q = ["Write a {lang} program to illustrate {a} and interpret the output.", "With a {lang} example, explain {a}."];
const PROGRAMMING = /programming|python|computing|data analytics|data science|machine learning|\bin r\b|using r\b|with r\b/i;
const MATHS =
  /math|numerical|calculus|algebra|analysis|probab|statist|inference|distribution|sampling|regression|stochastic|multivariate|design|experiment|estimation|testing|time series|quality|reliability|lifetime|demograph|survey|decision|operations|index/i;
const progLang = (name: string) => (/python/i.test(name) ? "Python" : /\bR\b/.test(name) ? "R" : "R or Python");

function questionMaker(units: UnitLike[], r: () => number, lang: string) {
  const decks = units.map((u) => shuffle(splitTopics(u.topics), r)).filter((d) => d.length);
  const idx = decks.map(() => 0);
  const draw = (unitIndex: number) => {
    if (!decks.length) return "the topics of this paper";
    const k = unitIndex % decks.length;
    const topic = decks[k][idx[k] % decks[k].length];
    idx[k]++;
    return topic;
  };
  return (templates: string[], unitIndex: number) => {
    const tpl = pick(templates, r);
    const a = draw(unitIndex);
    const b = tpl.includes("{b}") ? draw(unitIndex) : "";
    return tpl.replace("{a}", a).replace("{b}", b).replace("{lang}", lang);
  };
}

function labQuestion(topic: string) {
  const t = topic.trim().replace(/\.$/, "");
  if (/^program to /i.test(t)) return `Write a program to ${t.slice(11)}.`;
  return `${t}: carry out the computations (by hand or using R / Python) and record the results.`;
}

function semesterHeader(w: PdfWriter, sem: SemesterInfo) {
  w.text(sem.institution.toUpperCase(), { size: 8.5, font: "b", color: C.muted });
  w.text(`${sem.department}  |  ${semLine(sem)}  |  ${sem.session}`, { size: 9, color: C.muted });
  if (sem.note) w.text(sem.note, { size: 8.5, font: "i", color: C.brand });
  w.space(6);
}

/* ------------------------------------------------------------------ */
/* Syllabus                                                             */
/* ------------------------------------------------------------------ */

function writeSyllabusBody(w: PdfWriter, sem: SemesterInfo, s: SyllabusSubject) {
  const isLab = s.kind === "lab";
  const isProject = s.kind === "project";
  semesterHeader(w, sem);
  w.text(`${s.code}: ${s.name}`, { size: 18, font: "b", gap: 8 });
  const totalHours = s.units.reduce((acc, u) => acc + (u.hours || 0), 0);
  w.table(
    ["Course code", "Type", "Credits", "Teaching hours", "Faculty"],
    [[s.code, kindLabel(s.kind), String(s.credits), totalHours ? `${totalHours} hours` : "-", s.faculty || "-"]],
    [0.2, 0.2, 0.12, 0.18, 0.3],
  );
  if (s.description) {
    w.heading("Course description", 3);
    w.text(s.description, { size: 10, color: C.body, gap: 2 });
  }
  w.heading(isLab ? "List of practicals" : isProject ? "Project details" : "Course content", 2);
  if (!s.units.length) w.text("The syllabus has not been added yet.", { size: 10, font: "i", color: C.muted });
  for (const unit of s.units) {
    w.ensure(44);
    w.twoCol(isLab || isProject ? unit.title : `MODULE ${toRoman(unit.unitNo)}   ${unit.title}`, unit.hours ? `${unit.hours} Hours` : "", {
      size: 10.5,
      font: "b",
      color: C.brand,
    });
    const topics = splitTopics(unit.topics);
    if (isLab) w.numbered(topics.map(labQuestion));
    else if (isProject) w.bullets(topics);
    else if (topics.length) w.text(`${topics.join("; ")}.`, { size: 10, color: C.body });
    w.space(6);
  }
  const prescribed = s.books.filter((b) => !b.isOpenAccess);
  const open = s.books.filter((b) => b.isOpenAccess);
  if (prescribed.length) {
    w.heading("Textbooks and references", 2);
    w.numbered(prescribed.map(bookLine));
  }
  if (open.length) {
    w.heading("Free open-access books", 3);
    w.numbered(open.map((b) => `${bookLine(b)}${b.externalUrl ? ` - ${b.externalUrl}` : ""}`));
  }
}

export async function syllabusPdf(sem: SemesterInfo, subject: SyllabusSubject) {
  const w = await PdfWriter.create({
    title: `${subject.code} ${subject.name} - Syllabus`,
    footer: `${SITE.name} | ${sem.programShort} Semester ${sem.number} | ${subject.code} ${subject.name} - Syllabus`,
  });
  writeSyllabusBody(w, sem, subject);
  return w.finish();
}

function schemeTable(w: PdfWriter, papers: SyllabusSubject[]) {
  const credits = papers.reduce((acc, p) => acc + p.credits, 0);
  w.table(
    ["#", "Code", "Paper", "Type", "Credits", "Modules"],
    [
      ...papers.map((p, i) => [String(i + 1), p.code, p.name, kindLabel(p.kind), String(p.credits), String(p.units.length)]),
      ["", "", "Total credits", "", String(credits), ""],
    ],
    [0.06, 0.16, 0.42, 0.16, 0.1, 0.1],
    { size: 9, zebra: true, boldLast: true },
  );
}

export async function semesterSyllabusPdf(sem: SemesterInfo, papers: SyllabusSubject[]) {
  const w = await PdfWriter.create({
    title: `${sem.programName} Semester ${sem.number} - Complete Syllabus`,
    footer: `${SITE.name} | ${sem.programShort} Semester ${sem.number} | Complete syllabus`,
  });
  w.space(40);
  w.text(sem.institution.toUpperCase(), { size: 10, font: "b", color: C.muted, align: "center" });
  w.text(sem.department, { size: 10, color: C.muted, align: "center", gap: 10 });
  w.text(sem.programName, { size: 15, font: "b", align: "center", gap: 6 });
  w.text(`Semester ${toRoman(sem.number)} - Complete Syllabus`, { size: 24, font: "b", color: C.brand, align: "center", gap: 6 });
  w.text(sem.title, { size: 11, color: C.body, align: "center" });
  w.text(sem.session, { size: 10, color: C.muted, align: "center" });
  if (sem.note) w.text(sem.note, { size: 10, font: "i", color: C.brand, align: "center" });
  w.space(20);
  w.heading("Scheme of papers", 2);
  if (papers.length) schemeTable(w, papers);
  else w.text("Papers have not been added yet.", { size: 10, font: "i", color: C.muted });
  for (const paper of papers) {
    w.addPage();
    writeSyllabusBody(w, sem, paper);
  }
  return w.finish();
}

export async function programmeSyllabusPdf(prog: ProgrammeInfo, sems: Array<{ info: SemesterInfo; papers: SyllabusSubject[] }>) {
  const w = await PdfWriter.create({
    title: `${prog.name} - Programme Structure & Syllabus`,
    footer: `${SITE.name} | ${prog.name} | Programme structure & syllabus`,
  });
  w.space(40);
  w.text(prog.institution.toUpperCase(), { size: 10, font: "b", color: C.muted, align: "center" });
  w.text(prog.department, { size: 10, color: C.muted, align: "center", gap: 12 });
  w.text(prog.name, { size: 26, font: "b", color: C.brand, align: "center", gap: 4 });
  w.text("Programme Structure & Syllabus", { size: 14, font: "b", align: "center", gap: 4 });
  w.text(`${prog.durationYears} years  |  ${prog.totalSemesters} semesters`, { size: 10, color: C.muted, align: "center", gap: 14 });
  if (prog.description) w.text(prog.description, { size: 10, color: C.body, gap: 10 });
  w.heading("Scheme of the programme", 2);
  for (const s of sems) {
    w.heading(`Semester ${toRoman(s.info.number)}${s.info.note ? ` - ${s.info.note}` : ""}`, 3);
    if (s.papers.length) schemeTable(w, s.papers);
    else w.text("Papers have not been added yet.", { size: 9.5, font: "i", color: C.muted, gap: 6 });
  }
  for (const s of sems) {
    for (const paper of s.papers) {
      w.addPage();
      writeSyllabusBody(w, s.info, paper);
    }
  }
  return w.finish();
}

/* ------------------------------------------------------------------ */
/* Timetable                                                            */
/* ------------------------------------------------------------------ */

export type TimetableInput = {
  semester: SemesterInfo;
  subjects: Array<{ id: number; code: string; name: string; shortName: string; faculty: string }>;
  slots: Array<{ day: number; startTime: string; endTime: string; subjectId: number | null; label: string; kind: string; room: string }>;
  exams: Array<{ examType: string; examDate: string; startTime: string; endTime: string; subjectId: number | null; title: string; venue: string }>;
};

export async function timetablePdf(t: TimetableInput) {
  const sem = t.semester;
  const w = await PdfWriter.create({
    title: `${sem.programName} Semester ${sem.number} - Timetable`,
    footer: `${SITE.name} | ${sem.programShort} Semester ${sem.number} | Class & exam timetable`,
    landscape: true,
  });
  const subjectById = new Map(t.subjects.map((s) => [s.id, s]));
  const nameOf = (id: number | null, fallback: string) => {
    const s = id ? subjectById.get(id) : undefined;
    return s ? s.shortName || s.code : fallback || "-";
  };

  w.text(sem.institution.toUpperCase(), { size: 8.5, font: "b", color: C.muted });
  w.text(`${sem.programName} - Semester ${toRoman(sem.number)} - Class Timetable`, { size: 18, font: "b" });
  w.text(`${sem.session}${sem.note ? `  |  ${sem.note}` : ""}`, { size: 9.5, color: C.muted, gap: 8 });

  if (!t.slots.length) {
    w.text("The weekly class timetable has not been published yet.", { size: 10, font: "i", color: C.muted, gap: 8 });
  } else {
    const cols = buildColumns(t.slots).filter((c) => c.used);
    const days = activeDays(t.slots);
    const rows = days.map((day) => {
      const daySlots = t.slots.filter((s) => s.day === day);
      return [
        DAYS[day],
        ...cols.map((c) => {
          const s = daySlots.find((x) => x.startTime <= c.start && x.endTime >= c.end);
          if (!s) return "-";
          const name = nameOf(s.subjectId, s.label);
          if (s.startTime < c.start) return `${name} (contd.)`;
          const kind = s.kind !== "theory" ? ` [${SLOT_KINDS[s.kind] ?? s.kind}]` : "";
          return `${name}${kind}${s.room ? `\n${s.room}` : ""}`;
        }),
      ];
    });
    const dayW = 0.11;
    const colW = (1 - dayW) / Math.max(1, cols.length);
    w.table(["Day", ...cols.map((c) => `${formatTime(c.start)} - ${formatTime(c.end)}`)], rows, [dayW, ...cols.map(() => colW)], {
      size: 8.5,
      zebra: true,
      minRowHeight: 30,
    });
  }

  if (t.subjects.length) {
    w.heading("Papers & faculty", 3);
    w.table(
      ["Code", "Paper", "Short name", "Faculty"],
      t.subjects.map((s) => [s.code, s.name, s.shortName || "-", s.faculty || "-"]),
      [0.16, 0.46, 0.14, 0.24],
      { size: 8.5, zebra: true },
    );
  }

  w.addPage();
  w.text(`${sem.programName} - Semester ${toRoman(sem.number)} - Exam Timetable`, { size: 18, font: "b", gap: 6 });
  const groups = Object.entries(EXAM_TYPES)
    .sort((a, b) => a[1].order - b[1].order)
    .map(([key, meta]) => ({ meta, items: t.exams.filter((e) => e.examType === key) }))
    .filter((g) => g.items.length);
  if (!groups.length) w.text("No exams have been scheduled yet.", { size: 10, font: "i", color: C.muted });
  for (const g of groups) {
    w.heading(g.meta.label, 2);
    w.table(
      ["Date", "Day", "Time", "Code", "Paper", "Venue"],
      g.items
        .slice()
        .sort((a, b) => (a.examDate + a.startTime).localeCompare(b.examDate + b.startTime))
        .map((e) => {
          const s = e.subjectId ? subjectById.get(e.subjectId) : undefined;
          return [
            formatDate(e.examDate, "long"),
            weekdayName(e.examDate),
            `${formatTime(e.startTime)} - ${formatTime(e.endTime)}`,
            s?.code ?? "-",
            s?.name ?? (e.title || "-"),
            e.venue || "-",
          ];
        }),
      [0.16, 0.11, 0.17, 0.13, 0.31, 0.12],
      { size: 9, zebra: true },
    );
  }
  return w.finish();
}

/* ------------------------------------------------------------------ */
/* Question papers (PYQ / internal / practical)                         */
/* ------------------------------------------------------------------ */

export type PaperInput = {
  kind: "pyq" | "internal";
  semester: SemesterInfo;
  subject: { code: string; name: string; kind: string };
  units: UnitLike[];
  year: number | null;
  examLabel: string | null;
  seed: number;
  sample: boolean;
};

export async function questionPaperPdf(p: PaperInput) {
  const r = mulberry32(p.seed);
  const isLab = p.subject.kind === "lab";
  const prog = PROGRAMMING.test(p.subject.name);
  const lang = progLang(p.subject.name);
  const month = (p.examLabel?.match(/\(([^)]+)\)/)?.[1] ?? "").toUpperCase();
  const year = p.year ? String(p.year) : "";
  const w = await PdfWriter.create({
    title: `${p.subject.code} ${p.subject.name} - ${p.examLabel ?? "Question paper"} ${year}`,
    footer: `${SITE.name} | ${p.subject.code} ${p.subject.name} | ${p.examLabel ?? "Question paper"} ${year}`,
    watermark: p.sample ? "SAMPLE" : undefined,
  });
  if (p.sample) {
    w.callout(
      "Sample paper auto-generated from the syllabus for practice. Replace it with the original question paper from Admin > Upload.",
      "amber",
    );
  }
  w.twoCol("Reg. No. : ________________________", `Course Code: ${p.subject.code}`, { size: 9.5, color: C.body });
  w.space(8);
  w.text(p.semester.institution.toUpperCase(), { size: 11, font: "b", align: "center" });
  w.text(`${p.semester.programName.toUpperCase()} - SEMESTER ${toRoman(p.semester.number)}`, { size: 10.5, font: "b", align: "center" });

  if (p.kind === "internal") {
    const testNo = internalTestNo(p.examLabel);
    const [from, to] = internalUnitRange(p.units.length, testNo);
    const scoped = p.units.filter((u) => u.unitNo >= from && u.unitNo <= to);
    const units = scoped.length ? scoped : p.units;
    const make = questionMaker(units, r, lang);
    w.text(`CONTINUOUS EVALUATION - ${(p.examLabel ?? "Internal Test").toUpperCase()}${year ? ` - ${year}` : ""}`, {
      size: 10.5,
      font: "b",
      align: "center",
    });
    w.text(`${p.subject.code}: ${p.subject.name.toUpperCase()}`, { size: 12, font: "b", align: "center", gap: 6 });
    w.twoCol("Time: 1 Hour 30 Minutes", "Maximum Marks: 25", { size: 10, font: "b" });
    w.text(`Portion: Module ${toRoman(from)}${to > from ? ` to Module ${toRoman(to)}` : ""}`, {
      size: 9.5,
      font: "i",
      color: C.muted,
      align: "center",
    });
    w.rule();
    w.section("PART A - (5 x 2 = 10 Marks)", "Answer ALL questions.");
    w.questions(range(5).map((i) => ({ text: make(SHORT_Q, i), marks: "2" })), 1);
    w.section("PART B - (3 x 5 = 15 Marks)", "Answer any THREE questions.");
    w.questions(range(4).map((i) => ({ text: make(prog && r() < 0.35 ? PROG_Q : MID_Q, i), marks: "5" })), 6);
  } else if (isLab) {
    w.text(`PRACTICAL EXAMINATION${month ? `, ${month}` : ""} ${year}`.trim(), { size: 10.5, font: "b", align: "center" });
    w.text(`${p.subject.code}: ${p.subject.name.toUpperCase()}`, { size: 12, font: "b", align: "center", gap: 6 });
    w.twoCol("Time: 3 Hours", "Maximum Marks: 50", { size: 10, font: "b" });
    w.rule();
    const experiments = shuffle(p.units.flatMap((u) => splitTopics(u.topics)), r).slice(0, 8);
    w.section("QUESTIONS", "Each candidate is allotted ONE question by lot. Use R / Python / spreadsheet as directed.");
    w.questions(experiments.map((e) => ({ text: labQuestion(e), marks: "35" })), 1);
    w.heading("Scheme of valuation", 3);
    w.table(
      ["Component", "Marks"],
      [
        ["Formulae, method and program / procedure", "15"],
        ["Computation, correct results and interpretation", "20"],
        ["Viva voce", "10"],
        ["Practical record", "5"],
        ["Total", "50"],
      ],
      [0.75, 0.25],
      { size: 9.5, boldLast: true },
    );
  } else {
    const make = questionMaker(p.units, r, lang);
    w.text(`END SEMESTER EXAMINATION${month ? `, ${month}` : ""} ${year}`.trim(), { size: 10.5, font: "b", align: "center" });
    w.text(`${p.subject.code}: ${p.subject.name.toUpperCase()}`, { size: 12, font: "b", align: "center", gap: 6 });
    w.twoCol("Time: 3 Hours", "Maximum Marks: 50", { size: 10, font: "b" });
    w.rule();
    w.section("PART A - (5 x 2 = 10 Marks)", "Answer ALL questions.");
    w.questions(range(5).map((i) => ({ text: make(SHORT_Q, i), marks: "2" })), 1);
    const n = Math.max(1, p.units.length);
    const count = n === 5 ? 5 : 4;
    const each = n === 5 ? 8 : 10;
    w.section(`PART B - (${count} x ${each} = 40 Marks)`, "Answer either (a) or (b) from each module.");
    for (let i = 0; i < count; i++) {
      const ui = i % n;
      const unit = p.units[ui];
      const label = unit ? `MODULE ${toRoman(unit.unitNo)}` : `QUESTION ${i + 1}`;
      const tplA = prog && r() < 0.3 ? PROG_Q : LONG_Q;
      w.orQuestion(6 + i, label, make(tplA, ui), make(each >= 10 ? LONG_Q : MID_Q, ui), String(each));
    }
  }
  w.space(10);
  w.text("* * * * *", { align: "center", color: C.muted });
  return w.finish();
}

/* ------------------------------------------------------------------ */
/* Notes (module revision guide / lab record index)                    */
/* ------------------------------------------------------------------ */

export type NotesInput = {
  semester: SemesterInfo;
  subject: { code: string; name: string; kind: string; faculty: string };
  unit: UnitLike;
  seed: number;
  sample: boolean;
};

function revisionPrompt(subjectName: string) {
  if (PROGRAMMING.test(subjectName)) return "Revise: the idea, key functions / syntax in R or Python, a short worked example and how to interpret the output.";
  if (MATHS.test(subjectName)) return "Revise: definitions, statements of results with their conditions, outline of the derivation / proof and one solved numerical problem.";
  return "Revise: definition, explanation in points, an example and applications.";
}

function examTips(subjectName: string) {
  if (PROGRAMMING.test(subjectName))
    return [
      "Practise writing code for every topic and interpret the output in words - marks are given for interpretation.",
      "Keep a one-page sheet of the functions / commands used in each module.",
      "Trace the output of short code snippets by hand before the exam.",
      "Solve previous year papers - many questions repeat with small changes.",
    ];
  if (MATHS.test(subjectName))
    return [
      "Write the statement of every theorem with all its conditions before starting the proof.",
      "Show each step of derivations and numerical work - partial marks are awarded.",
      "Practise at least three numerical problems from every module and interpret the answers.",
      "Solve previous year papers to learn the module-wise either/or question pattern.",
    ];
  return [
    "Begin each answer with a crisp definition, then explain in points.",
    "Use headings and underline keywords so answers are easy to evaluate.",
    "Add examples or neat diagrams wherever relevant.",
    "Solve previous year papers to understand the question pattern.",
  ];
}

export async function notesPdf(p: NotesInput) {
  const r = mulberry32(p.seed);
  const isLab = p.subject.kind === "lab";
  const topics = splitTopics(p.unit.topics);
  const title = isLab ? `${p.unit.title} - Lab Record Index` : `Module ${toRoman(p.unit.unitNo)}: ${p.unit.title}`;
  const w = await PdfWriter.create({
    title: `${p.subject.code} ${title}`,
    footer: `${SITE.name} | ${p.subject.code} ${p.subject.name} | ${title}`,
    watermark: p.sample ? "SAMPLE" : undefined,
  });
  if (p.sample) {
    w.callout(
      isLab
        ? "Sample lab record index generated from the syllabus. Upload your practical record or manual from Admin > Upload to replace it."
        : "Sample revision guide generated from the syllabus. Upload your class notes from Admin > Upload to replace it.",
      "brand",
    );
  }
  w.text(`${p.semester.programShort} SEMESTER ${toRoman(p.semester.number)}  |  ${p.subject.code}  |  ${p.subject.name.toUpperCase()}`, {
    size: 9,
    font: "b",
    color: C.muted,
  });
  if (p.semester.note) w.text(p.semester.note, { size: 8.5, font: "i", color: C.brand });
  w.text(title, { size: 18, font: "b", gap: 2 });
  w.text(`${isLab ? "Practical" : "Teaching"} hours: ${p.unit.hours || "-"}   |   Faculty: ${p.subject.faculty || "-"}`, {
    size: 9.5,
    color: C.muted,
    gap: 6,
  });

  if (isLab) {
    w.table(
      ["No.", "Practical", "Date", "Page", "Signature"],
      topics.map((t, i) => [String(i + 1), t, "", "", ""]),
      [0.07, 0.55, 0.13, 0.1, 0.15],
      { size: 9.5, minRowHeight: 28 },
    );
    w.heading("Record writing format", 2);
    w.bullets([
      "Aim - what the practical is expected to do.",
      "Formulae / procedure - the statistical method used.",
      "Data and computations - neatly tabulated, or the R / Python code used.",
      "Results - the final values, tables or plots.",
      "Inference - interpretation of the results in words.",
    ]);
    w.heading("Common viva questions", 2);
    w.bullets([
      ...shuffle(topics, r)
        .slice(0, 3)
        .map((t) => `Explain the method you used for: ${t}.`),
      "What assumptions does your method need, and how did you check them?",
      "How would you interpret the result for a non-statistician?",
    ]);
    return w.finish();
  }

  w.heading("Topics checklist", 2);
  w.checklist(topics);
  w.heading("Key points to revise", 2);
  topics.forEach((t, i) => {
    w.text(`${i + 1}. ${t}`, { size: 10.5, font: "b", gap: 1 });
    w.text(revisionPrompt(p.subject.name), { size: 9.5, color: C.body, indent: 14, gap: 5 });
  });
  const make = questionMaker([p.unit], r, progLang(p.subject.name));
  w.heading("Important questions", 2);
  w.text("2 marks", { size: 10, font: "b", color: C.brand, gap: 2 });
  const shortCount = Math.min(5, Math.max(3, topics.length));
  w.questions(range(shortCount).map(() => ({ text: make(SHORT_Q, 0), marks: "2" })), 1);
  w.text("5 marks", { size: 10, font: "b", color: C.brand, gap: 2 });
  w.questions(range(3).map(() => ({ text: make(MID_Q, 0), marks: "5" })), shortCount + 1);
  w.text("10 marks", { size: 10, font: "b", color: C.brand, gap: 2 });
  w.questions(range(2).map(() => ({ text: make(LONG_Q, 0), marks: "10" })), shortCount + 4);
  w.heading("Exam tips", 2);
  w.bullets(examTips(p.subject.name));
  w.heading("My notes", 2);
  w.ruledLines(8);
  return w.finish();
}
