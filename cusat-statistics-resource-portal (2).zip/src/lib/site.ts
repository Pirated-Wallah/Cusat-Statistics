export const SITE = {
  name: "SemHub",
  institution: "Cochin University of Science and Technology",
  institutionShort: "CUSAT",
  department: "Department of Statistics",
  tagline:
    "Notes, previous year papers, internal papers, textbooks, syllabus and timetables for M.Sc. Statistics and the Five-Year Integrated M.Sc. Statistics.",
  timeZone: "Asia/Kolkata",
  maxUploadMb: 50,
};

export const RESOURCE_TYPES = ["notes", "pyq", "internal", "textbook", "syllabus", "timetable"] as const;
export type ResourceType = (typeof RESOURCE_TYPES)[number];

/** Types that always belong to a specific paper (subject). */
export const PAPER_TYPES: ResourceType[] = ["notes", "pyq", "internal", "textbook"];

export function isResourceType(value: unknown): value is ResourceType {
  return typeof value === "string" && (RESOURCE_TYPES as readonly string[]).includes(value);
}

export const TYPE_META: Record<
  ResourceType,
  { label: string; plural: string; short: string; description: string; badge: string; iconWrap: string; bar: string }
> = {
  notes: {
    label: "Notes",
    plural: "Notes",
    short: "Notes",
    description: "Module-wise class notes, revision guides and lab records",
    badge: "bg-indigo-50 text-indigo-700 ring-indigo-600/20",
    iconWrap: "bg-indigo-100 text-indigo-600",
    bar: "bg-indigo-500",
  },
  pyq: {
    label: "PYQ",
    plural: "Previous Year Papers",
    short: "PYQs",
    description: "End-semester and practical question papers from past years",
    badge: "bg-amber-50 text-amber-800 ring-amber-600/20",
    iconWrap: "bg-amber-100 text-amber-700",
    bar: "bg-amber-500",
  },
  internal: {
    label: "Internal Paper",
    plural: "Internal Papers",
    short: "Internals",
    description: "Continuous evaluation test papers (Test I, Test II)",
    badge: "bg-emerald-50 text-emerald-700 ring-emerald-600/20",
    iconWrap: "bg-emerald-100 text-emerald-700",
    bar: "bg-emerald-500",
  },
  textbook: {
    label: "Textbook",
    plural: "Textbooks",
    short: "Textbooks",
    description: "Prescribed textbooks, reference books and free PDF books",
    badge: "bg-sky-50 text-sky-700 ring-sky-600/20",
    iconWrap: "bg-sky-100 text-sky-700",
    bar: "bg-sky-500",
  },
  syllabus: {
    label: "Syllabus",
    plural: "Syllabus",
    short: "Syllabus",
    description: "Module-wise syllabus PDF for every paper",
    badge: "bg-violet-50 text-violet-700 ring-violet-600/20",
    iconWrap: "bg-violet-100 text-violet-700",
    bar: "bg-violet-500",
  },
  timetable: {
    label: "Timetable",
    plural: "Timetables",
    short: "Timetable",
    description: "Weekly class schedule and exam timetable",
    badge: "bg-rose-50 text-rose-700 ring-rose-600/20",
    iconWrap: "bg-rose-100 text-rose-700",
    bar: "bg-rose-500",
  },
};

export const SUBJECT_KINDS: Record<string, { label: string; badge: string }> = {
  core: { label: "Core", badge: "bg-slate-100 text-slate-700 ring-slate-500/20" },
  elective: { label: "Elective", badge: "bg-cyan-50 text-cyan-700 ring-cyan-600/20" },
  lab: { label: "Practical", badge: "bg-teal-50 text-teal-700 ring-teal-600/20" },
  project: { label: "Project", badge: "bg-purple-50 text-purple-700 ring-purple-600/20" },
  minor: { label: "Minor", badge: "bg-blue-50 text-blue-700 ring-blue-600/20" },
  aec: { label: "Ability Enhancement", badge: "bg-orange-50 text-orange-700 ring-orange-600/20" },
  sec: { label: "Skill Enhancement", badge: "bg-fuchsia-50 text-fuchsia-700 ring-fuchsia-600/20" },
};

export const EXAM_TYPES: Record<string, { label: string; order: number; badge: string }> = {
  internal1: { label: "Internal Test I", order: 1, badge: "bg-emerald-50 text-emerald-700 ring-emerald-600/20" },
  internal2: { label: "Internal Test II", order: 2, badge: "bg-teal-50 text-teal-700 ring-teal-600/20" },
  model: { label: "Model Exam", order: 3, badge: "bg-sky-50 text-sky-700 ring-sky-600/20" },
  practical: { label: "Practical Exam", order: 4, badge: "bg-violet-50 text-violet-700 ring-violet-600/20" },
  semester: { label: "End Semester Exam", order: 5, badge: "bg-rose-50 text-rose-700 ring-rose-600/20" },
  viva: { label: "Project Viva Voce", order: 6, badge: "bg-purple-50 text-purple-700 ring-purple-600/20" },
};

/** Index 1..6 = Monday..Saturday */
export const DAYS = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

export const SLOT_KINDS: Record<string, string> = {
  theory: "Theory",
  lab: "Lab",
  tutorial: "Tutorial",
  activity: "Activity",
};

export const SEM_THEMES = [
  { gradient: "from-indigo-500 via-indigo-600 to-violet-600", soft: "bg-indigo-50 text-indigo-700", text: "text-indigo-600", ring: "ring-indigo-200", dot: "bg-indigo-500" },
  { gradient: "from-emerald-500 via-emerald-600 to-teal-600", soft: "bg-emerald-50 text-emerald-700", text: "text-emerald-600", ring: "ring-emerald-200", dot: "bg-emerald-500" },
  { gradient: "from-amber-500 via-orange-500 to-orange-600", soft: "bg-amber-50 text-amber-800", text: "text-amber-600", ring: "ring-amber-200", dot: "bg-amber-500" },
  { gradient: "from-rose-500 via-rose-600 to-pink-600", soft: "bg-rose-50 text-rose-700", text: "text-rose-600", ring: "ring-rose-200", dot: "bg-rose-500" },
  { gradient: "from-sky-500 via-sky-600 to-blue-600", soft: "bg-sky-50 text-sky-700", text: "text-sky-600", ring: "ring-sky-200", dot: "bg-sky-500" },
  { gradient: "from-violet-500 via-purple-600 to-fuchsia-600", soft: "bg-violet-50 text-violet-700", text: "text-violet-600", ring: "ring-violet-200", dot: "bg-violet-500" },
];

export function semTheme(semesterNumber: number) {
  const len = SEM_THEMES.length;
  return SEM_THEMES[(((semesterNumber - 1) % len) + len) % len];
}

export const PROGRAM_THEMES = [
  { gradient: "from-indigo-600 via-violet-600 to-purple-600", soft: "bg-indigo-50 text-indigo-700", text: "text-indigo-600", ring: "ring-indigo-200", dot: "bg-indigo-500", border: "border-indigo-200" },
  { gradient: "from-emerald-500 via-teal-600 to-cyan-600", soft: "bg-emerald-50 text-emerald-700", text: "text-emerald-600", ring: "ring-emerald-200", dot: "bg-emerald-500", border: "border-emerald-200" },
  { gradient: "from-amber-500 via-orange-500 to-rose-500", soft: "bg-amber-50 text-amber-800", text: "text-amber-600", ring: "ring-amber-200", dot: "bg-amber-500", border: "border-amber-200" },
];

/** Theme by programme sort order (1-based). */
export function programTheme(sortOrder: number) {
  const len = PROGRAM_THEMES.length;
  const i = Math.max(0, sortOrder - 1);
  return PROGRAM_THEMES[i % len];
}

/** Colours for papers inside the timetable grid. */
export const SUBJECT_COLORS = [
  "bg-sky-50 border-sky-200 text-sky-900",
  "bg-violet-50 border-violet-200 text-violet-900",
  "bg-emerald-50 border-emerald-200 text-emerald-900",
  "bg-amber-50 border-amber-200 text-amber-900",
  "bg-rose-50 border-rose-200 text-rose-900",
  "bg-teal-50 border-teal-200 text-teal-900",
  "bg-orange-50 border-orange-200 text-orange-900",
  "bg-fuchsia-50 border-fuchsia-200 text-fuchsia-900",
];
