import { PDFDocument, StandardFonts, degrees, rgb, type PDFFont, type PDFPage } from "pdf-lib";
import { SITE } from "./site";

type Color = ReturnType<typeof rgb>;
type FontKey = "r" | "b" | "i";

export const C = {
  ink: rgb(0.06, 0.09, 0.16),
  body: rgb(0.2, 0.25, 0.33),
  muted: rgb(0.42, 0.46, 0.54),
  line: rgb(0.82, 0.85, 0.89),
  brand: rgb(0.31, 0.27, 0.9),
  brandSoft: rgb(0.93, 0.93, 1),
  soft: rgb(0.96, 0.97, 0.98),
  white: rgb(1, 1, 1),
  amberBg: rgb(1, 0.97, 0.88),
  amberInk: rgb(0.57, 0.25, 0.05),
  red: rgb(0.86, 0.15, 0.15),
};

/** Standard PDF fonts only support WinAnsi - normalise text to plain ASCII. */
export function clean(text: string): string {
  return text
    .replace(/[\u2018\u2019\u201A\u2032]/g, "'")
    .replace(/[\u201C\u201D\u201E\u2033]/g, '"')
    .replace(/[\u2013\u2014\u2212]/g, "-")
    .replace(/\u2026/g, "...")
    .replace(/[\u2022\u00B7]/g, "-")
    .replace(/\u2192/g, "->")
    .replace(/\u2264/g, "<=")
    .replace(/\u2265/g, ">=")
    .replace(/\u00D7/g, "x")
    .replace(/\t/g, " ")
    .replace(/[^\x20-\x7E\n]/g, "");
}

type TextOpts = {
  size?: number;
  font?: FontKey;
  color?: Color;
  indent?: number;
  gap?: number;
  align?: "left" | "center" | "right";
};

type WriterOpts = { title: string; footer: string; landscape?: boolean; watermark?: string };

export class PdfWriter {
  page!: PDFPage;
  y = 0;
  readonly margin = 46;

  private constructor(
    readonly doc: PDFDocument,
    readonly fonts: Record<FontKey, PDFFont>,
    readonly size: [number, number],
    readonly opts: WriterOpts,
  ) {}

  static async create(opts: WriterOpts) {
    const doc = await PDFDocument.create();
    doc.setTitle(clean(opts.title));
    doc.setAuthor(SITE.name);
    doc.setCreator(SITE.name);
    doc.setProducer(SITE.name);
    const fonts = {
      r: await doc.embedFont(StandardFonts.Helvetica),
      b: await doc.embedFont(StandardFonts.HelveticaBold),
      i: await doc.embedFont(StandardFonts.HelveticaOblique),
    };
    const size: [number, number] = opts.landscape ? [841.89, 595.28] : [595.28, 841.89];
    const w = new PdfWriter(doc, fonts, size, opts);
    w.addPage();
    return w;
  }

  get width() {
    return this.size[0];
  }
  get height() {
    return this.size[1];
  }
  get contentWidth() {
    return this.width - this.margin * 2;
  }
  get bottom() {
    return this.margin + 16;
  }

  addPage() {
    this.page = this.doc.addPage(this.size);
    this.page.drawRectangle({ x: 0, y: this.height - 5, width: this.width, height: 5, color: C.brand });
    this.y = this.height - this.margin;
  }

  ensure(h: number) {
    if (this.y - h < this.bottom) this.addPage();
  }

  space(h: number) {
    this.y -= h;
  }

  wrap(text: string, font: PDFFont, size: number, maxWidth: number): string[] {
    const out: string[] = [];
    for (const para of clean(text).split("\n")) {
      const words = para.split(/\s+/).filter(Boolean);
      if (!words.length) {
        out.push("");
        continue;
      }
      let line = "";
      for (const word of words) {
        const candidate = line ? `${line} ${word}` : word;
        if (font.widthOfTextAtSize(candidate, size) <= maxWidth) {
          line = candidate;
          continue;
        }
        if (line) out.push(line);
        let rest = word;
        while (font.widthOfTextAtSize(rest, size) > maxWidth && rest.length > 1) {
          let k = rest.length - 1;
          while (k > 1 && font.widthOfTextAtSize(rest.slice(0, k), size) > maxWidth) k--;
          out.push(rest.slice(0, k));
          rest = rest.slice(k);
        }
        line = rest;
      }
      if (line) out.push(line);
    }
    return out;
  }

  text(text: string, o: TextOpts = {}) {
    const size = o.size ?? 10.5;
    const font = this.fonts[o.font ?? "r"];
    const indent = o.indent ?? 0;
    const lh = size * 1.4;
    for (const line of this.wrap(text, font, size, this.contentWidth - indent)) {
      this.ensure(lh);
      const tw = font.widthOfTextAtSize(line, size);
      let x = this.margin + indent;
      if (o.align === "center") x = this.margin + (this.contentWidth - tw) / 2;
      if (o.align === "right") x = this.margin + this.contentWidth - tw;
      this.page.drawText(line, { x, y: this.y - size * 0.85, size, font, color: o.color ?? C.ink });
      this.y -= lh;
    }
    this.y -= o.gap ?? 0;
  }

  twoCol(left: string, right: string, o: TextOpts = {}) {
    const size = o.size ?? 10;
    const font = this.fonts[o.font ?? "r"];
    const lh = size * 1.5;
    this.ensure(lh);
    const r = clean(right);
    this.page.drawText(clean(left), { x: this.margin, y: this.y - size * 0.85, size, font, color: o.color ?? C.ink });
    if (r) {
      const tw = font.widthOfTextAtSize(r, size);
      this.page.drawText(r, { x: this.margin + this.contentWidth - tw, y: this.y - size * 0.85, size, font, color: o.color ?? C.ink });
    }
    this.y -= lh + (o.gap ?? 0);
  }

  heading(text: string, level: 1 | 2 | 3 = 2) {
    const size = level === 1 ? 18 : level === 2 ? 12.5 : 11;
    this.ensure(size * 3);
    this.y -= level === 1 ? 4 : 10;
    this.text(text, { size, font: "b", color: level === 2 ? C.brand : C.ink });
    if (level === 2) {
      this.page.drawLine({
        start: { x: this.margin, y: this.y + 2 },
        end: { x: this.margin + 36, y: this.y + 2 },
        thickness: 1.5,
        color: C.brand,
      });
      this.y -= 6;
    } else {
      this.y -= 2;
    }
  }

  rule() {
    this.ensure(12);
    this.page.drawLine({
      start: { x: this.margin, y: this.y - 4 },
      end: { x: this.margin + this.contentWidth, y: this.y - 4 },
      thickness: 0.8,
      color: C.line,
    });
    this.y -= 12;
  }

  callout(text: string, tone: "amber" | "brand" = "brand") {
    const size = 9;
    const pad = 8;
    const lines = this.wrap(text, this.fonts.r, size, this.contentWidth - pad * 2);
    const lh = size * 1.4;
    const h = lines.length * lh + pad * 2;
    this.ensure(h + 8);
    this.page.drawRectangle({
      x: this.margin,
      y: this.y - h,
      width: this.contentWidth,
      height: h,
      color: tone === "amber" ? C.amberBg : C.brandSoft,
      borderColor: tone === "amber" ? rgb(0.98, 0.85, 0.55) : rgb(0.78, 0.78, 0.98),
      borderWidth: 0.8,
    });
    lines.forEach((line, i) =>
      this.page.drawText(line, {
        x: this.margin + pad,
        y: this.y - pad - size * 0.85 - i * lh,
        size,
        font: this.fonts.r,
        color: tone === "amber" ? C.amberInk : C.brand,
      }),
    );
    this.y -= h + 10;
  }

  section(title: string, instruction?: string) {
    this.ensure(46);
    this.y -= 6;
    this.text(title, { size: 11, font: "b", align: "center" });
    if (instruction) this.text(instruction, { size: 9.5, font: "i", color: C.muted, align: "center" });
    this.y -= 4;
  }

  /** Numbered questions with marks in the right margin. */
  questions(items: Array<{ text: string; marks?: string }>, startNo = 1) {
    const size = 10.5;
    const lh = size * 1.45;
    const numW = 26;
    const marksW = 34;
    const textW = this.contentWidth - numW - marksW;
    items.forEach((item, idx) => {
      const lines = this.wrap(item.text, this.fonts.r, size, textW);
      this.ensure(lines.length * lh + 4);
      const top = this.y;
      this.page.drawText(`${startNo + idx}.`, { x: this.margin, y: top - size * 0.85, size, font: this.fonts.b, color: C.ink });
      if (item.marks) {
        const m = `(${item.marks})`;
        const mw = this.fonts.r.widthOfTextAtSize(m, size - 1);
        this.page.drawText(m, { x: this.margin + this.contentWidth - mw, y: top - size * 0.85, size: size - 1, font: this.fonts.r, color: C.muted });
      }
      lines.forEach((line, k) =>
        this.page.drawText(line, { x: this.margin + numW, y: top - size * 0.85 - k * lh, size, font: this.fonts.r, color: C.ink }),
      );
      this.y -= lines.length * lh + 5;
    });
  }

  bullets(items: string[], size = 10) {
    const lh = size * 1.45;
    for (const item of items) {
      const lines = this.wrap(item, this.fonts.r, size, this.contentWidth - 16);
      this.ensure(lines.length * lh + 2);
      this.page.drawCircle({ x: this.margin + 4, y: this.y - size * 0.55, size: 1.8, color: C.brand });
      lines.forEach((line, k) =>
        this.page.drawText(line, { x: this.margin + 16, y: this.y - size * 0.85 - k * lh, size, font: this.fonts.r, color: C.body }),
      );
      this.y -= lines.length * lh + 3;
    }
  }

  numbered(items: string[], size = 10) {
    const lh = size * 1.45;
    items.forEach((item, i) => {
      const lines = this.wrap(item, this.fonts.r, size, this.contentWidth - 22);
      this.ensure(lines.length * lh + 2);
      this.page.drawText(`${i + 1}.`, { x: this.margin, y: this.y - size * 0.85, size, font: this.fonts.b, color: C.ink });
      lines.forEach((line, k) =>
        this.page.drawText(line, { x: this.margin + 22, y: this.y - size * 0.85 - k * lh, size, font: this.fonts.r, color: C.body }),
      );
      this.y -= lines.length * lh + 3;
    });
  }

  checklist(items: string[], size = 10) {
    const lh = size * 1.45;
    for (const item of items) {
      const lines = this.wrap(item, this.fonts.r, size, this.contentWidth - 20);
      this.ensure(lines.length * lh + 3);
      this.page.drawRectangle({ x: this.margin, y: this.y - size * 0.95, width: 8, height: 8, borderColor: C.brand, borderWidth: 0.9 });
      lines.forEach((line, k) =>
        this.page.drawText(line, { x: this.margin + 18, y: this.y - size * 0.85 - k * lh, size, font: this.fonts.r, color: C.body }),
      );
      this.y -= lines.length * lh + 4;
    }
  }

  ruledLines(count: number) {
    for (let i = 0; i < count; i++) {
      this.ensure(22);
      this.y -= 22;
      this.page.drawLine({
        start: { x: this.margin, y: this.y },
        end: { x: this.margin + this.contentWidth, y: this.y },
        thickness: 0.5,
        color: C.line,
      });
    }
    this.y -= 6;
  }

  table(headers: string[], rows: string[][], widths: number[], o: { size?: number; zebra?: boolean; minRowHeight?: number; boldLast?: boolean } = {}) {
    const size = o.size ?? 9;
    const pad = 4;
    const lh = size * 1.3;
    const colW = widths.map((f) => f * this.contentWidth);
    const drawRow = (cells: string[], header: boolean, fill?: Color, bold = false) => {
      const font = header || bold ? this.fonts.b : this.fonts.r;
      const lines = cells.map((c, i) => this.wrap(c || " ", font, size, colW[i] - pad * 2));
      const h = Math.max(o.minRowHeight ?? 0, Math.max(...lines.map((l) => l.length)) * lh + pad * 2);
      if (this.y - h < this.bottom) {
        this.addPage();
        if (!header) drawRow(headers, true, C.brand);
      }
      if (fill) this.page.drawRectangle({ x: this.margin, y: this.y - h, width: this.contentWidth, height: h, color: fill });
      let x = this.margin;
      cells.forEach((_, i) => {
        this.page.drawRectangle({ x, y: this.y - h, width: colW[i], height: h, borderColor: C.line, borderWidth: 0.6 });
        lines[i].forEach((line, k) =>
          this.page.drawText(line, {
            x: x + pad,
            y: this.y - pad - size * 0.85 - k * lh,
            size,
            font,
            color: header ? C.white : C.ink,
          }),
        );
        x += colW[i];
      });
      this.y -= h;
    };
    drawRow(headers, true, C.brand);
    rows.forEach((row, idx) =>
      drawRow(row, false, o.zebra && idx % 2 === 1 ? C.soft : undefined, !!o.boldLast && idx === rows.length - 1),
    );
    this.y -= 10;
  }

  /** Module-wise either/or question: "6. (a) ... OR (b) ..." with marks on the right. */
  orQuestion(no: number, heading: string, a: string, b: string, marks: string) {
    const size = 10.5;
    const lh = size * 1.45;
    const numW = 26;
    const tagW = 20;
    const marksW = 34;
    const textW = this.contentWidth - numW - tagW - marksW;
    const aLines = this.wrap(a, this.fonts.r, size, textW);
    const bLines = this.wrap(b, this.fonts.r, size, textW);
    this.ensure((aLines.length + bLines.length) * lh + 48);
    this.text(heading, { size: 8.5, font: "b", color: C.muted, align: "center", gap: 2 });
    const part = (tag: string, lines: string[], withNo: boolean) => {
      const top = this.y;
      const baseY = top - size * 0.85;
      if (withNo) this.page.drawText(`${no}.`, { x: this.margin, y: baseY, size, font: this.fonts.b, color: C.ink });
      this.page.drawText(tag, { x: this.margin + numW, y: baseY, size, font: this.fonts.b, color: C.ink });
      const m = `(${marks})`;
      const mw = this.fonts.r.widthOfTextAtSize(m, size - 1);
      this.page.drawText(m, { x: this.margin + this.contentWidth - mw, y: baseY, size: size - 1, font: this.fonts.r, color: C.muted });
      lines.forEach((line, k) =>
        this.page.drawText(line, { x: this.margin + numW + tagW, y: baseY - k * lh, size, font: this.fonts.r, color: C.ink }),
      );
      this.y -= lines.length * lh + 3;
    };
    part("(a)", aLines, true);
    this.text("OR", { size: 9, font: "b", color: C.muted, align: "center", gap: 2 });
    part("(b)", bLines, false);
    this.y -= 6;
  }

  async finish(): Promise<Uint8Array<ArrayBuffer>> {
    const pages = this.doc.getPages();
    const total = pages.length;
    pages.forEach((p, i) => {
      const { width, height } = p.getSize();
      if (this.opts.watermark) {
        p.drawText(clean(this.opts.watermark), {
          x: width * 0.2,
          y: height * 0.32,
          size: 92,
          font: this.fonts.b,
          color: C.red,
          opacity: 0.06,
          rotate: degrees(35),
        });
      }
      p.drawLine({ start: { x: this.margin, y: 34 }, end: { x: width - this.margin, y: 34 }, thickness: 0.5, color: C.line });
      p.drawText(clean(this.opts.footer).slice(0, 110), { x: this.margin, y: 22, size: 7.5, font: this.fonts.r, color: C.muted });
      const label = `Page ${i + 1} of ${total}`;
      const lw = this.fonts.r.widthOfTextAtSize(label, 7.5);
      p.drawText(label, { x: width - this.margin - lw, y: 22, size: 7.5, font: this.fonts.r, color: C.muted });
    });
    return new Uint8Array(await this.doc.save());
  }
}

