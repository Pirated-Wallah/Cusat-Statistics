export type SlotLike = { day: number; startTime: string; endTime: string };
export type TimeColumn = { start: string; end: string; used: boolean };

const toMinutes = (t: string) => {
  const [h, m] = t.split(":").map(Number);
  return (h || 0) * 60 + (m || 0);
};

/** Splits the day into columns at every slot boundary; unused columns are breaks. */
export function buildColumns(slots: SlotLike[]): TimeColumn[] {
  const points = Array.from(new Set(slots.flatMap((s) => [s.startTime, s.endTime]))).sort();
  const cols: TimeColumn[] = [];
  for (let i = 0; i < points.length - 1; i++) {
    const start = points[i];
    const end = points[i + 1];
    cols.push({ start, end, used: slots.some((s) => s.startTime <= start && s.endTime >= end) });
  }
  return cols;
}

/** Monday-Friday always, Saturday only when it has classes. */
export function activeDays(slots: SlotLike[]) {
  const days = [1, 2, 3, 4, 5];
  if (slots.some((s) => s.day === 6)) days.push(6);
  return days;
}

export function breakLabel(col: TimeColumn) {
  const mins = toMinutes(col.end) - toMinutes(col.start);
  return col.start >= "12:00" && col.start < "14:30" && mins >= 30 ? "Lunch" : "Break";
}

/** Cells for one day: either a slot spanning N columns, a break column, or an empty column. */
export function dayCells<T extends SlotLike>(cols: TimeColumn[], daySlots: T[]) {
  const cells: Array<
    { type: "slot"; slot: T; span: number; col: TimeColumn } | { type: "break"; col: TimeColumn } | { type: "empty"; col: TimeColumn }
  > = [];
  let i = 0;
  while (i < cols.length) {
    const col = cols[i];
    if (!col.used) {
      cells.push({ type: "break", col });
      i++;
      continue;
    }
    const slot = daySlots.find((s) => s.startTime <= col.start && s.endTime > col.start);
    if (!slot) {
      cells.push({ type: "empty", col });
      i++;
      continue;
    }
    let span = 0;
    while (i + span < cols.length && cols[i + span].end <= slot.endTime) span++;
    span = Math.max(1, span);
    cells.push({ type: "slot", slot, span, col });
    i += span;
  }
  return cells;
}
