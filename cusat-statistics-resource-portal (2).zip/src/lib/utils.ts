import { SITE } from "./site";

export function cn(...classes: Array<string | false | null | undefined>) {
  return classes.filter(Boolean).join(" ");
}

const ROMAN: Array<[number, string]> = [
  [1000, "M"], [900, "CM"], [500, "D"], [400, "CD"], [100, "C"], [90, "XC"],
  [50, "L"], [40, "XL"], [10, "X"], [9, "IX"], [5, "V"], [4, "IV"], [1, "I"],
];

export function toRoman(n: number): string {
  if (!Number.isFinite(n) || n <= 0) return String(n);
  let x = Math.floor(n);
  let out = "";
  for (const [value, symbol] of ROMAN) {
    while (x >= value) {
      out += symbol;
      x -= value;
    }
  }
  return out;
}

/** Today's date as YYYY-MM-DD in the portal's time zone. */
export function todayISO(timeZone: string = SITE.timeZone): string {
  return new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());
}

function parseISO(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(Date.UTC(y || 1970, (m || 1) - 1, d || 1));
}

export function addDaysISO(iso: string, days: number) {
  const dt = parseISO(iso);
  dt.setUTCDate(dt.getUTCDate() + days);
  return dt.toISOString().slice(0, 10);
}

/** 0 = Sunday ... 6 = Saturday */
export function weekdayISO(iso: string) {
  return parseISO(iso).getUTCDay();
}

export function daysBetween(from: string, to: string) {
  return Math.round((parseISO(to).getTime() - parseISO(from).getTime()) / 86_400_000);
}

export function formatDate(iso: string, style: "long" | "short" | "full" = "long") {
  const opts: Intl.DateTimeFormatOptions =
    style === "full"
      ? { weekday: "long", day: "numeric", month: "long", year: "numeric", timeZone: "UTC" }
      : style === "long"
        ? { weekday: "short", day: "numeric", month: "short", year: "numeric", timeZone: "UTC" }
        : { day: "numeric", month: "short", timeZone: "UTC" };
  return new Intl.DateTimeFormat("en-IN", opts).format(parseISO(iso));
}

export function weekdayName(iso: string, style: "long" | "short" = "long") {
  return new Intl.DateTimeFormat("en-IN", { weekday: style, timeZone: "UTC" }).format(parseISO(iso));
}

export function formatTime(t: string) {
  const [h, m] = t.split(":").map(Number);
  if (Number.isNaN(h)) return t;
  const suffix = h >= 12 ? "PM" : "AM";
  const hh = ((h + 11) % 12) + 1;
  return `${hh}:${String(m || 0).padStart(2, "0")} ${suffix}`;
}

export function formatBytes(n?: number | null) {
  if (!n || n <= 0) return "";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(0)} KB`;
  return `${(n / (1024 * 1024)).toFixed(1)} MB`;
}

export function relativeDay(iso: string, today: string = todayISO()) {
  const d = daysBetween(today, iso);
  if (d === 0) return "Today";
  if (d === 1) return "Tomorrow";
  if (d === -1) return "Yesterday";
  return d > 0 ? `in ${d} days` : `${-d} days ago`;
}

export function timeAgo(date: Date | string) {
  const t = typeof date === "string" ? new Date(date) : date;
  const s = Math.max(0, Math.round((Date.now() - t.getTime()) / 1000));
  if (s < 60) return "just now";
  const m = Math.round(s / 60);
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} hr ago`;
  const d = Math.round(h / 24);
  if (d < 30) return `${d} day${d > 1 ? "s" : ""} ago`;
  const mo = Math.round(d / 30);
  if (mo < 12) return `${mo} month${mo > 1 ? "s" : ""} ago`;
  const y = Math.round(mo / 12);
  return `${y} year${y > 1 ? "s" : ""} ago`;
}

/** Current weekday in the portal time zone: 0 = Sunday ... 6 = Saturday */
export function currentWeekday(timeZone: string = SITE.timeZone) {
  const wd = new Intl.DateTimeFormat("en-US", { timeZone, weekday: "short" }).format(new Date());
  return ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].indexOf(wd);
}

export function slugify(s: string) {
  return (
    s
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "")
      .slice(0, 80) || "file"
  );
}

export function splitTopics(topics: string) {
  return topics
    .split(/\n|;/)
    .map((t) => t.trim())
    .filter(Boolean);
}

export function firstParam(v: string | string[] | undefined) {
  return Array.isArray(v) ? v[0] : v;
}

export function toInt(v: unknown): number | null {
  if (v === null || v === undefined || v === "") return null;
  const n = Number(v);
  return Number.isInteger(n) ? n : null;
}

/** Odd semesters run July-December, even semesters January-June. */
export function semesterInSession(semesterNumber: number, today: string = todayISO()) {
  const month = Number(today.slice(5, 7));
  return (semesterNumber % 2 === 1) === month >= 7;
}

export function yearOfSemester(semesterNumber: number) {
  return Math.ceil(semesterNumber / 2);
}

export function ordinal(n: number) {
  const s = ["th", "st", "nd", "rd"];
  const v = n % 100;
  return `${n}${s[(v - 20) % 10] || s[v] || s[0]}`;
}

/** 1 = Internal Test I, 2 = Internal Test II, 0 = all units (model exam / unknown) */
export function internalTestNo(label: string | null | undefined): 0 | 1 | 2 {
  if (!label) return 1;
  if (/model/i.test(label)) return 0;
  if (/\b(II|2)\b/.test(label)) return 2;
  return 1;
}

/** Units covered by an internal test, as [fromUnitNo, toUnitNo]. */
export function internalUnitRange(unitCount: number, testNo: 0 | 1 | 2): [number, number] {
  if (unitCount <= 1 || testNo === 0) return [1, Math.max(1, unitCount)];
  const split = Math.max(1, Math.round(unitCount * 0.45));
  return testNo === 1 ? [1, split] : [split + 1, unitCount];
}
