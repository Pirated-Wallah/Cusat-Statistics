import Link from "next/link";
import { CalendarDays } from "lucide-react";
import { timetableHref } from "@/components/program-ui";
import { Badge, InSessionBadge, semesterSubtitle } from "@/components/ui";
import { listProgramsWithSemesters } from "@/lib/data";
import { programTheme } from "@/lib/site";
import { cn, semesterInSession, todayISO } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "Timetables" };

export default async function TimetableIndexPage() {
  const programs = await listProgramsWithSemesters();
  const today = todayISO();
  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <h1 className="text-3xl font-bold tracking-tight text-slate-900">Timetables</h1>
      <p className="mt-1 text-slate-500">Weekly class timetable and exam schedule for every semester of both programmes.</p>
      <div className="mt-8 space-y-8">
        {programs.map((p) => (
          <section key={p.id}>
            <h2 className={cn("mb-3 text-xl font-bold", programTheme(p.sortOrder).text)}>{p.name}</h2>
            <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
              {p.semesters.map((s) => (
                <Link
                  key={s.id}
                  href={timetableHref(p.slug, s.number)}
                  className="card flex items-start gap-3 p-4 transition hover:-translate-y-0.5 hover:border-indigo-200 hover:shadow-md"
                >
                  <span className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-rose-50 text-rose-600">
                    <CalendarDays className="h-5 w-5" aria-hidden />
                  </span>
                  <span className="min-w-0">
                    <span className="block font-semibold text-slate-900">Semester {s.number}</span>
                    <span className="block truncate text-xs text-slate-500">{semesterSubtitle(s.title)}</span>
                    <span className="mt-1.5 flex flex-wrap gap-1">
                      {semesterInSession(s.number, today) && <InSessionBadge />}
                      {s.linked && (
                        <Badge className="bg-violet-50 text-violet-700 ring-violet-600/20">
                          = {s.linked.programShort} Sem {s.linked.number}
                        </Badge>
                      )}
                    </span>
                  </span>
                </Link>
              ))}
            </div>
          </section>
        ))}
      </div>
    </div>
  );
}
