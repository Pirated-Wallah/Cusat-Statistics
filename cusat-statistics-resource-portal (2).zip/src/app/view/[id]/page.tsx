import Link from "next/link";
import { notFound } from "next/navigation";
import { BookOpen, Download, ExternalLink, FileWarning, Trash2 } from "lucide-react";
import { ApiButton, ApiForm } from "@/components/client";
import { semesterHref, semesterTag } from "@/components/program-ui";
import { fileHref, fileKind } from "@/components/resource-item";
import { Badge, Breadcrumbs, EmptyState, TypeIcon } from "@/components/ui";
import { isAdmin } from "@/lib/auth";
import { getResourceById, getResourcesForSubject, getSemesterLevelResources } from "@/lib/data";
import { SITE, TYPE_META, isResourceType } from "@/lib/site";
import { formatBytes, timeAgo, toRoman } from "@/lib/utils";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ id: string }> };

export async function generateMetadata({ params }: Props) {
  const { id } = await params;
  const item = Number.isInteger(Number(id)) ? await getResourceById(Number(id)) : null;
  return { title: item?.title ?? "Study material" };
}

export default async function ViewPage({ params }: Props) {
  const { id } = await params;
  const rid = Number(id);
  if (!Number.isInteger(rid)) notFound();
  const item = await getResourceById(rid);
  if (!item) notFound();

  const [admin, siblings] = await Promise.all([
    isAdmin(),
    item.subjectId ? getResourcesForSubject(item.subjectId) : getSemesterLevelResources(item.semesterId),
  ]);
  const type = isResourceType(item.type) ? item.type : "notes";
  const related = siblings
    .filter((r) => r.id !== item.id)
    .sort((a, b) => Number(b.type === item.type) - Number(a.type === item.type))
    .slice(0, 8);
  const isPdf = item.source === "generated" || (item.source === "upload" && item.fileMime === "application/pdf");
  const isImage = item.source === "upload" && !!item.fileMime?.startsWith("image/");
  let host = "";
  try {
    host = item.externalUrl ? new URL(item.externalUrl).host : "";
  } catch {
    host = "";
  }
  const semHref = semesterHref(item.programSlug, item.semesterNumber);
  const back = item.subjectId ? `/paper/${item.subjectId}?tab=${type}` : semHref;
  const tag = semesterTag(item.programShort, item.semesterNumber, item.aliasLabel);

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <Breadcrumbs
        items={[
          { label: "Home", href: "/" },
          { label: item.programName, href: `/p/${item.programSlug}` },
          { label: `Semester ${item.semesterNumber}`, href: semHref },
          ...(item.subjectId && item.subjectCode ? [{ label: item.subjectCode, href: `/paper/${item.subjectId}` }] : []),
          { label: TYPE_META[type].plural, href: back },
        ]}
      />

      <div className="mt-5 grid gap-8 lg:grid-cols-[1fr_320px]">
        <div className="min-w-0">
          <div className="card p-5">
            <div className="flex items-start gap-4">
              <TypeIcon type={type} size="lg" />
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap gap-1.5">
                  <Badge className={TYPE_META[type].badge}>{TYPE_META[type].label}</Badge>
                  {item.unitNo ? <Badge>Module {toRoman(item.unitNo)}</Badge> : null}
                  {item.year ? <Badge>{item.year}</Badge> : null}
                  {item.examLabel ? <Badge>{item.examLabel}</Badge> : null}
                  {item.isOpenAccess && <Badge className="bg-emerald-50 text-emerald-700 ring-emerald-600/20">Free & open access</Badge>}
                  {item.isSample && <Badge className="bg-amber-50 text-amber-700 ring-amber-600/20">Sample</Badge>}
                </div>
                <h1 className="mt-2 text-2xl font-bold tracking-tight text-slate-900">{item.title}</h1>
                <p className="mt-1 text-slate-600">
                  {item.subjectName ? `${item.subjectCode} · ${item.subjectName} · ` : ""}
                  {tag}
                </p>
                {item.author && (
                  <p className="mt-1 text-sm text-slate-500">{[item.author, item.publisher, item.edition].filter(Boolean).join(" · ")}</p>
                )}
                {item.description && <p className="mt-2 text-sm text-slate-600">{item.description}</p>}
                <p className="mt-2 text-xs text-slate-400">
                  {[
                    fileKind(item),
                    formatBytes(item.fileSize),
                    item.downloads ? `${item.downloads} views` : "",
                    item.source === "upload" || item.source === "link" ? `added ${timeAgo(item.createdAt)}` : "",
                  ]
                    .filter(Boolean)
                    .join(" · ")}
                </p>
              </div>
            </div>
            <div className="mt-5 flex flex-wrap gap-2">
              {item.source === "link" ? (
                <a href={fileHref(item.id)} target="_blank" rel="noopener noreferrer" className="btn btn-primary">
                  <ExternalLink className="h-4 w-4" aria-hidden /> Open {host || "link"}
                </a>
              ) : item.source !== "none" ? (
                <>
                  <a href={fileHref(item.id, true)} className="btn btn-primary">
                    <Download className="h-4 w-4" aria-hidden /> Download
                  </a>
                  <a href={fileHref(item.id)} target="_blank" rel="noopener noreferrer" className="btn btn-secondary">
                    <ExternalLink className="h-4 w-4" aria-hidden /> Open in new tab
                  </a>
                </>
              ) : null}
              {admin && (
                <ApiButton
                  endpoint={`/api/admin/resources/${item.id}`}
                  method="DELETE"
                  confirmMessage={`Delete "${item.title}"? This cannot be undone.`}
                  redirectTo={back}
                  className="btn btn-danger"
                >
                  <Trash2 className="h-4 w-4" aria-hidden /> Delete
                </ApiButton>
              )}
            </div>
            {item.isSample && (
              <p className="mt-4 rounded-xl bg-amber-50 p-3 text-sm text-amber-800 ring-1 ring-inset ring-amber-200">
                This is practice content generated from the syllabus so the portal isn&apos;t empty.{" "}
                {admin ? "Replace it with the real file using the form below." : "Original papers and notes will be uploaded by the admin."}
              </p>
            )}
          </div>

          <div className="mt-6">
            {isPdf ? (
              <iframe src={fileHref(item.id)} title={item.title} className="h-[78vh] w-full rounded-2xl border border-slate-200 bg-white shadow-sm" />
            ) : isImage ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={fileHref(item.id)} alt={item.title} className="w-full rounded-2xl border border-slate-200 bg-white" />
            ) : item.source === "link" ? (
              <div className="card flex flex-col items-center gap-3 p-10 text-center">
                <ExternalLink className="h-10 w-10 text-indigo-500" aria-hidden />
                <p className="font-semibold text-slate-800">This material is hosted on {host || "an external website"}.</p>
                <p className="max-w-md text-sm text-slate-500">Use the button above to open it in a new tab.</p>
              </div>
            ) : item.source === "upload" ? (
              <EmptyState icon={FileWarning} title="Preview isn't available for this file type">
                Download the {fileKind(item)} file to open it on your device.
              </EmptyState>
            ) : (
              <EmptyState icon={BookOpen} title="PDF not uploaded yet">
                {admin
                  ? "Attach the PDF or a link using the form below."
                  : "This book is on the syllabus, but its PDF hasn't been uploaded. Check this paper's Textbooks tab for free open-access books."}
              </EmptyState>
            )}
          </div>

          {admin && (
            <div className="card mt-6 p-5">
              <h2 className="font-bold text-slate-900">{item.source === "none" ? "Attach a file" : "Replace file"}</h2>
              <p className="mt-1 text-sm text-slate-500">Upload a file (max {SITE.maxUploadMb} MB) or paste a link such as a Google Drive URL.</p>
              <ApiForm action={`/api/admin/resources/${item.id}/file`} successMessage="File saved." resetOnSuccess className="mt-4 grid gap-3">
                <input
                  type="file"
                  name="file"
                  accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.txt,.png,.jpg,.jpeg,.webp,.zip"
                  className="input file:mr-3 file:rounded-lg file:border-0 file:bg-indigo-50 file:px-3 file:py-1 file:text-sm file:font-semibold file:text-indigo-700"
                />
                <input type="url" name="url" placeholder="...or paste a link (https://...)" className="input" />
                <div>
                  <button className="btn btn-primary">Save</button>
                </div>
              </ApiForm>
            </div>
          )}
        </div>

        <aside className="space-y-5">
          {item.subjectId && (
            <Link href={`/paper/${item.subjectId}`} className="card block p-5 transition hover:border-indigo-200 hover:shadow-md">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">Paper</p>
              <p className="mt-1 font-bold text-slate-900">{item.subjectName}</p>
              <p className="text-sm text-slate-500">
                {item.subjectCode} · {tag}
              </p>
              <p className="mt-3 text-sm font-semibold text-indigo-600">Syllabus, notes, PYQs & more</p>
            </Link>
          )}
          <div className="card p-5">
            <h2 className="mb-3 font-bold text-slate-900">More from this {item.subjectId ? "paper" : "semester"}</h2>
            <div className="space-y-1">
              {related.map((r) => (
                <Link key={r.id} href={`/view/${r.id}`} className="flex items-center gap-3 rounded-xl p-2 transition hover:bg-slate-50">
                  <TypeIcon type={isResourceType(r.type) ? r.type : "notes"} size="sm" />
                  <span className="min-w-0 flex-1">
                    <span className="line-clamp-2 text-sm font-medium text-slate-700">{r.title}</span>
                    <span className="text-xs text-slate-400">{isResourceType(r.type) ? TYPE_META[r.type].label : r.type}</span>
                  </span>
                </Link>
              ))}
              {!related.length && <p className="text-sm text-slate-500">Nothing else here yet.</p>}
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}
