import type { Metadata } from "next";
import Link from "next/link";
import type { ReactNode } from "react";
import { SiteHeader } from "@/components/site-header";
import { isAdmin } from "@/lib/auth";
import { listProgramsWithSemesters } from "@/lib/data";
import { SITE } from "@/lib/site";
import "./globals.css";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: {
    default: `${SITE.name} - ${SITE.institutionShort} Statistics notes, PYQs, internals, textbooks & syllabus`,
    template: `%s | ${SITE.name}`,
  },
  description: SITE.tagline,
};

export default async function RootLayout({ children }: { children: ReactNode }) {
  const [programs, admin] = await Promise.all([listProgramsWithSemesters(), isAdmin()]);
  return (
    <html lang="en">
      <body className="min-h-screen bg-slate-50 text-slate-900 antialiased">
        <div className="flex min-h-screen flex-col">
          <SiteHeader programs={programs} admin={admin} />
          <main className="flex-1">{children}</main>
          <footer className="border-t border-slate-200 bg-white">
            <div className="mx-auto grid max-w-7xl gap-6 px-4 py-8 text-sm text-slate-500 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]">
              <div>
                <p className="font-semibold text-slate-700">
                  {SITE.name} · {SITE.department}, {SITE.institutionShort}
                </p>
                <p className="mt-1">Notes · PYQs · Internal papers · Textbooks · Syllabus · Timetables</p>
                <p className="mt-1 text-xs">Student-run study portal. Always confirm exam dates with the department notice board.</p>
              </div>
              {programs.map((p) => (
                <div key={p.id}>
                  <Link href={`/p/${p.slug}`} className="font-semibold text-slate-700 hover:text-indigo-600">
                    {p.name}
                  </Link>
                  <div className="mt-1 flex flex-wrap gap-x-3 gap-y-1">
                    {p.semesters.map((s) => (
                      <Link key={s.id} href={`/p/${p.slug}/semester/${s.number}`} className="hover:text-indigo-600">
                        Sem {s.number}
                      </Link>
                    ))}
                  </div>
                </div>
              ))}
            </div>
            <div className="border-t border-slate-100">
              <div className="mx-auto flex max-w-7xl flex-wrap gap-x-4 gap-y-1 px-4 py-3 text-xs text-slate-500 sm:px-6">
                <Link href="/browse" className="hover:text-indigo-600">
                  Browse all material
                </Link>
                <Link href="/timetable" className="hover:text-indigo-600">
                  Timetables
                </Link>
                <Link href="/admin" className="hover:text-indigo-600">
                  Admin
                </Link>
              </div>
            </div>
          </footer>
        </div>
      </body>
    </html>
  );
}
