import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, CalendarClock, CalendarDays, FileDown, FolderOpen, Link as LinkIcon, Upload, User, Users } from "lucide-react";
import { semesterHref, timetableHref } from "@/components/program-ui";
import { BookCard, ResourceRow } from "@/components/resource-item";
import { TodayClasses } from "@/components/timetable-view";
import { EmptyState, InSessionBadge, KindBadge, PillNav, TypeIcon, semesterSubtitle } from "@/components/ui";
import { isAdmin } from "@/lib/auth";
import {
  emptyCounts,
  getResourcesForSemester,
  getSemesterLevelResources,
  getSemesterView,
  getSubjectsWithCounts,
  getTimetableData,
  getUpcomingExams,
} from "@/lib/data";
import { EXAM_TYPES, RESOURCE_TYPES, TYPE_META, isResourceType, semTheme, type ResourceType } from "@/lib/site";
import { cn, currentWeekday, firstParam, formatDate, formatTime, relativeDay, semesterInSession, todayISO } from "@/lib/utils";

export const dynamic = "force-dynamic";

type Props = {
  params: Promise<{ program: string; sem: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export async function generateMetadata({ params }: Props) {
  const { program, sem } = await params;
  const view = await getSemesterView(program, Number(sem));
  return { title: view ? `${view.program.name} Semester ${sem}` : "Semester" };
}

const FILTER_TYPES: ResourceType[] = ["notes", "pyq", "internal", "textbook", "syllabus"];

export default async function SemesterPage({ params, searchParams }: Props) {
  const { program: slug, sem } = await params;
  const sp = await searchParams;
  const n = Number(sem);
  if (!Number.isInteger(n) || n < 1) notFound();
  const view = await getSemesterView(slug, n);
  if (!view) notFound();
  const { program, semester, contentProgram, contentSemester, sharedWith } = view;
  const contentId = contentSemester.id;

  const typeParam = firstParam(sp.type);
  const type = isResourceType(typeParam) && FILTER_TYPES.includes(typeParam) ? typeParam : undefined;

  const [papers, upcoming, tt, admin, semLevel, typed] = await Promise.all([
    getSubjectsWithCounts(contentId),
    getUpcomingExams(4, [contentId]),
    getTimetableData(contentId),
    isAdmin(),
    getSemesterLevelResources(contentId),
    type ? getResourcesForSemester(contentId, type) : Promise.resolve([]),
  ]);

  const theme = semTheme(n);
  const today = todayISO();
  const inSession = semesterInSession(n, today);
  const weekday = currentWeekday();
  const totals = emptyCounts();
  for (const p of papers) for (const t of RESOURCE_TYPES) totals[t] += p.counts[t];
  for (const r of semLevel) if (isResourceType(r.type)) totals[r.type] += 1;
  const credits = papers.reduce((acc, p) => acc + p.credits, 0);
  const uploadedDocs = semLevel.filter((r) => r.source !== "generated");
  const base = semesterHref(program.slug, n);

  const groups = type
    ? [
        ...(typed.some((r) => !r.subjectId)
          ? [{ key: "semester", title: "Whole semester", href: undefined as string | undefined, items: typed.filter((r) => !r.subjectId) }]
          : []),
        ...papers
          .map((p) => ({
            key: String(p.id),
            title: `${p.code} · ${p.name}`,
            href: `/paper/${p.id}?tab=${type}` as string | undefined,
            items: typed.filter((r) => r.subjectId === p.id),
          }))
          .filter((g) => g.items.length),
      ]
    : [];

  return (
    <div>
      <section className={cn("bg-linear-to-br text-white", theme.gradient)}>
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
          <nav className="text-sm text-white/75">
            <Link href="/" className="hover:text-white">
              Home
            </Link>{" "}
            /{" "}
            <Link href={`/p/${program.slug}`} className="hover:text-white">
              {program.name}
            </Link>{" "}
            / <span className="font-medium text-white">Semester {n}</span>
          </nav>
          <div className="mt-4 flex flex-wrap items-end justify-between gap-6">
            <div>
              <p className="text-sm font-semibold uppercase tracking-widest text-white/80">
                {program.name} · Semester {n}
              </p>
              <h1 className="mt-1 text-3xl font-bold tracking-tight sm:text-4xl">{semesterSubtitle(semester.title)}</h1>
              <p className="mt-2 max-w-2xl text-white/85">{semester.description || contentSemester.description}</p>
              <div className="mt-2 flex flex-wrap items-center gap-2 text-sm text-white/75">
                <span>{semester.session}</span>
                {inSession && <InSessionBadge />}
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <Link href={timetableHref(program.slug, n)} className="btn bg-white text-slate-900 hover:bg-white/90">
                <CalendarDays className="h-4 w-4" aria-hidden /> Timetable
              </Link>
              <a
                href={`/api/pdf/syllabus?semester=${semester.id}`}
                target="_blank"
                rel="noopener noreferrer"
                className="btn bg-white/15 text-white ring-1 ring-inset ring-white/30 hover:bg-white/25"
              >
                <FileDown className="h-4 w-4" aria-hidden /> Complete syllabus PDF
              </a>
              {admin && (
                <Link href={`/admin?semesterId=${contentId}`} className="btn bg-white/15 text-white ring-1 ring-inset ring-white/30 hover:bg-white/25">
                  <Upload className="h-4 w-4" aria-hidden /> Upload
                </Link>
              )}
            </div>
          </div>
          <div className="mt-6 grid grid-cols-3 gap-2 sm:grid-cols-6">
            {[
              ["Papers", papers.length],
              ["Credits", credits],
              ["Notes", totals.notes],
              ["PYQs", totals.pyq],
              ["Internals", totals.internal],
              ["Textbooks", totals.textbook],
            ].map(([label, value]) => (
              <div key={label} className="rounded-xl bg-white/10 px-3 py-2 ring-1 ring-inset ring-white/20">
                <p className="text-xl font-bold">{value}</p>
                <p className="text-xs text-white/75">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        <PillNav
          items={program.semesters.map((s) => ({
            href: semesterHref(program.slug, s.number),
            label: `Sem ${s.number}`,
            hint: s.linked ? "joint" : undefined,
            active: s.number === n,
            activeClass: cn("bg-linear-to-r", semTheme(s.number).gradient),
          }))}
        />

        {semester.linked && (
          <div className="mt-6 flex flex-wrap items-start gap-3 rounded-2xl border border-violet-200 bg-violet-50 p-4 text-violet-900">
            <LinkIcon className="mt-0.5 h-5 w-5 shrink-0" aria-hidden />
            <div className="min-w-0 flex-1 text-sm">
              <p className="font-semibold">
                Joint semester: you study with {contentProgram.name} Semester {contentSemester.number}.
              </p>
              <p className="mt-0.5">
                The papers, notes, PYQs, internal papers, textbooks, timetable and exams below are shared with {contentProgram.name} Semester{" "}
                {contentSemester.number}.
              </p>
            </div>
            <Link href={semesterHref(contentProgram.slug, contentSemester.number)} className="btn btn-secondary btn-sm">
              Open {contentProgram.shortName} Sem {contentSemester.number}
            </Link>
          </div>
        )}
        {!semester.linked && sharedWith.length > 0 && (
          <div className="mt-6 flex flex-wrap items-start gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-900">
            <Users className="mt-0.5 h-5 w-5 shrink-0" aria-hidden />
            <p className="min-w-0 flex-1">
              <span className="font-semibold">{sharedWith.map((s) => `${s.programName} Semester ${s.number}`).join(", ")}</span> students attend
              these classes too - everything on this page is shared with them.
            </p>
          </div>
        )}

        <div className="mt-6 grid gap-8 lg:grid-cols-[1fr_320px]">
          <div className="min-w-0">
            <div className="mb-5 flex gap-2 overflow-x-auto pb-1">
              <Link
                href={base}
                className={cn(
                  "inline-flex shrink-0 items-center gap-2 rounded-xl px-3.5 py-2 text-sm font-semibold transition",
                  !type ? "bg-slate-900 text-white" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50",
                )}
              >
                All papers <span className="text-xs opacity-70">{papers.length}</span>
              </Link>
              {FILTER_TYPES.map((t) => (
                <Link
                  key={t}
                  href={`${base}?type=${t}`}
                  className={cn(
                    "inline-flex shrink-0 items-center gap-2 rounded-xl px-3.5 py-2 text-sm font-semibold transition",
                    type === t ? "bg-slate-900 text-white" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50",
                  )}
                >
                  {TYPE_META[t].short} <span className="text-xs opacity-70">{totals[t]}</span>
                </Link>
              ))}
            </div>

            {!type &&
              (papers.length ? (
                <div className="grid gap-4 sm:grid-cols-2">
                  {papers.map((p) => (
                    <Link
                      key={p.id}
                      href={`/paper/${p.id}`}
                      className="card group flex flex-col p-5 transition hover:-translate-y-0.5 hover:border-indigo-200 hover:shadow-md"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs font-bold tracking-wide text-slate-500">{p.code}</span>
                        <KindBadge kind={p.kind} />
                      </div>
                      <h3 className="mt-2 text-lg font-bold leading-snug text-slate-900 group-hover:text-indigo-700">{p.name}</h3>
                      <p className="mt-1 flex items-center gap-1.5 text-sm text-slate-500">
                        <User className="h-3.5 w-3.5" aria-hidden />
                        {p.faculty || "Faculty TBA"} · {p.credits} credits
                      </p>
                      <div className="mt-4 grid grid-cols-4 gap-1.5">
                        {(["notes", "pyq", "internal", "textbook"] as const).map((t) => (
                          <div key={t} className="flex flex-col items-center rounded-xl bg-slate-50 py-2">
                            <TypeIcon type={t} size="sm" className="h-7 w-7" />
                            <span className="mt-1 text-sm font-bold text-slate-900">{p.counts[t]}</span>
                            <span className="text-[10px] text-slate-500">{TYPE_META[t].short}</span>
                          </div>
                        ))}
                      </div>
                      <div className="mt-4 flex items-center justify-between text-sm">
                        <span className="text-slate-500">
                          {p.unitCount} {p.kind === "lab" ? "parts" : p.unitCount === 1 ? "module" : "modules"}
                        </span>
                        <span className="inline-flex items-center gap-1 font-semibold text-indigo-600">
                          Open <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" aria-hidden />
                        </span>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <EmptyState title="No papers added yet">
                  {admin ? (
                    <Link href="/admin/papers" className="font-semibold text-indigo-600">
                      Add papers for this semester
                    </Link>
                  ) : (
                    "Papers for this semester will appear here soon."
                  )}
                </EmptyState>
              ))}

            {type &&
              (groups.length ? (
                <div className="space-y-7">
                  {groups.map((g) => (
                    <section key={g.key}>
                      <div className="mb-3 flex items-center justify-between gap-2">
                        <h2 className="font-bold text-slate-900">{g.title}</h2>
                        {g.href && (
                          <Link href={g.href} className="text-sm font-semibold text-indigo-600 hover:text-indigo-500">
                            Open paper
                          </Link>
                        )}
                      </div>
                      {type === "textbook" ? (
                        <div className="grid gap-3 md:grid-cols-2">
                          {g.items.map((r) => (
                            <BookCard key={r.id} item={r} isAdmin={admin} />
                          ))}
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {g.items.map((r) => (
                            <ResourceRow key={r.id} item={r} showType={false} isAdmin={admin} />
                          ))}
                        </div>
                      )}
                    </section>
                  ))}
                </div>
              ) : (
                <EmptyState icon={FolderOpen} title={`No ${TYPE_META[type].plural.toLowerCase()} yet`}>
                  {admin ? (
                    <Link href={`/admin?semesterId=${contentId}&type=${type}`} className="font-semibold text-indigo-600">
                      Upload the first one
                    </Link>
                  ) : (
                    "Check back soon - new material is added regularly."
                  )}
                </EmptyState>
              ))}
          </div>

          <aside className="space-y-5">
            <div className="card p-5">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="font-bold text-slate-900">Today&apos;s classes</h2>
                <Link href={timetableHref(program.slug, n)} className="text-xs font-semibold text-indigo-600">
                  Full week
                </Link>
              </div>
              {inSession ? (
                <TodayClasses data={tt} weekday={weekday} />
              ) : (
                <p className="text-sm text-slate-500">This semester is not in session right now. The weekly timetable is still available.</p>
              )}
            </div>

            <div className="card p-5">
              <h2 className="mb-3 flex items-center gap-2 font-bold text-slate-900">
                <CalendarClock className="h-4 w-4 text-rose-500" aria-hidden /> Upcoming exams
              </h2>
              {upcoming.length ? (
                <ul className="space-y-2.5">
                  {upcoming.map((e) => (
                    <li key={e.id} className="rounded-xl bg-slate-50 px-3 py-2">
                      <div className="flex items-center justify-between gap-2">
                        <span className="truncate text-sm font-semibold text-slate-900">{e.subjectName ?? e.title}</span>
                        <span className="shrink-0 text-xs font-semibold text-indigo-600">{relativeDay(e.examDate, today)}</span>
                      </div>
                      <p className="text-xs text-slate-500">
                        {EXAM_TYPES[e.examType]?.label ?? e.examType} · {formatDate(e.examDate, "short")} · {formatTime(e.startTime)}
                      </p>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-slate-500">No upcoming exams.</p>
              )}
            </div>

            <div className="card p-5">
              <h2 className="mb-3 font-bold text-slate-900">Semester documents</h2>
              <div className="space-y-2">
                <a
                  href={`/api/pdf/syllabus?semester=${semester.id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 rounded-xl p-2 transition hover:bg-slate-50"
                >
                  <TypeIcon type="syllabus" size="sm" />
                  <span className="min-w-0 flex-1 truncate text-sm font-medium text-slate-700">Complete syllabus (all papers)</span>
                </a>
                <a
                  href={`/api/pdf/timetable?semester=${semester.id}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 rounded-xl p-2 transition hover:bg-slate-50"
                >
                  <TypeIcon type="timetable" size="sm" />
                  <span className="min-w-0 flex-1 truncate text-sm font-medium text-slate-700">Class & exam timetable</span>
                </a>
                {uploadedDocs.map((r) => (
                  <Link key={r.id} href={`/view/${r.id}`} className="flex items-center gap-3 rounded-xl p-2 transition hover:bg-slate-50">
                    <TypeIcon type={isResourceType(r.type) ? r.type : "syllabus"} size="sm" />
                    <span className="min-w-0 flex-1 truncate text-sm font-medium text-slate-700">{r.title}</span>
                  </Link>
                ))}
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
