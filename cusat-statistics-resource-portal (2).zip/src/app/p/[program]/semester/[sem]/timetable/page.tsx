import Link from "next/link";
import { notFound } from "next/navigation";
import { CalendarClock, FileDown, Link as LinkIcon, MapPin, Pencil } from "lucide-react";
import { semesterHref, timetableHref } from "@/components/program-ui";
import { ResourceRow } from "@/components/resource-item";
import { ExamSchedule, SubjectLegend, WeeklyGrid } from "@/components/timetable-view";
import { Breadcrumbs, InSessionBadge, PillNav } from "@/components/ui";
import { isAdmin } from "@/lib/auth";
import { getSemesterLevelResources, getSemesterView, getTimetableData } from "@/lib/data";
import { EXAM_TYPES, semTheme } from "@/lib/site";
import { cn, currentWeekday, formatDate, formatTime, relativeDay, semesterInSession, todayISO } from "@/lib/utils";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ program: string; sem: string }> };

export async function generateMetadata({ params }: Props) {
  const { program, sem } = await params;
  const view = await getSemesterView(program, Number(sem));
  return { title: view ? `${view.program.name} Semester ${sem} timetable` : "Timetable" };
}

export default async function SemesterTimetablePage({ params }: Props) {
  const { program: slug, sem } = await params;
  const n = Number(sem);
  if (!Number.isInteger(n) || n < 1) notFound();
  const view = await getSemesterView(slug, n);
  if (!view) notFound();
  const { program, semester, contentProgram, contentSemester } = view;

  const [tt, admin, semLevel] = await Promise.all([getTimetableData(contentSemester.id), isAdmin(), getSemesterLevelResources(contentSemester.id)]);
  const today = todayISO();
  const inSession = semesterInSession(n, today);
  const weekday = inSession ? currentWeekday() : -1;
  const nextExam = tt.exams
    .filter((e) => e.examDate >= today)
    .sort((a, b) => (a.examDate + a.startTime).localeCompare(b.examDate + b.startTime))[0];
  const nextSubject = nextExam?.subjectId ? tt.subjects.find((s) => s.id === nextExam.subjectId) : undefined;
  const officialDocs = semLevel.filter((r) => r.type === "timetable" && r.source !== "generated");

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <Breadcrumbs
        items={[
          { label: "Home", href: "/" },
          { label: program.name, href: `/p/${program.slug}` },
          { label: `Semester ${n}`, href: semesterHref(program.slug, n) },
          { label: "Timetable" },
        ]}
      />
      <div className="mt-4 flex flex-wrap items-end justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-slate-900">
            {program.name} · Semester {n} timetable
          </h1>
          <p className="mt-1 flex flex-wrap items-center gap-2 text-slate-500">
            {semester.session} · weekly classes and exam schedule {inSession && <InSessionBadge />}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <a href={`/api/pdf/timetable?semester=${semester.id}&download=1`} className="btn btn-primary">
            <FileDown className="h-4 w-4" aria-hidden /> Download PDF
          </a>
          {admin && (
            <Link href={`/admin/timetable?semesterId=${contentSemester.id}`} className="btn btn-secondary">
              <Pencil className="h-4 w-4" aria-hidden /> Edit timetable
            </Link>
          )}
        </div>
      </div>
      <div className="mt-5">
        <PillNav
          items={program.semesters.map((s) => ({
            href: timetableHref(program.slug, s.number),
            label: `Sem ${s.number}`,
            hint: s.linked ? "joint" : undefined,
            active: s.number === n,
            activeClass: cn("bg-linear-to-r", semTheme(s.number).gradient),
          }))}
        />
      </div>

      {semester.linked && (
        <p className="mt-5 flex items-center gap-2 rounded-xl bg-violet-50 px-4 py-3 text-sm text-violet-900 ring-1 ring-inset ring-violet-200">
          <LinkIcon className="h-4 w-4 shrink-0" aria-hidden />
          Same classes and exams as {contentProgram.name} Semester {contentSemester.number}.
        </p>
      )}

      {nextExam && (
        <div className="mt-6 flex flex-wrap items-center gap-4 rounded-2xl bg-linear-to-r from-rose-500 to-orange-500 p-5 text-white shadow-sm">
          <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20">
            <CalendarClock className="h-6 w-6" aria-hidden />
          </span>
          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold uppercase tracking-widest text-white/80">
              Next exam · {EXAM_TYPES[nextExam.examType]?.label ?? nextExam.examType}
            </p>
            <p className="truncate text-lg font-bold">{nextSubject?.name ?? (nextExam.title || "Exam")}</p>
            <p className="flex flex-wrap items-center gap-x-3 text-sm text-white/90">
              <span>
                {formatDate(nextExam.examDate, "full")} · {formatTime(nextExam.startTime)} - {formatTime(nextExam.endTime)}
              </span>
              {nextExam.venue && (
                <span className="inline-flex items-center gap-1">
                  <MapPin className="h-3.5 w-3.5" aria-hidden /> {nextExam.venue}
                </span>
              )}
            </p>
          </div>
          <span className="rounded-full bg-white px-3 py-1 text-sm font-bold text-rose-600">{relativeDay(nextExam.examDate, today)}</span>
        </div>
      )}

      <section className="mt-8">
        <h2 className="mb-3 text-xl font-bold text-slate-900">Weekly class timetable</h2>
        <WeeklyGrid data={tt} today={weekday} />
        <div className="mt-4">
          <SubjectLegend data={tt} />
        </div>
      </section>

      <section className="mt-10">
        <h2 className="mb-3 text-xl font-bold text-slate-900">Exam timetable</h2>
        <ExamSchedule data={tt} today={today} isAdmin={admin} />
      </section>

      {officialDocs.length > 0 && (
        <section className="mt-10">
          <h2 className="mb-3 text-xl font-bold text-slate-900">Official timetable notices</h2>
          <div className="space-y-2">
            {officialDocs.map((r) => (
              <ResourceRow key={r.id} item={r} showType={false} isAdmin={admin} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
