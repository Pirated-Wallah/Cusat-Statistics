import Link from "next/link";
import { notFound } from "next/navigation";
import { CalendarClock, CalendarDays, FileDown, Link as LinkIcon, Upload, Users } from "lucide-react";
import { SemesterCard, semesterHref, semesterTag, timetableHref } from "@/components/program-ui";
import { Badge, Breadcrumbs } from "@/components/ui";
import { isAdmin } from "@/lib/auth";
import { getSemesterStats, getUpcomingExams, listProgramsWithSemesters } from "@/lib/data";
import { EXAM_TYPES, programTheme } from "@/lib/site";
import { cn, formatDate, formatTime, ordinal, relativeDay, semesterInSession, todayISO, yearOfSemester } from "@/lib/utils";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ program: string }> };

export async function generateMetadata({ params }: Props) {
  const { program } = await params;
  const all = await listProgramsWithSemesters();
  const p = all.find((x) => x.slug === program);
  return { title: p ? `${p.name} - notes, PYQs, internals, textbooks & syllabus` : "Programme" };
}

export default async function ProgramPage({ params }: Props) {
  const { program: slug } = await params;
  const all = await listProgramsWithSemesters();
  const program = all.find((p) => p.slug === slug);
  if (!program) notFound();

  const contentIds = Array.from(new Set(program.semesters.map((s) => s.contentId)));
  const [stats, upcoming, admin] = await Promise.all([getSemesterStats(contentIds), getUpcomingExams(6, contentIds), isAdmin()]);
  const today = todayISO();
  const theme = programTheme(program.sortOrder);
  const joint = program.semesters.filter((s) => s.linked);
  const feeders = all.flatMap((q) => q.semesters.filter((s) => s.linked?.programId === program.id).map((s) => ({ program: q, sem: s })));
  const years = Array.from(new Set(program.semesters.map((s) => yearOfSemester(s.number)))).sort((a, b) => a - b);
  const live = program.semesters.find((s) => semesterInSession(s.number, today)) ?? program.semesters[0];
  const totals = contentIds.reduce(
    (acc, id) => {
      const s = stats.get(id);
      if (s) {
        acc.papers += s.subjectCount;
        acc.credits += s.credits;
        acc.notes += s.counts.notes;
        acc.pyq += s.counts.pyq;
        acc.internal += s.counts.internal;
        acc.books += s.counts.textbook;
      }
      return acc;
    },
    { papers: 0, credits: 0, notes: 0, pyq: 0, internal: 0, books: 0 },
  );

  return (
    <div>
      <section className={cn("bg-linear-to-br text-white", theme.gradient)}>
        <div className="mx-auto max-w-7xl px-4 py-10 sm:px-6">
          <nav className="text-sm text-white/75">
            <Link href="/" className="hover:text-white">
              Home
            </Link>{" "}
            / <span className="font-medium text-white">{program.name}</span>
          </nav>
          <div className="mt-4 flex flex-wrap items-end justify-between gap-6">
            <div className="max-w-3xl">
              <p className="text-sm font-semibold uppercase tracking-widest text-white/80">
                {program.department} · {program.institution}
              </p>
              <h1 className="mt-1 text-3xl font-bold tracking-tight sm:text-4xl">{program.name}</h1>
              <p className="mt-2 text-white/90">{program.description}</p>
            </div>
            <div className="flex flex-wrap gap-2">
              <a href={`/api/pdf/programme?program=${program.slug}`} target="_blank" rel="noopener noreferrer" className="btn bg-white text-slate-900 hover:bg-white/90">
                <FileDown className="h-4 w-4" aria-hidden /> Full programme syllabus
              </a>
              {live && (
                <Link href={timetableHref(program.slug, live.number)} className="btn bg-white/15 text-white ring-1 ring-inset ring-white/30 hover:bg-white/25">
                  <CalendarDays className="h-4 w-4" aria-hidden /> Timetable
                </Link>
              )}
              {admin && (
                <Link href="/admin" className="btn bg-white/15 text-white ring-1 ring-inset ring-white/30 hover:bg-white/25">
                  <Upload className="h-4 w-4" aria-hidden /> Upload
                </Link>
              )}
            </div>
          </div>
          <div className="mt-6 grid grid-cols-3 gap-2 sm:grid-cols-6">
            {[
              ["Semesters", program.semesters.length],
              ["Papers", totals.papers],
              ["Notes", totals.notes],
              ["PYQs", totals.pyq],
              ["Internals", totals.internal],
              ["Textbooks", totals.books],
            ].map(([label, value]) => (
              <div key={label} className="rounded-xl bg-white/10 px-3 py-2 ring-1 ring-inset ring-white/20">
                <p className="text-xl font-bold">{value}</p>
                <p className="text-xs text-white/75">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        {joint.length > 0 && joint[0].linked && (
          <div className="mb-8 flex flex-wrap items-start gap-3 rounded-2xl border border-violet-200 bg-violet-50 p-4 text-violet-900">
            <LinkIcon className="mt-0.5 h-5 w-5 shrink-0" aria-hidden />
            <div className="min-w-0 flex-1 text-sm">
              <p className="font-semibold">
                From Semester {joint[0].number} you join the {joint[0].linked.programName} batch.
              </p>
              <p className="mt-0.5">
                {joint
                  .map((s) => `Sem ${s.number} = ${s.linked?.programShort} Sem ${s.linked?.number}`)
                  .join(" · ")}
                . Papers, notes, PYQs, internals, textbooks, timetable and exams are shared, so nothing is uploaded twice.
              </p>
            </div>
            <Link href={`/p/${joint[0].linked.programSlug}`} className="btn btn-secondary btn-sm">
              View {joint[0].linked.programName}
            </Link>
          </div>
        )}
        {feeders.length > 0 && (
          <div className="mb-8 flex flex-wrap items-start gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-emerald-900">
            <Users className="mt-0.5 h-5 w-5 shrink-0" aria-hidden />
            <div className="min-w-0 flex-1 text-sm">
              <p className="font-semibold">{feeders[0].program.name} students study with you.</p>
              <p className="mt-0.5">
                {feeders.map((f) => `${f.program.shortName} Sem ${f.sem.number} = Sem ${f.sem.linked?.number}`).join(" · ")} - they attend the same
                classes and write the same exams.
              </p>
            </div>
          </div>
        )}

        <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
          <div className="space-y-8">
            {years.map((y) => {
              const sems = program.semesters.filter((s) => yearOfSemester(s.number) === y);
              const allJoint = sems.length > 0 && sems.every((s) => s.linked);
              return (
                <section key={y}>
                  <div className="mb-3 flex flex-wrap items-center gap-2">
                    <h2 className="text-xl font-bold text-slate-900">{ordinal(y)} year</h2>
                    <span className="text-sm text-slate-500">Semesters {sems.map((s) => s.number).join(" & ")}</span>
                    {allJoint && sems[0].linked && (
                      <Badge className="bg-violet-50 text-violet-700 ring-violet-600/20">
                        Joint with {sems[0].linked.programName} {ordinal(yearOfSemester(sems[0].linked.number))} year
                      </Badge>
                    )}
                  </div>
                  <div className="grid gap-4 sm:grid-cols-2">
                    {sems.map((s) => (
                      <SemesterCard key={s.id} slug={program.slug} sem={s} stats={stats.get(s.contentId)} today={today} />
                    ))}
                  </div>
                </section>
              );
            })}
          </div>

          <aside className="space-y-5">
            <div className="card p-5">
              <h2 className="mb-3 flex items-center gap-2 font-bold text-slate-900">
                <CalendarClock className="h-4 w-4 text-rose-500" aria-hidden /> Upcoming exams
              </h2>
              {upcoming.length ? (
                <ul className="space-y-2.5">
                  {upcoming.map((e) => (
                    <li key={e.id} className="rounded-xl bg-slate-50 px-3 py-2">
                      <div className="flex items-center justify-between gap-2">
                        <span className="truncate text-sm font-semibold text-slate-900">{e.subjectName ?? e.title}</span>
                        <span className="shrink-0 text-xs font-semibold text-indigo-600">{relativeDay(e.examDate, today)}</span>
                      </div>
                      <p className="text-xs text-slate-500">
                        {semesterTag(e.programShort, e.semesterNumber, e.aliasLabel)} · {EXAM_TYPES[e.examType]?.label ?? e.examType}
                      </p>
                      <p className="text-xs text-slate-500">
                        {formatDate(e.examDate, "short")} · {formatTime(e.startTime)}
                      </p>
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="text-sm text-slate-500">No upcoming exams.</p>
              )}
            </div>
            <div className="card p-5">
              <h2 className="mb-3 font-bold text-slate-900">Timetables</h2>
              <div className="grid grid-cols-2 gap-2">
                {program.semesters.map((s) => (
                  <Link
                    key={s.id}
                    href={timetableHref(program.slug, s.number)}
                    className="flex items-center justify-between rounded-xl bg-slate-50 px-3 py-2 text-sm font-medium text-slate-700 transition hover:bg-indigo-50"
                  >
                    Sem {s.number}
                    {semesterInSession(s.number, today) && <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" aria-label="In session" />}
                  </Link>
                ))}
              </div>
            </div>
            <div className="card p-5 text-sm text-slate-600">
              <h2 className="mb-2 font-bold text-slate-900">Quick links</h2>
              <ul className="space-y-1.5">
                {program.semesters.slice(0, 1).map((s) => (
                  <li key={s.id}>
                    <Link href={semesterHref(program.slug, s.number)} className="text-indigo-600 hover:text-indigo-500">
                      Start with Semester {s.number}
                    </Link>
                  </li>
                ))}
                <li>
                  <Link href="/browse?type=pyq" className="text-indigo-600 hover:text-indigo-500">
                    All previous year papers
                  </Link>
                </li>
                <li>
                  <Link href="/browse?type=textbook" className="text-indigo-600 hover:text-indigo-500">
                    All textbooks & free books
                  </Link>
                </li>
              </ul>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}
