import Link from "next/link";
import { ChevronLeft, ChevronRight, Search, SearchX } from "lucide-react";
import { ResourceRow } from "@/components/resource-item";
import { EmptyState } from "@/components/ui";
import { isAdmin } from "@/lib/auth";
import { listAllSubjects, listProgramsWithSemesters, searchResources } from "@/lib/data";
import { RESOURCE_TYPES, TYPE_META, isResourceType } from "@/lib/site";
import { cn, firstParam, toInt } from "@/lib/utils";

export const dynamic = "force-dynamic";
export const metadata = { title: "Browse study material" };

const PER_PAGE = 24;

type Props = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export default async function BrowsePage({ searchParams }: Props) {
  const sp = await searchParams;
  const q = (firstParam(sp.q) ?? "").trim().slice(0, 100);
  const typeParam = firstParam(sp.type);
  const type = isResourceType(typeParam) ? typeParam : undefined;
  const scope = (firstParam(sp.scope) ?? "").slice(0, 80);
  const subjectId = toInt(firstParam(sp.paper)) ?? undefined;
  const sortParam = firstParam(sp.sort);
  const sort = sortParam === "popular" || sortParam === "title" ? sortParam : "new";
  const page = Math.max(1, toInt(firstParam(sp.page)) ?? 1);

  const [programs, subs, admin] = await Promise.all([listProgramsWithSemesters(), listAllSubjects(), isAdmin()]);

  // scope = "<program-slug>" or "<program-slug>:<semester-number>" (linked semesters resolve to the shared one)
  const [scopeSlug, scopeSem] = scope.split(":");
  const scopeProgram = programs.find((p) => p.slug === scopeSlug);
  let semesterIds: number[] | undefined;
  if (scopeProgram) {
    const n = toInt(scopeSem);
    const sems = n ? scopeProgram.semesters.filter((s) => s.number === n) : scopeProgram.semesters;
    semesterIds = Array.from(new Set(sems.map((s) => s.contentId)));
  }

  const { items, total } = await searchResources({
    q,
    type,
    semesterIds,
    subjectId,
    sort,
    limit: PER_PAGE,
    offset: (page - 1) * PER_PAGE,
  });
  const pages = Math.max(1, Math.ceil(total / PER_PAGE));
  const paperOptions = semesterIds ? subs.filter((s) => semesterIds.includes(s.semesterId)) : subs;
  const paperGroups = Array.from(new Set(paperOptions.map((p) => `${p.programShort} Semester ${p.semesterNumber}`)));

  const href = (patch: Record<string, string | number | undefined>) => {
    const base: Record<string, string | number | undefined> = {
      q: q || undefined,
      type,
      scope: scope || undefined,
      paper: subjectId,
      sort: sort === "new" ? undefined : sort,
      ...patch,
    };
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(base)) if (v !== undefined && v !== "") params.set(k, String(v));
    const s = params.toString();
    return s ? `/browse?${s}` : "/browse";
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <h1 className="text-3xl font-bold tracking-tight text-slate-900">Browse study material</h1>
      <p className="mt-1 text-slate-500">
        Search notes, previous year papers, internal papers, textbooks, syllabus and timetables across M.Sc. and Integrated M.Sc. Statistics.
      </p>

      <form action="/browse" className="card mt-6 grid gap-3 p-4 md:grid-cols-[1.6fr_1.2fr_1.4fr_1fr_auto]" role="search">
        {type && <input type="hidden" name="type" value={type} />}
        <label className="relative">
          <span className="sr-only">Search</span>
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" aria-hidden />
          <input name="q" defaultValue={q} className="input pl-9" placeholder="Title, paper, code, author, year..." />
        </label>
        <label>
          <span className="sr-only">Programme / semester</span>
          <select name="scope" defaultValue={scope} className="input">
            <option value="">All programmes</option>
            {programs.map((p) => (
              <optgroup key={p.id} label={p.name}>
                <option value={p.slug}>All of {p.name}</option>
                {p.semesters.map((s) => (
                  <option key={s.id} value={`${p.slug}:${s.number}`}>
                    {p.shortName} Semester {s.number}
                    {s.linked ? ` (= ${s.linked.programShort} Sem ${s.linked.number})` : ""}
                  </option>
                ))}
              </optgroup>
            ))}
          </select>
        </label>
        <label>
          <span className="sr-only">Paper</span>
          <select name="paper" defaultValue={subjectId ? String(subjectId) : ""} className="input">
            <option value="">All papers</option>
            {paperGroups.map((g) => (
              <optgroup key={g} label={g}>
                {paperOptions
                  .filter((p) => `${p.programShort} Semester ${p.semesterNumber}` === g)
                  .map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.code} - {p.name}
                    </option>
                  ))}
              </optgroup>
            ))}
          </select>
        </label>
        <label>
          <span className="sr-only">Sort</span>
          <select name="sort" defaultValue={sort} className="input">
            <option value="new">Newest first</option>
            <option value="popular">Most viewed</option>
            <option value="title">Title A-Z</option>
          </select>
        </label>
        <button className="btn btn-primary">Apply</button>
      </form>

      <div className="mt-5 flex gap-2 overflow-x-auto pb-1">
        <Link
          href={href({ type: undefined, page: undefined })}
          className={cn(
            "shrink-0 rounded-xl px-3.5 py-2 text-sm font-semibold transition",
            !type ? "bg-slate-900 text-white" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50",
          )}
        >
          All types
        </Link>
        {RESOURCE_TYPES.map((t) => (
          <Link
            key={t}
            href={href({ type: t, page: undefined })}
            className={cn(
              "shrink-0 rounded-xl px-3.5 py-2 text-sm font-semibold transition",
              type === t ? "bg-slate-900 text-white" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50",
            )}
          >
            {TYPE_META[t].plural}
          </Link>
        ))}
      </div>

      <div className="mt-5 flex flex-wrap items-center justify-between gap-2 text-sm text-slate-500">
        <p>
          <span className="font-semibold text-slate-900">{total}</span> result{total === 1 ? "" : "s"}
          {q ? (
            <>
              {" "}
              for &ldquo;<span className="font-medium text-slate-700">{q}</span>&rdquo;
            </>
          ) : null}
        </p>
        {(q || type || scope || subjectId) && (
          <Link href="/browse" className="font-semibold text-indigo-600 hover:text-indigo-500">
            Clear filters
          </Link>
        )}
      </div>

      <div className="mt-3 space-y-2">
        {items.map((r) => (
          <ResourceRow key={r.id} item={r} showSemester showSubject isAdmin={admin} />
        ))}
        {!items.length && (
          <EmptyState icon={SearchX} title="Nothing matches your search">
            Try a different keyword, or remove some filters.
          </EmptyState>
        )}
      </div>

      {pages > 1 && (
        <nav className="mt-6 flex items-center justify-between gap-2" aria-label="Pagination">
          {page > 1 ? (
            <Link href={href({ page: page - 1 })} className="btn btn-secondary">
              <ChevronLeft className="h-4 w-4" aria-hidden /> Previous
            </Link>
          ) : (
            <span />
          )}
          <span className="text-sm text-slate-500">
            Page {page} of {pages}
          </span>
          {page < pages ? (
            <Link href={href({ page: page + 1 })} className="btn btn-secondary">
              Next <ChevronRight className="h-4 w-4" aria-hidden />
            </Link>
          ) : (
            <span />
          )}
        </nav>
      )}
    </div>
  );
}
