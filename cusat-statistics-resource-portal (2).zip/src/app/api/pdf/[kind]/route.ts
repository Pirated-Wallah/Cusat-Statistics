import type { NextRequest } from "next/server";
import { ensureDb } from "@/db/bootstrap";
import {
  fileResponse,
  renderProgrammeSyllabus,
  renderSemesterSyllabus,
  renderSubjectSyllabus,
  renderTimetable,
  type PdfFile,
} from "@/lib/pdf-render";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

type Ctx = { params: Promise<{ kind: string }> };

const positiveInt = (v: string | null) => {
  const n = Number(v);
  return Number.isInteger(n) && n > 0 ? n : null;
};

/**
 * /api/pdf/syllabus?subject=ID      - one paper's syllabus
 * /api/pdf/syllabus?semester=ID     - complete syllabus of a semester (linked semesters resolved)
 * /api/pdf/timetable?semester=ID    - class + exam timetable
 * /api/pdf/programme?program=slug   - programme structure & syllabus of all semesters
 */
export async function GET(req: NextRequest, ctx: Ctx) {
  await ensureDb();
  const { kind } = await ctx.params;
  const sp = req.nextUrl.searchParams;
  const download = sp.get("download") === "1";
  const subjectId = positiveInt(sp.get("subject"));
  const semesterId = positiveInt(sp.get("semester"));
  const program = sp.get("program");

  try {
    let pdf: PdfFile | null = null;
    if (kind === "syllabus" && subjectId) pdf = await renderSubjectSyllabus(subjectId);
    else if (kind === "syllabus" && semesterId) pdf = await renderSemesterSyllabus(semesterId);
    else if (kind === "timetable" && semesterId) pdf = await renderTimetable(semesterId);
    else if (kind === "programme" && program) pdf = await renderProgrammeSyllabus(program.slice(0, 80));
    if (!pdf) return new Response("Not found", { status: 404 });
    return fileResponse(pdf.bytes, "application/pdf", pdf.filename, download);
  } catch (err) {
    console.error("PDF generation failed", err);
    return new Response("Could not generate the PDF.", { status: 500 });
  }
}
