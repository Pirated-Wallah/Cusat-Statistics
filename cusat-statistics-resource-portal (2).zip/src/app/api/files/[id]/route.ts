import { NextResponse, type NextRequest } from "next/server";
import { eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { ensureDb } from "@/db/bootstrap";
import { files, resources } from "@/db/schema";
import { fileResponse, renderResourcePdf } from "@/lib/pdf-render";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(req: NextRequest, ctx: Ctx) {
  await ensureDb();
  const { id } = await ctx.params;
  const rid = Number(id);
  if (!Number.isInteger(rid)) return new Response("Not found", { status: 404 });

  const [r] = await db.select().from(resources).where(eq(resources.id, rid)).limit(1);
  if (!r) return new Response("Not found", { status: 404 });

  const download = req.nextUrl.searchParams.get("download") === "1";
  const countView = async () => {
    if (req.headers.get("range")) return;
    await db
      .update(resources)
      .set({ downloads: sql`${resources.downloads} + 1` })
      .where(eq(resources.id, r.id));
  };

  try {
    if (r.source === "link" && r.externalUrl) {
      await countView();
      return NextResponse.redirect(r.externalUrl, 302);
    }

    if (r.source === "upload" && r.fileId) {
      const [f] = await db.select().from(files).where(eq(files.id, r.fileId)).limit(1);
      if (!f) return new Response("File missing", { status: 404 });
      await countView();
      return fileResponse(new Uint8Array(f.data), f.mimeType, f.filename, download);
    }

    if (r.source === "generated") {
      const pdf = await renderResourcePdf(r);
      if (!pdf) return new Response("Could not generate this document", { status: 404 });
      await countView();
      return fileResponse(pdf.bytes, "application/pdf", pdf.filename, download);
    }
  } catch (err) {
    console.error("File route failed", err);
    return new Response("Something went wrong while preparing the file.", { status: 500 });
  }

  return new Response("No file has been uploaded for this item yet.", { status: 404 });
}
