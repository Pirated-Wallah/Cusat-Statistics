import { db } from "@/db";
import { ensureDb } from "@/db/bootstrap";
import { sql } from "drizzle-orm";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    await ensureDb();
    await db.execute(sql`select 1`);
    return Response.json({ ok: true });
  } catch (err) {
    console.error("Health check failed", err);
    return Response.json({ ok: false }, { status: 500 });
  }
}
