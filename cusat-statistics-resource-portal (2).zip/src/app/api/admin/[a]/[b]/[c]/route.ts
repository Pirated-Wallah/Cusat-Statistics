import type { NextRequest } from "next/server";
import { handleAdminPost } from "@/lib/admin-api";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

export async function POST(req: NextRequest, ctx: { params: Promise<{ a: string; b: string; c: string }> }) {
  const { a, b, c } = await ctx.params;
  return handleAdminPost(req, [a, b, c]);
}
