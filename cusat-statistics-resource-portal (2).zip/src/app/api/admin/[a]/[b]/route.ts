import type { NextRequest } from "next/server";
import { handleAdminDelete, handleAdminPost } from "@/lib/admin-api";

export const dynamic = "force-dynamic";
export const runtime = "nodejs";

type Ctx = { params: Promise<{ a: string; b: string }> };

export async function POST(req: NextRequest, ctx: Ctx) {
  const { a, b } = await ctx.params;
  return handleAdminPost(req, [a, b]);
}

export async function DELETE(req: NextRequest, ctx: Ctx) {
  const { a, b } = await ctx.params;
  return handleAdminDelete(req, [a, b]);
}
