import Link from "next/link";
import { ArrowRight, CalendarClock, Clock, FileDown, GraduationCap, Search, Sparkles } from "lucide-react";
import { ProgramPathway, programHref, semesterHref, semesterTag, timetableHref } from "@/components/program-ui";
import { ResourceRow } from "@/components/resource-item";
import { EmptyState, SectionHeading, TYPE_ICONS, TypeIcon } from "@/components/ui";
import { isAdmin } from "@/lib/auth";
import { getRecentResources, getSemesterStats, getTotals, getUpcomingExams, listProgramsWithSemesters } from "@/lib/data";
import { EXAM_TYPES, RESOURCE_TYPES, SITE, TYPE_META, programTheme } from "@/lib/site";
import { cn, formatDate, formatTime, relativeDay, semesterInSession, todayISO } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [programs, totals, upcoming, recent, admin] = await Promise.all([
    listProgramsWithSemesters(),
    getTotals(),
    getUpcomingExams(8),
    getRecentResources(6, { uploadsOnly: true }),
    isAdmin(),
  ]);
  const stats = await getSemesterStats(programs.flatMap((p) => p.semesters.map((s) => s.contentId)));
  const today = todayISO();
  const heroStats = [
    { label: "Papers", value: totals.papers, hint: "with module-wise syllabus" },
    { label: "Notes", value: totals.counts.notes, hint: "module-wise" },
    { label: "PYQs", value: totals.counts.pyq, hint: "previous year papers" },
    { label: "Internal papers", value: totals.counts.internal, hint: "test I & II" },
    { label: "Textbooks", value: totals.counts.textbook, hint: "incl. free PDFs" },
    { label: "Syllabus PDFs", value: totals.counts.syllabus, hint: "every paper" },
  ];

  return (
    <div>
      <section className="relative overflow-hidden border-b border-slate-200 bg-white">
        <div className="pointer-events-none absolute -right-40 -top-40 h-[480px] w-[480px] rounded-full bg-indigo-200/40 blur-3xl" />
        <div className="pointer-events-none absolute -bottom-48 left-1/3 h-[380px] w-[380px] rounded-full bg-emerald-200/30 blur-3xl" />
        <div className="relative mx-auto grid max-w-7xl gap-10 px-4 py-12 sm:px-6 lg:grid-cols-[1.35fr_1fr] lg:items-center lg:py-16">
          <div>
            <span className="inline-flex items-center gap-2 rounded-full bg-indigo-50 px-3 py-1 text-xs font-semibold text-indigo-700 ring-1 ring-indigo-200">
              <Sparkles className="h-3.5 w-3.5" aria-hidden />
              {SITE.department}, {SITE.institutionShort}
            </span>
            <h1 className="mt-4 text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl">
              Statistics study material,{" "}
              <span className="bg-linear-to-r from-indigo-600 to-emerald-600 bg-clip-text text-transparent">semester by semester.</span>
            </h1>
            <p className="mt-4 max-w-xl text-lg text-slate-600">{SITE.tagline}</p>
            <form action="/browse" className="mt-6 flex max-w-xl gap-2" role="search">
              <label className="relative flex-1">
                <span className="sr-only">Search</span>
                <Search className="pointer-events-none absolute left-3.5 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" aria-hidden />
                <input name="q" className="input py-3 pl-11 text-base" placeholder="Try 'Stochastic', 'Sampling 2024', 'Module III'..." />
              </label>
              <button className="btn btn-primary px-5">Search</button>
            </form>
            <div className="mt-5 flex flex-wrap gap-2">
              {RESOURCE_TYPES.map((t) => {
                const Icon = TYPE_ICONS[t];
                return (
                  <Link
                    key={t}
                    href={t === "timetable" ? "/timetable" : `/browse?type=${t}`}
                    className="inline-flex items-center gap-1.5 rounded-full bg-white px-3 py-1.5 text-sm font-medium text-slate-700 ring-1 ring-slate-200 transition hover:text-indigo-700 hover:ring-indigo-300"
                  >
                    <Icon className="h-4 w-4" aria-hidden />
                    {TYPE_META[t].short}
                  </Link>
                );
              })}
            </div>
          </div>
          <div className="card grid grid-cols-2 gap-px overflow-hidden bg-slate-200/70">
            {heroStats.map((s) => (
              <div key={s.label} className="bg-white p-5">
                <p className="text-3xl font-bold tracking-tight text-slate-900">{s.value}</p>
                <p className="text-sm font-semibold text-slate-700">{s.label}</p>
                <p className="text-xs text-slate-500">{s.hint}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="mx-auto max-w-7xl space-y-14 px-4 py-12 sm:px-6">
        <section>
          <SectionHeading title="Choose your programme" subtitle="Each programme has its own semesters; open one to see every paper's syllabus, notes, PYQs, internals, textbooks and timetable." />
          <div className="grid gap-6 lg:grid-cols-2">
            {programs.map((p) => {
              const theme = programTheme(p.sortOrder);
              const ids = Array.from(new Set(p.semesters.map((s) => s.contentId)));
              const sum = ids.reduce(
                (acc, id) => {
                  const s = stats.get(id);
                  if (s) {
                    acc.papers += s.subjectCount;
                    acc.notes += s.counts.notes;
                    acc.pyq += s.counts.pyq;
                    acc.internal += s.counts.internal;
                    acc.books += s.counts.textbook;
                  }
                  return acc;
                },
                { papers: 0, notes: 0, pyq: 0, internal: 0, books: 0 },
              );
              const live = p.semesters.filter((s) => semesterInSession(s.number, today));
              const joint = p.semesters.filter((s) => s.linked);
              return (
                <article key={p.id} className="card flex flex-col overflow-hidden">
                  <Link href={programHref(p.slug)} className={cn("relative block bg-linear-to-br p-6 text-white", theme.gradient)}>
                    <GraduationCap className="absolute right-5 top-5 h-16 w-16 text-white/15" aria-hidden />
                    <p className="text-xs font-semibold uppercase tracking-widest text-white/80">
                      {p.durationYears} years · {p.totalSemesters} semesters
                    </p>
                    <h3 className="mt-1 text-2xl font-bold">{p.name}</h3>
                    <p className="mt-2 line-clamp-3 max-w-lg text-sm text-white/90">{p.description}</p>
                  </Link>
                  <div className="flex flex-1 flex-col p-5">
                    <dl className="grid grid-cols-5 gap-2 text-center">
                      {[
                        ["Papers", sum.papers],
                        ["Notes", sum.notes],
                        ["PYQs", sum.pyq],
                        ["Internals", sum.internal],
                        ["Books", sum.books],
                      ].map(([label, value]) => (
                        <div key={label} className="flex flex-col-reverse rounded-xl bg-slate-50 py-2">
                          <dt className="text-[11px] text-slate-500">{label}</dt>
                          <dd className="text-lg font-bold text-slate-900">{value}</dd>
                        </div>
                      ))}
                    </dl>
                    <p className="mt-4 text-xs font-semibold uppercase tracking-wide text-slate-500">Semesters</p>
                    <div className="mt-2 flex flex-wrap gap-1.5">
                      {p.semesters.map((s) => (
                        <Link
                          key={s.id}
                          href={semesterHref(p.slug, s.number)}
                          title={s.linked ? `Joint with ${s.linked.programName} Semester ${s.linked.number}` : s.title}
                          className={cn(
                            "inline-flex items-center gap-1 rounded-lg px-2.5 py-1 text-sm font-semibold ring-1 ring-inset transition",
                            s.linked ? "bg-violet-50 text-violet-700 ring-violet-200 hover:bg-violet-100" : "bg-white text-slate-700 ring-slate-200 hover:bg-slate-50",
                          )}
                        >
                          {semesterInSession(s.number, today) && <span className="h-1.5 w-1.5 rounded-full bg-emerald-500" aria-hidden />}
                          S{s.number}
                        </Link>
                      ))}
                    </div>
                    {joint.length > 0 && (
                      <p className="mt-3 rounded-xl bg-violet-50 px-3 py-2 text-xs text-violet-800">
                        Semesters {joint[0].number}-{joint[joint.length - 1].number} are joint with {joint[0].linked?.programName} Semesters{" "}
                        {joint[0].linked?.number}-{joint[joint.length - 1].linked?.number} (same classes, papers and exams).
                      </p>
                    )}
                    {live.length > 0 && (
                      <p className="mt-2 text-xs text-slate-500">In session now: {live.map((s) => `Sem ${s.number}`).join(", ")}</p>
                    )}
                    <div className="mt-auto flex flex-wrap gap-2 pt-5">
                      <Link href={programHref(p.slug)} className="btn btn-primary flex-1">
                        Open {p.shortName || p.name} <ArrowRight className="h-4 w-4" aria-hidden />
                      </Link>
                      <a href={`/api/pdf/programme?program=${p.slug}`} target="_blank" rel="noopener noreferrer" className="btn btn-secondary">
                        <FileDown className="h-4 w-4" aria-hidden /> Full syllabus
                      </a>
                    </div>
                  </div>
                </article>
              );
            })}
          </div>
        </section>

        <section className="card p-5 sm:p-6">
          <SectionHeading
            title="How the programmes connect"
            subtitle="Integrated M.Sc. students study their own papers for three years, then join the M.Sc. Statistics batch from Semester 7."
          />
          <ProgramPathway programs={programs} today={today} />
        </section>

        <section className="grid gap-6 lg:grid-cols-[1fr_1.4fr]">
          <div className="card p-5">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="flex items-center gap-2 text-lg font-bold text-slate-900">
                <CalendarClock className="h-5 w-5 text-rose-500" aria-hidden /> Upcoming exams
              </h2>
              <Link href="/timetable" className="text-sm font-semibold text-indigo-600 hover:text-indigo-500">
                All timetables
              </Link>
            </div>
            {upcoming.length ? (
              <ul className="space-y-2.5">
                {upcoming.map((e) => (
                  <li key={e.id}>
                    <Link
                      href={timetableHref(e.programSlug, e.semesterNumber)}
                      className="flex items-center gap-3 rounded-xl border border-slate-100 p-3 transition hover:border-indigo-200 hover:bg-indigo-50/30"
                    >
                      <span
                        className={cn(
                          "inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-linear-to-br text-xs font-bold text-white",
                          programTheme(e.programSort).gradient,
                        )}
                      >
                        S{e.semesterNumber}
                      </span>
                      <span className="min-w-0 flex-1">
                        <span className="block truncate text-sm font-semibold text-slate-900">{e.subjectName ?? e.title}</span>
                        <span className="block truncate text-xs text-slate-500">{semesterTag(e.programShort, e.semesterNumber, e.aliasLabel)}</span>
                        <span className="flex items-center gap-1 text-xs text-slate-500">
                          <Clock className="h-3 w-3" aria-hidden />
                          {formatDate(e.examDate)} · {formatTime(e.startTime)} · {EXAM_TYPES[e.examType]?.label ?? e.examType}
                        </span>
                      </span>
                      <span className="shrink-0 rounded-full bg-indigo-50 px-2 py-0.5 text-xs font-semibold text-indigo-700">{relativeDay(e.examDate, today)}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            ) : (
              <EmptyState icon={CalendarClock} title="No upcoming exams" />
            )}
          </div>

          <div className="card p-5">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-bold text-slate-900">Recently uploaded</h2>
              <Link href="/browse" className="text-sm font-semibold text-indigo-600 hover:text-indigo-500">
                Browse everything
              </Link>
            </div>
            <div className="space-y-2.5">
              {recent.map((r) => (
                <ResourceRow key={r.id} item={r} showSemester showSubject isAdmin={admin} />
              ))}
              {!recent.length && (
                <EmptyState title="No uploads yet">
                  Class notes, previous year papers and internal papers uploaded by the admin will appear here. Every paper already has its syllabus,
                  textbook list and sample papers.
                </EmptyState>
              )}
            </div>
          </div>
        </section>

        <section>
          <SectionHeading title="Browse by category" subtitle="Jump straight to what you need across both programmes." />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {RESOURCE_TYPES.map((t) => (
              <Link
                key={t}
                href={t === "timetable" ? "/timetable" : `/browse?type=${t}`}
                className="card group flex items-center gap-4 p-5 transition hover:-translate-y-0.5 hover:shadow-md"
              >
                <TypeIcon type={t} size="lg" />
                <span className="min-w-0 flex-1">
                  <span className="block font-semibold text-slate-900">{TYPE_META[t].plural}</span>
                  <span className="block text-sm text-slate-500">{TYPE_META[t].description}</span>
                </span>
                <span className="text-right">
                  <span className="block text-2xl font-bold text-slate-900">{totals.counts[t]}</span>
                  <ArrowRight className="ml-auto h-4 w-4 text-slate-300 transition group-hover:translate-x-0.5 group-hover:text-indigo-500" aria-hidden />
                </span>
              </Link>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
}
