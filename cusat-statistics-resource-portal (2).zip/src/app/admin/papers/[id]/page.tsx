import Link from "next/link";
import { notFound } from "next/navigation";
import { Eye, FileDown, Trash2, Upload } from "lucide-react";
import { PaperFields, UnitFields } from "@/components/admin-fields";
import { ApiButton, ApiForm } from "@/components/client";
import { Breadcrumbs } from "@/components/ui";
import { getSubjectDetail } from "@/lib/data";
import { toRoman } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function AdminPaperPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const sid = Number(id);
  if (!Number.isInteger(sid)) notFound();
  const detail = await getSubjectDetail(sid);
  if (!detail) notFound();
  const { subject, semester, program, units } = detail;

  return (
    <div className="space-y-6">
      <Breadcrumbs
        items={[
          { label: "Admin", href: "/admin" },
          { label: "Papers & syllabus", href: "/admin/papers" },
          { label: `${program.shortName} Semester ${semester.number}` },
          { label: subject.code },
        ]}
      />
      <div className="grid gap-6 lg:grid-cols-[1fr_1.3fr]">
        <section className="card h-fit p-5">
          <h2 className="text-lg font-bold text-slate-900">Paper details</h2>
          <ApiForm action={`/api/admin/subjects/${subject.id}`} successMessage="Paper updated." className="mt-4 grid gap-3 sm:grid-cols-2">
            <PaperFields defaults={subject} withOrder />
            <div className="sm:col-span-2">
              <button className="btn btn-primary">Save changes</button>
            </div>
          </ApiForm>
          <div className="mt-5 flex flex-wrap gap-2 border-t border-slate-100 pt-4">
            <Link href={`/paper/${subject.id}`} className="btn btn-secondary btn-sm">
              <Eye className="h-3.5 w-3.5" aria-hidden /> View paper page
            </Link>
            <Link href={`/admin?semesterId=${semester.id}&subject=${subject.id}`} className="btn btn-secondary btn-sm">
              <Upload className="h-3.5 w-3.5" aria-hidden /> Upload material
            </Link>
            <a href={`/api/pdf/syllabus?subject=${subject.id}`} target="_blank" rel="noopener noreferrer" className="btn btn-secondary btn-sm">
              <FileDown className="h-3.5 w-3.5" aria-hidden /> Preview syllabus PDF
            </a>
          </div>
        </section>

        <section className="space-y-4">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Syllabus modules</h2>
            <p className="text-sm text-slate-500">Write one topic per line. The paper page, syllabus PDFs and practice papers update instantly.</p>
          </div>
          {units.map((u) => (
            <div key={u.id} className="card p-5">
              <div className="mb-3 flex items-center justify-between gap-2">
                <p className="text-sm font-bold text-slate-700">
                  Module {toRoman(u.unitNo)} · {u.title}
                </p>
                <ApiButton
                  endpoint={`/api/admin/units/${u.id}`}
                  method="DELETE"
                  confirmMessage={`Delete Module ${toRoman(u.unitNo)} (${u.title})?`}
                  className="btn btn-ghost btn-sm text-rose-600 hover:bg-rose-50"
                  title="Delete module"
                >
                  <Trash2 className="h-3.5 w-3.5" aria-hidden />
                </ApiButton>
              </div>
              <ApiForm action={`/api/admin/units/${u.id}`} successMessage="Module saved." className="grid gap-3 sm:grid-cols-[90px_1fr_100px]">
                <UnitFields defaults={u} />
                <div className="sm:col-span-3">
                  <button className="btn btn-primary btn-sm">Save module</button>
                </div>
              </ApiForm>
            </div>
          ))}
          <div className="card border-dashed p-5">
            <h3 className="mb-3 font-bold text-slate-900">Add a module</h3>
            <ApiForm
              action={`/api/admin/subjects/${subject.id}/units`}
              resetOnSuccess
              successMessage="Module added."
              className="grid gap-3 sm:grid-cols-[90px_1fr_100px]"
            >
              <UnitFields defaults={{ unitNo: (units[units.length - 1]?.unitNo ?? 0) + 1 }} />
              <div className="sm:col-span-3">
                <button className="btn btn-primary btn-sm">Add module</button>
              </div>
            </ApiForm>
          </div>
        </section>
      </div>
    </div>
  );
}
