import Link from "next/link";
import { Eye, Link as LinkIcon, Pencil, Plus, Trash2 } from "lucide-react";
import { PaperFields, SemesterFields } from "@/components/admin-fields";
import { ApiButton, ApiForm } from "@/components/client";
import { semesterHref } from "@/components/program-ui";
import { KindBadge, semesterSubtitle } from "@/components/ui";
import { contentSemesters, getSubjectsWithCounts, listProgramsWithSemesters } from "@/lib/data";
import { RESOURCE_TYPES, programTheme } from "@/lib/site";
import { cn } from "@/lib/utils";

export const dynamic = "force-dynamic";

export default async function AdminPapersPage() {
  const programs = await listProgramsWithSemesters();
  const own = contentSemesters(programs);
  const papersBySem = new Map(await Promise.all(own.map(async (s) => [s.id, await getSubjectsWithCounts(s.id)] as const)));

  return (
    <div className="space-y-10">
      {programs.map((p) => {
        const theme = programTheme(p.sortOrder);
        return (
          <section key={p.id} className="space-y-4">
            <div className={cn("rounded-2xl bg-linear-to-r px-5 py-4 text-white", theme.gradient)}>
              <p className="text-xs font-semibold uppercase tracking-widest text-white/80">
                {p.durationYears} years · {p.totalSemesters} semesters
              </p>
              <h2 className="text-xl font-bold">{p.name}</h2>
            </div>

            {p.semesters.map((s) => {
              if (s.linked) {
                return (
                  <div key={s.id} className="card flex flex-wrap items-center gap-3 border-violet-200 bg-violet-50/50 px-5 py-4">
                    <LinkIcon className="h-5 w-5 text-violet-600" aria-hidden />
                    <div className="min-w-0 flex-1">
                      <p className="font-semibold text-slate-900">
                        Semester {s.number} · {semesterSubtitle(s.title)}
                      </p>
                      <p className="text-sm text-violet-800">
                        Shares classes with {s.linked.programName} Semester {s.linked.number}. Its papers, files, timetable and exams are managed there.
                      </p>
                    </div>
                    <a href={`#sem-${s.linked.id}`} className="btn btn-secondary btn-sm">
                      Manage {s.linked.programShort} Sem {s.linked.number}
                    </a>
                    <ApiButton
                      endpoint={`/api/admin/semesters/${s.id}`}
                      method="DELETE"
                      confirmMessage={`Remove ${p.name} Semester ${s.number}? The shared ${s.linked.programName} semester is not affected.`}
                      className="btn btn-ghost btn-sm text-rose-600 hover:bg-rose-50"
                      title="Delete semester"
                    >
                      <Trash2 className="h-3.5 w-3.5" aria-hidden />
                    </ApiButton>
                  </div>
                );
              }
              const papers = papersBySem.get(s.id) ?? [];
              const credits = papers.reduce((acc, x) => acc + x.credits, 0);
              const shared = own.find((o) => o.id === s.id)?.sharedWith ?? [];
              return (
                <div key={s.id} id={`sem-${s.id}`} className="card scroll-mt-24 overflow-hidden">
                  <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 bg-slate-50/70 px-5 py-3">
                    <div>
                      <p className="font-bold text-slate-900">
                        Semester {s.number} · {semesterSubtitle(s.title)}
                      </p>
                      <p className="text-xs text-slate-500">
                        {s.session || "No session set"} · {papers.length} papers · {credits} credits
                        {shared.length ? ` · also ${shared.map((x) => `${x.programShort} Sem ${x.number}`).join(", ")}` : ""}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      <Link href={semesterHref(p.slug, s.number)} className="btn btn-secondary btn-sm">
                        <Eye className="h-3.5 w-3.5" aria-hidden /> View
                      </Link>
                      <ApiButton
                        endpoint={`/api/admin/semesters/${s.id}`}
                        method="DELETE"
                        confirmMessage={`Delete ${p.name} Semester ${s.number} with ALL its papers, uploaded files and timetable?${shared.length ? " Linked semesters will lose their shared content." : ""} This cannot be undone.`}
                        className="btn btn-ghost btn-sm text-rose-600 hover:bg-rose-50"
                        title={`Delete Semester ${s.number}`}
                      >
                        <Trash2 className="h-3.5 w-3.5" aria-hidden />
                      </ApiButton>
                    </div>
                  </div>

                  <div className="divide-y divide-slate-100">
                    {papers.map((x) => {
                      const items = RESOURCE_TYPES.reduce((acc, t) => acc + x.counts[t], 0);
                      return (
                        <div key={x.id} className="flex flex-wrap items-center gap-3 px-5 py-3">
                          <span className="w-24 shrink-0 text-xs font-bold text-slate-500">{x.code}</span>
                          <div className="min-w-0 flex-1">
                            <p className="flex flex-wrap items-center gap-2 font-semibold text-slate-900">
                              {x.name} <KindBadge kind={x.kind} />
                            </p>
                            <p className="text-xs text-slate-500">
                              {x.credits} credits · {x.unitCount} modules · {x.faculty || "No faculty set"} · {items} items
                            </p>
                          </div>
                          <Link href={`/admin/papers/${x.id}`} className="btn btn-secondary btn-sm">
                            <Pencil className="h-3.5 w-3.5" aria-hidden /> Edit & syllabus
                          </Link>
                          <ApiButton
                            endpoint={`/api/admin/subjects/${x.id}`}
                            method="DELETE"
                            confirmMessage={`Delete ${x.code} ${x.name} with its syllabus and all ${items} items? This cannot be undone.`}
                            className="btn btn-ghost btn-sm text-rose-600 hover:bg-rose-50"
                            title="Delete paper"
                          >
                            <Trash2 className="h-3.5 w-3.5" aria-hidden />
                          </ApiButton>
                        </div>
                      );
                    })}
                    {!papers.length && <p className="px-5 py-4 text-sm text-slate-500">No papers yet - add the first one below.</p>}
                  </div>

                  <div className="grid gap-4 border-t border-slate-100 bg-slate-50/60 p-5 lg:grid-cols-2">
                    <details className="rounded-xl bg-white p-4 ring-1 ring-slate-200">
                      <summary className="flex cursor-pointer items-center gap-2 text-sm font-semibold text-indigo-600">
                        <Plus className="h-4 w-4" aria-hidden /> Add a paper to Semester {s.number}
                      </summary>
                      <ApiForm action="/api/admin/subjects" resetOnSuccess successMessage="Paper added." className="mt-4 grid gap-3 sm:grid-cols-2">
                        <input type="hidden" name="semesterId" value={s.id} />
                        <PaperFields />
                        <div className="sm:col-span-2">
                          <button className="btn btn-primary">Add paper</button>
                        </div>
                      </ApiForm>
                    </details>
                    <details className="rounded-xl bg-white p-4 ring-1 ring-slate-200">
                      <summary className="flex cursor-pointer items-center gap-2 text-sm font-semibold text-slate-700">
                        <Pencil className="h-4 w-4" aria-hidden /> Edit semester details
                      </summary>
                      <ApiForm action={`/api/admin/semesters/${s.id}`} successMessage="Semester updated." className="mt-4 grid gap-3 sm:grid-cols-2">
                        <SemesterFields defaults={s} />
                        <div className="sm:col-span-2">
                          <button className="btn btn-primary">Save</button>
                        </div>
                      </ApiForm>
                    </details>
                  </div>
                </div>
              );
            })}
          </section>
        );
      })}

      <section className="card p-5">
        <h2 className="font-bold text-slate-900">Add a semester</h2>
        <p className="mt-1 text-sm text-slate-500">
          Create a new semester for a programme. If its students attend another programme&apos;s classes, link it so everything is shared.
        </p>
        <ApiForm action="/api/admin/semesters" resetOnSuccess successMessage="Semester created." className="mt-4 grid gap-3 sm:grid-cols-2">
          <SemesterFields
            create={{
              programs: programs.map((p) => ({ id: p.id, name: p.name })),
              linkOptions: own.map((s) => ({ id: s.id, label: `${s.program.name} Semester ${s.number}` })),
            }}
          />
          <div className="sm:col-span-2">
            <button className="btn btn-primary">
              <Plus className="h-4 w-4" aria-hidden /> Create semester
            </button>
          </div>
        </ApiForm>
      </section>
    </div>
  );
}
