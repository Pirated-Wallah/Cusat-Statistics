import Link from "next/link";
import { eq, sql } from "drizzle-orm";
import { CalendarDays, FolderOpen, ListChecks, Sparkles, Trash2 } from "lucide-react";
import { ApiButton } from "@/components/client";
import { ResourceRow } from "@/components/resource-item";
import { UploadForm } from "@/components/upload-form";
import { EmptyState } from "@/components/ui";
import { db } from "@/db";
import { ensureDb } from "@/db/bootstrap";
import { resources } from "@/db/schema";
import { contentSemesters, getRecentResources, getTotals, listAllSubjects, listProgramsWithSemesters } from "@/lib/data";
import { SITE, TYPE_META, isResourceType } from "@/lib/site";
import { firstParam, toInt } from "@/lib/utils";

export const dynamic = "force-dynamic";

type Props = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export default async function AdminHomePage({ searchParams }: Props) {
  const sp = await searchParams;
  await ensureDb();
  const [programs, subs, totals, recent, sampleRows] = await Promise.all([
    listProgramsWithSemesters(),
    listAllSubjects(),
    getTotals(),
    getRecentResources(8, { uploadsOnly: true }),
    db.select({ n: sql<number>`count(*)::int` }).from(resources).where(eq(resources.isSample, true)),
  ]);
  const samples = sampleRows[0]?.n ?? 0;

  // Uploads always go to the semester that holds the content (M.Sc. Sem 1 also serves Integrated Sem 7).
  const uploadSemesters = contentSemesters(programs).map((s) => ({
    id: s.id,
    group: s.program.name,
    label: `Semester ${s.number}${s.sharedWith.length ? ` (also ${s.sharedWith.map((x) => `${x.programShort} Sem ${x.number}`).join(", ")})` : ""}`,
  }));

  const semParam = toInt(firstParam(sp.semesterId));
  const subjectId = toInt(firstParam(sp.subject));
  const typeParam = firstParam(sp.type);
  const anySem = programs.flatMap((p) => p.semesters).find((s) => s.id === semParam);
  const defaults = {
    type: isResourceType(typeParam) ? typeParam : undefined,
    semesterId: subs.find((s) => s.id === subjectId)?.semesterId ?? anySem?.contentId,
    subjectId: subjectId && subs.some((s) => s.id === subjectId) ? subjectId : undefined,
  };

  const stats = [
    { label: "Programmes", value: programs.length },
    { label: "Semesters", value: programs.reduce((acc, p) => acc + p.semesters.length, 0) },
    { label: "Papers", value: totals.papers },
    { label: TYPE_META.notes.plural, value: totals.counts.notes },
    { label: "PYQs", value: totals.counts.pyq },
    { label: "Internals", value: totals.counts.internal },
  ];

  return (
    <div className="grid gap-6 lg:grid-cols-[1.6fr_1fr]">
      <section className="card p-5 sm:p-6">
        <h2 className="text-lg font-bold text-slate-900">Upload study material</h2>
        <p className="mb-5 text-sm text-slate-500">
          Notes, previous year papers, internal papers, textbook PDFs, syllabus or timetables. Material for M.Sc. Semesters 1-4 automatically
          appears in Integrated M.Sc. Semesters 7-10 too.
        </p>
        <UploadForm key={JSON.stringify(defaults)} semesters={uploadSemesters} subjects={subs} defaults={defaults} maxMb={SITE.maxUploadMb} />
      </section>

      <div className="space-y-6">
        <section className="card p-5">
          <h2 className="mb-3 font-bold text-slate-900">Portal at a glance</h2>
          <div className="grid grid-cols-3 gap-2">
            {stats.map((s) => (
              <div key={s.label} className="rounded-xl bg-slate-50 px-3 py-2">
                <p className="text-xl font-bold text-slate-900">{s.value}</p>
                <p className="text-[11px] text-slate-500">{s.label}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="card p-5">
          <h2 className="mb-3 font-bold text-slate-900">Manage</h2>
          <div className="grid gap-2">
            <Link href="/admin/papers" className="flex items-center gap-3 rounded-xl p-2.5 transition hover:bg-slate-50">
              <ListChecks className="h-5 w-5 text-violet-600" aria-hidden />
              <span>
                <span className="block text-sm font-semibold text-slate-900">Papers & syllabus</span>
                <span className="block text-xs text-slate-500">Programmes, semesters, papers and module-wise topics</span>
              </span>
            </Link>
            <Link href="/admin/timetable" className="flex items-center gap-3 rounded-xl p-2.5 transition hover:bg-slate-50">
              <CalendarDays className="h-5 w-5 text-rose-600" aria-hidden />
              <span>
                <span className="block text-sm font-semibold text-slate-900">Timetables</span>
                <span className="block text-xs text-slate-500">Weekly classes, internal tests, practicals and end-semester exams</span>
              </span>
            </Link>
            <Link href="/browse" className="flex items-center gap-3 rounded-xl p-2.5 transition hover:bg-slate-50">
              <FolderOpen className="h-5 w-5 text-indigo-600" aria-hidden />
              <span>
                <span className="block text-sm font-semibold text-slate-900">All material</span>
                <span className="block text-xs text-slate-500">Browse, replace or delete any file (delete buttons appear while logged in)</span>
              </span>
            </Link>
          </div>
        </section>

        {samples > 0 && (
          <section className="card border-amber-200 bg-amber-50/60 p-5">
            <h2 className="flex items-center gap-2 font-bold text-amber-900">
              <Sparkles className="h-4 w-4" aria-hidden /> Practice content
            </h2>
            <p className="mt-1 text-sm text-amber-800">
              {samples} sample notes, PYQs and internal papers were generated from the syllabus so students have something to practise with. Remove
              them once real files are uploaded. Syllabus, timetables and textbooks are kept.
            </p>
            <ApiButton
              endpoint="/api/admin/resources/clear-samples"
              confirmMessage={`Remove all ${samples} sample items? Your uploads, syllabus, timetables and textbooks are not affected.`}
              className="btn btn-danger btn-sm mt-3"
            >
              <Trash2 className="h-3.5 w-3.5" aria-hidden /> Remove sample content
            </ApiButton>
          </section>
        )}

        <section className="card p-5">
          <h2 className="mb-3 font-bold text-slate-900">Your recent uploads</h2>
          <div className="space-y-2">
            {recent.map((r) => (
              <ResourceRow key={r.id} item={r} showSemester showSubject isAdmin />
            ))}
            {!recent.length && <EmptyState title="Nothing uploaded yet">Use the form to publish your first PDF.</EmptyState>}
          </div>
        </section>
      </div>
    </div>
  );
}
