import Link from "next/link";
import { Eye, Trash2 } from "lucide-react";
import { ApiButton, ApiForm } from "@/components/client";
import { timetableHref } from "@/components/program-ui";
import { ExamSchedule } from "@/components/timetable-view";
import { EmptyState, PillNav } from "@/components/ui";
import { contentSemesters, getTimetableData, listProgramsWithSemesters } from "@/lib/data";
import { DAYS, EXAM_TYPES, SLOT_KINDS } from "@/lib/site";
import { addDaysISO, firstParam, formatTime, semesterInSession, toInt, todayISO } from "@/lib/utils";

export const dynamic = "force-dynamic";

type Props = { searchParams: Promise<Record<string, string | string[] | undefined>> };

export default async function AdminTimetablePage({ searchParams }: Props) {
  const sp = await searchParams;
  const programs = await listProgramsWithSemesters();
  const own = contentSemesters(programs);
  const today = todayISO();
  const wanted = toInt(firstParam(sp.semesterId));
  const wantedNode = programs.flatMap((p) => p.semesters).find((s) => s.id === wanted);
  const semester = own.find((s) => s.id === wantedNode?.contentId) ?? own.find((s) => semesterInSession(s.number, today)) ?? own[0];
  if (!semester) return <EmptyState title="Add a semester first">Create semesters from the Papers & syllabus tab.</EmptyState>;

  const tt = await getTimetableData(semester.id);
  const byId = new Map(tt.subjects.map((s) => [s.id, s]));
  const heading = `${semester.program.name} Semester ${semester.number}`;

  return (
    <div className="space-y-6">
      <div className="space-y-3">
        {programs.map((p) => {
          const items = own.filter((s) => s.program.id === p.id);
          if (!items.length) return null;
          return (
            <div key={p.id} className="flex flex-wrap items-center gap-3">
              <span className="w-40 shrink-0 text-sm font-semibold text-slate-600">{p.name}</span>
              <div className="min-w-0 flex-1">
                <PillNav
                  items={items.map((s) => ({
                    href: `/admin/timetable?semesterId=${s.id}`,
                    label: `Sem ${s.number}`,
                    hint: s.sharedWith.length ? `+ ${s.sharedWith.map((x) => `${x.programShort} ${x.number}`).join(", ")}` : undefined,
                    active: s.id === semester.id,
                    activeClass: "bg-indigo-600",
                  }))}
                />
              </div>
            </div>
          );
        })}
      </div>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-slate-500">
          Editing <span className="font-semibold text-slate-900">{heading}</span>
          {semester.sharedWith.length > 0 &&
            ` - also used by ${semester.sharedWith.map((x) => `${x.programName} Semester ${x.number}`).join(", ")}`}
        </p>
        <Link href={timetableHref(semester.program.slug, semester.number)} className="btn btn-secondary btn-sm">
          <Eye className="h-3.5 w-3.5" aria-hidden /> View public timetable
        </Link>
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className="card h-fit p-5">
          <h2 className="text-lg font-bold text-slate-900">Weekly classes · {heading}</h2>
          <p className="text-sm text-slate-500">Add each period. Practicals can span multiple periods (e.g. 1:30 PM - 3:30 PM).</p>
          <ApiForm action="/api/admin/slots" successMessage="Class added." className="mt-4 grid gap-3 sm:grid-cols-2">
            <input type="hidden" name="semesterId" value={semester.id} />
            <label className="block">
              <span className="label">Day</span>
              <select name="day" className="input" defaultValue="1">
                {[1, 2, 3, 4, 5, 6].map((d) => (
                  <option key={d} value={d}>
                    {DAYS[d]}
                  </option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="label">Type</span>
              <select name="kind" className="input" defaultValue="theory">
                {Object.entries(SLOT_KINDS).map(([k, v]) => (
                  <option key={k} value={k}>
                    {v}
                  </option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="label">Start</span>
              <input type="time" name="startTime" required defaultValue="09:30" className="input" />
            </label>
            <label className="block">
              <span className="label">End</span>
              <input type="time" name="endTime" required defaultValue="10:30" className="input" />
            </label>
            <label className="block sm:col-span-2">
              <span className="label">Paper</span>
              <select name="subjectId" className="input" defaultValue="">
                <option value="">None - use the label below</option>
                {tt.subjects.map((s) => (
                  <option key={s.id} value={s.id}>
                    {s.code} - {s.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="block">
              <span className="label">Label (if no paper)</span>
              <input name="label" className="input" placeholder="e.g. Elective I, Library, Seminar" />
            </label>
            <label className="block">
              <span className="label">Room</span>
              <input name="room" className="input" placeholder="e.g. PG-1, Computer Lab" />
            </label>
            <div className="sm:col-span-2">
              <button className="btn btn-primary">Add class</button>
            </div>
          </ApiForm>

          <div className="mt-6 space-y-4">
            {[1, 2, 3, 4, 5, 6].map((d) => {
              const list = tt.slots.filter((s) => s.day === d);
              if (!list.length) return null;
              return (
                <div key={d}>
                  <h3 className="mb-2 text-sm font-bold text-slate-700">{DAYS[d]}</h3>
                  <ul className="divide-y divide-slate-100 rounded-xl border border-slate-200">
                    {list.map((s) => {
                      const sub = s.subjectId ? byId.get(s.subjectId) : undefined;
                      return (
                        <li key={s.id} className="flex items-center gap-3 px-3 py-2 text-sm">
                          <span className="w-36 shrink-0 font-medium text-slate-600">
                            {formatTime(s.startTime)} - {formatTime(s.endTime)}
                          </span>
                          <span className="min-w-0 flex-1 truncate text-slate-900">
                            {sub ? `${sub.code} ${sub.name}` : s.label}
                            <span className="text-xs text-slate-400">
                              {" "}
                              · {SLOT_KINDS[s.kind] ?? s.kind}
                              {s.room ? ` · ${s.room}` : ""}
                            </span>
                          </span>
                          <ApiButton
                            endpoint={`/api/admin/slots/${s.id}`}
                            method="DELETE"
                            className="btn btn-ghost btn-sm text-rose-600 hover:bg-rose-50"
                            title="Remove class"
                          >
                            <Trash2 className="h-3.5 w-3.5" aria-hidden />
                          </ApiButton>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              );
            })}
            {!tt.slots.length && <p className="text-sm text-slate-500">No classes added yet.</p>}
          </div>
        </section>

        <section className="space-y-5">
          <div className="card p-5">
            <h2 className="text-lg font-bold text-slate-900">Schedule an exam</h2>
            <p className="text-sm text-slate-500">Internal tests, model exams, practicals, project viva and end-semester exams.</p>
            <ApiForm action="/api/admin/exams" successMessage="Exam scheduled." className="mt-4 grid gap-3 sm:grid-cols-2">
              <input type="hidden" name="semesterId" value={semester.id} />
              <label className="block">
                <span className="label">Exam</span>
                <select name="examType" className="input" defaultValue="internal1">
                  {Object.entries(EXAM_TYPES).map(([k, v]) => (
                    <option key={k} value={k}>
                      {v.label}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block">
                <span className="label">Date</span>
                <input type="date" name="examDate" required defaultValue={addDaysISO(today, 7)} className="input" />
              </label>
              <label className="block sm:col-span-2">
                <span className="label">Paper</span>
                <select name="subjectId" className="input" defaultValue="">
                  <option value="">None - use the title below</option>
                  {tt.subjects.map((s) => (
                    <option key={s.id} value={s.id}>
                      {s.code} - {s.name}
                    </option>
                  ))}
                </select>
              </label>
              <label className="block sm:col-span-2">
                <span className="label">Title (if no paper)</span>
                <input name="title" className="input" placeholder="e.g. Comprehensive viva voce" />
              </label>
              <label className="block">
                <span className="label">Start</span>
                <input type="time" name="startTime" required defaultValue="09:30" className="input" />
              </label>
              <label className="block">
                <span className="label">End</span>
                <input type="time" name="endTime" required defaultValue="12:30" className="input" />
              </label>
              <label className="block sm:col-span-2">
                <span className="label">Venue</span>
                <input name="venue" className="input" placeholder="e.g. Exam Hall A" />
              </label>
              <div className="sm:col-span-2">
                <button className="btn btn-primary">Add exam</button>
              </div>
            </ApiForm>
          </div>
          <ExamSchedule data={tt} today={today} isAdmin />
        </section>
      </div>
    </div>
  );
}
