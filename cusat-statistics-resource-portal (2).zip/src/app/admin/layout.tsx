import Link from "next/link";
import type { ReactNode } from "react";
import { Lock, LogOut, ShieldCheck } from "lucide-react";
import { AdminNav, ApiButton, ApiForm } from "@/components/client";
import { isAdmin, usingDefaultPassword } from "@/lib/auth";

export const dynamic = "force-dynamic";
export const metadata = { title: "Admin" };

export default async function AdminLayout({ children }: { children: ReactNode }) {
  if (!(await isAdmin())) {
    return (
      <div className="mx-auto flex max-w-md flex-col px-4 py-16">
        <div className="card p-6 sm:p-8">
          <span className="inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600">
            <Lock className="h-6 w-6" aria-hidden />
          </span>
          <h1 className="mt-4 text-2xl font-bold text-slate-900">Admin login</h1>
          <p className="mt-1 text-sm text-slate-500">
            Log in to upload notes, PYQs, internal papers and textbook PDFs, and to manage papers, syllabus and timetables for every semester.
          </p>
          <ApiForm action="/api/admin/login" successMessage="Welcome! Loading the admin panel..." className="mt-6 grid gap-4">
            <label className="block">
              <span className="label">Password</span>
              <input type="password" name="password" required autoFocus autoComplete="current-password" className="input" />
            </label>
            <button className="btn btn-primary w-full">Log in</button>
          </ApiForm>
          {usingDefaultPassword() && (
            <p className="mt-5 rounded-xl bg-amber-50 p-3 text-xs text-amber-800 ring-1 ring-inset ring-amber-200">
              Default password is <code className="font-bold">admin123</code>. Set the <code className="font-semibold">ADMIN_PASSWORD</code> environment
              variable to change it.
            </p>
          )}
        </div>
        <Link href="/" className="mt-4 text-center text-sm text-slate-500 hover:text-indigo-600">
          Back to the portal
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
      <div className="mb-6 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-50 text-emerald-600">
            <ShieldCheck className="h-5 w-5" aria-hidden />
          </span>
          <div>
            <h1 className="text-2xl font-bold text-slate-900">Admin panel</h1>
            <p className="text-sm text-slate-500">Upload material and manage semesters, papers, syllabus and timetables.</p>
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <AdminNav
            links={[
              { href: "/admin", label: "Upload & overview" },
              { href: "/admin/papers", label: "Papers & syllabus" },
              { href: "/admin/timetable", label: "Timetables" },
            ]}
          />
          <ApiButton endpoint="/api/admin/logout" redirectTo="/" className="btn btn-secondary btn-sm">
            <LogOut className="h-3.5 w-3.5" aria-hidden /> Log out
          </ApiButton>
        </div>
      </div>
      {children}
    </div>
  );
}
