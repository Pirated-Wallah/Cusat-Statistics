import Link from "next/link";
import { SearchX } from "lucide-react";

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-xl flex-col items-center px-4 py-24 text-center">
      <span className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-50 text-indigo-600">
        <SearchX className="h-7 w-7" aria-hidden />
      </span>
      <h1 className="mt-4 text-2xl font-bold text-slate-900">Page not found</h1>
      <p className="mt-2 text-slate-500">The semester, paper or file you are looking for doesn&apos;t exist or was removed.</p>
      <div className="mt-6 flex gap-2">
        <Link href="/" className="btn btn-primary">
          Go home
        </Link>
        <Link href="/browse" className="btn btn-secondary">
          Browse material
        </Link>
      </div>
    </div>
  );
}
