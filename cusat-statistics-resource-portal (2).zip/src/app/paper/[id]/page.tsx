import Link from "next/link";
import { notFound } from "next/navigation";
import { CalendarClock, CalendarDays, Clock, FileDown, ListChecks, Pencil, Upload, User, Users } from "lucide-react";
import { semesterHref, timetableHref } from "@/components/program-ui";
import { BookCard, ResourceRow } from "@/components/resource-item";
import { Badge, Breadcrumbs, EmptyState, KindBadge, TYPE_ICONS } from "@/components/ui";
import { isAdmin } from "@/lib/auth";
import { getResourcesForSubject, getSubjectDetail, getTimetableData, listProgramsWithSemesters, sharedWithOf, type ResourceItem } from "@/lib/data";
import { EXAM_TYPES, TYPE_META, semTheme, type ResourceType } from "@/lib/site";
import { cn, firstParam, formatDate, formatTime, relativeDay, splitTopics, toRoman, todayISO } from "@/lib/utils";

export const dynamic = "force-dynamic";

const TABS: Array<{ key: ResourceType; label: string }> = [
  { key: "syllabus", label: "Syllabus" },
  { key: "notes", label: "Notes" },
  { key: "pyq", label: "PYQs" },
  { key: "internal", label: "Internals" },
  { key: "textbook", label: "Textbooks" },
];

type Props = {
  params: Promise<{ id: string }>;
  searchParams: Promise<Record<string, string | string[] | undefined>>;
};

export async function generateMetadata({ params }: Props) {
  const { id } = await params;
  const detail = Number.isInteger(Number(id)) ? await getSubjectDetail(Number(id)) : null;
  return { title: detail ? `${detail.subject.code} ${detail.subject.name}` : "Paper" };
}

function groupBy(items: ResourceItem[], keyOf: (r: ResourceItem) => string) {
  const map = new Map<string, ResourceItem[]>();
  for (const r of items) {
    const k = keyOf(r);
    map.set(k, [...(map.get(k) ?? []), r]);
  }
  return Array.from(map.entries());
}

export default async function PaperPage({ params, searchParams }: Props) {
  const { id } = await params;
  const sp = await searchParams;
  const sid = Number(id);
  if (!Number.isInteger(sid)) notFound();
  const detail = await getSubjectDetail(sid);
  if (!detail) notFound();
  const { subject, semester, program, units } = detail;

  const [items, admin, tt, all] = await Promise.all([getResourcesForSubject(sid), isAdmin(), getTimetableData(semester.id), listProgramsWithSemesters()]);
  const shared = sharedWithOf(all, semester.id);
  const tabParam = firstParam(sp.tab);
  const tab: ResourceType = TABS.find((t) => t.key === tabParam)?.key ?? "syllabus";
  const of = (t: ResourceType) => items.filter((i) => i.type === t);
  const theme = semTheme(semester.number);
  const isLab = subject.kind === "lab";
  const isProject = subject.kind === "project";
  const partLabel = (unitNo: number) => (isLab ? `Part ${unitNo}` : isProject ? "Project" : `Module ${toRoman(unitNo)}`);
  const today = todayISO();
  const totalHours = units.reduce((acc, u) => acc + u.hours, 0);
  const weeklyMinutes = tt.slots
    .filter((s) => s.subjectId === sid)
    .reduce((acc, s) => {
      const [sh, sm] = s.startTime.split(":").map(Number);
      const [eh, em] = s.endTime.split(":").map(Number);
      return acc + Math.max(0, eh * 60 + em - (sh * 60 + sm));
    }, 0);
  const upcomingExams = tt.exams.filter((e) => e.subjectId === sid && e.examDate >= today);
  const uploadHref = `/admin?semesterId=${semester.id}&subject=${sid}&type=${tab}`;

  const emptyFor = (t: ResourceType) => (
    <EmptyState icon={TYPE_ICONS[t]} title={`No ${TYPE_META[t].plural.toLowerCase()} for this paper yet`}>
      {admin ? (
        <Link href={uploadHref} className="font-semibold text-indigo-600">
          Upload {TYPE_META[t].label.toLowerCase()}
        </Link>
      ) : (
        "New material is added regularly - check back soon."
      )}
    </EmptyState>
  );

  return (
    <div>
      <section className="border-b border-slate-200 bg-white">
        <div className="mx-auto max-w-7xl px-4 pt-8 sm:px-6">
          <Breadcrumbs
            items={[
              { label: "Home", href: "/" },
              { label: program.name, href: `/p/${program.slug}` },
              { label: `Semester ${semester.number}`, href: semesterHref(program.slug, semester.number) },
              { label: subject.code },
            ]}
          />
          <div className="mt-5 flex flex-wrap items-start justify-between gap-6">
            <div className="flex items-start gap-4">
              <span
                className={cn(
                  "hidden h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-linear-to-br p-1 text-center text-sm font-black leading-tight text-white shadow-md sm:inline-flex",
                  theme.gradient,
                )}
              >
                {(subject.shortName || subject.code).slice(0, 8)}
              </span>
              <div>
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-sm font-bold text-slate-500">{subject.code}</span>
                  <KindBadge kind={subject.kind} />
                  <Badge>{subject.credits} credits</Badge>
                  <Badge className={cn(theme.soft, "ring-transparent")}>
                    {program.shortName} Sem {semester.number}
                  </Badge>
                  {shared.map((s) => (
                    <Badge key={`${s.programSlug}-${s.number}`} className="bg-violet-50 text-violet-700 ring-violet-600/20">
                      Also {s.programShort} Sem {s.number}
                    </Badge>
                  ))}
                </div>
                <h1 className="mt-1.5 text-3xl font-bold tracking-tight text-slate-900">{subject.name}</h1>
                {subject.description && <p className="mt-2 max-w-2xl text-slate-600">{subject.description}</p>}
                <div className="mt-3 flex flex-wrap gap-x-5 gap-y-1 text-sm text-slate-500">
                  <span className="inline-flex items-center gap-1.5">
                    <User className="h-4 w-4" aria-hidden /> {subject.faculty || "Faculty TBA"}
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <ListChecks className="h-4 w-4" aria-hidden /> {units.length} {isLab ? "parts" : units.length === 1 ? "module" : "modules"}
                    {totalHours ? ` · ${totalHours} hours` : ""}
                  </span>
                  {weeklyMinutes > 0 && (
                    <span className="inline-flex items-center gap-1.5">
                      <Clock className="h-4 w-4" aria-hidden /> {Math.round((weeklyMinutes / 60) * 10) / 10} hrs / week
                    </span>
                  )}
                  {shared.length > 0 && (
                    <span className="inline-flex items-center gap-1.5">
                      <Users className="h-4 w-4" aria-hidden /> Joint class with {shared.map((s) => `${s.programShort} Sem ${s.number}`).join(", ")}
                    </span>
                  )}
                </div>
              </div>
            </div>
            <div className="flex flex-wrap gap-2">
              <a href={`/api/pdf/syllabus?subject=${sid}&download=1`} className="btn btn-primary">
                <FileDown className="h-4 w-4" aria-hidden /> Syllabus PDF
              </a>
              <Link href={timetableHref(program.slug, semester.number)} className="btn btn-secondary">
                <CalendarDays className="h-4 w-4" aria-hidden /> Timetable
              </Link>
              {admin && (
                <>
                  <Link href={uploadHref} className="btn btn-secondary">
                    <Upload className="h-4 w-4" aria-hidden /> Upload
                  </Link>
                  <Link href={`/admin/papers/${sid}`} className="btn btn-ghost">
                    <Pencil className="h-4 w-4" aria-hidden /> Edit
                  </Link>
                </>
              )}
            </div>
          </div>

          <nav className="-mb-px mt-8 flex gap-1 overflow-x-auto">
            {TABS.map((t) => {
              const Icon = TYPE_ICONS[t.key];
              const count = t.key === "syllabus" ? units.length : of(t.key).length;
              const active = tab === t.key;
              return (
                <Link
                  key={t.key}
                  href={t.key === "syllabus" ? `/paper/${sid}` : `/paper/${sid}?tab=${t.key}`}
                  scroll={false}
                  className={cn(
                    "inline-flex shrink-0 items-center gap-2 border-b-2 px-4 py-3 text-sm font-semibold transition",
                    active ? "border-indigo-600 text-indigo-700" : "border-transparent text-slate-500 hover:border-slate-300 hover:text-slate-700",
                  )}
                >
                  <Icon className="h-4 w-4" aria-hidden />
                  {t.label}
                  <span className={cn("rounded-full px-1.5 text-xs", active ? "bg-indigo-100 text-indigo-700" : "bg-slate-100 text-slate-500")}>{count}</span>
                </Link>
              );
            })}
          </nav>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6">
        {tab === "syllabus" && (
          <div className="grid gap-8 lg:grid-cols-[1fr_320px]">
            <div className="space-y-4">
              {units.map((u, idx) => {
                const topics = splitTopics(u.topics);
                const notesCount = of("notes").filter((nt) => nt.unitNo === u.unitNo).length;
                return (
                  <article key={u.id} className="card p-5">
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div className="flex items-center gap-3">
                        <span className={cn("inline-flex h-10 min-w-10 items-center justify-center rounded-xl px-2 text-sm font-black", theme.soft)}>
                          {isLab ? idx + 1 : toRoman(u.unitNo)}
                        </span>
                        <div>
                          <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">{partLabel(u.unitNo)}</p>
                          <h3 className="font-bold text-slate-900">{u.title}</h3>
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        {u.hours > 0 && <Badge>{u.hours} hours</Badge>}
                        {notesCount > 0 && (
                          <Link href={`/paper/${sid}?tab=notes`} className="text-xs font-semibold text-indigo-600 hover:text-indigo-500">
                            {notesCount} notes
                          </Link>
                        )}
                      </div>
                    </div>
                    <ul className="mt-4 grid gap-x-6 gap-y-1.5 sm:grid-cols-2">
                      {topics.map((t) => (
                        <li key={t} className="flex gap-2 text-sm text-slate-600">
                          <span className={cn("mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full", theme.dot)} />
                          {t}
                        </li>
                      ))}
                    </ul>
                  </article>
                );
              })}
              {!units.length && (
                <EmptyState icon={ListChecks} title="Syllabus not added yet">
                  {admin ? (
                    <Link href={`/admin/papers/${sid}`} className="font-semibold text-indigo-600">
                      Add modules and topics
                    </Link>
                  ) : (
                    "The module-wise syllabus will appear here soon."
                  )}
                </EmptyState>
              )}
            </div>
            <aside className="space-y-5">
              <div className="card p-5">
                <h2 className="mb-3 font-bold text-slate-900">Syllabus files</h2>
                <div className="space-y-2">
                  {of("syllabus").map((r) => (
                    <ResourceRow key={r.id} item={r} showType={false} isAdmin={admin} />
                  ))}
                  {!of("syllabus").length && (
                    <a href={`/api/pdf/syllabus?subject=${sid}`} target="_blank" rel="noopener noreferrer" className="btn btn-secondary w-full">
                      <FileDown className="h-4 w-4" aria-hidden /> Open syllabus PDF
                    </a>
                  )}
                </div>
              </div>
              <div className="card p-5">
                <h2 className="mb-3 flex items-center gap-2 font-bold text-slate-900">
                  <CalendarClock className="h-4 w-4 text-rose-500" aria-hidden /> Upcoming exams
                </h2>
                {upcomingExams.length ? (
                  <ul className="space-y-2">
                    {upcomingExams.map((e) => (
                      <li key={e.id} className="rounded-xl bg-slate-50 px-3 py-2">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-sm font-semibold text-slate-900">{EXAM_TYPES[e.examType]?.label ?? e.examType}</span>
                          <span className="text-xs font-semibold text-indigo-600">{relativeDay(e.examDate, today)}</span>
                        </div>
                        <p className="text-xs text-slate-500">
                          {formatDate(e.examDate)} · {formatTime(e.startTime)}
                          {e.venue ? ` · ${e.venue}` : ""}
                        </p>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-sm text-slate-500">No upcoming exams for this paper.</p>
                )}
              </div>
              <div className="card p-5">
                <h2 className="mb-3 font-bold text-slate-900">Quick links</h2>
                <div className="grid grid-cols-2 gap-2">
                  {TABS.filter((t) => t.key !== "syllabus").map((t) => (
                    <Link key={t.key} href={`/paper/${sid}?tab=${t.key}`} className="rounded-xl bg-slate-50 px-3 py-2 text-sm transition hover:bg-indigo-50">
                      <span className="block font-bold text-slate-900">{of(t.key).length}</span>
                      <span className="text-xs text-slate-500">{t.label}</span>
                    </Link>
                  ))}
                </div>
              </div>
            </aside>
          </div>
        )}

        {tab === "notes" &&
          (of("notes").length ? (
            <div className="space-y-7">
              {groupBy(of("notes"), (r) => (r.unitNo && units.some((u) => u.unitNo === r.unitNo) ? String(r.unitNo) : "general"))
                .sort((a, b) => (a[0] === "general" ? 1 : b[0] === "general" ? -1 : Number(a[0]) - Number(b[0])))
                .map(([key, list]) => {
                  const unit = units.find((u) => String(u.unitNo) === key);
                  return (
                    <section key={key}>
                      <h2 className="mb-3 font-bold text-slate-900">{unit ? `${partLabel(unit.unitNo)} · ${unit.title}` : "General / all modules"}</h2>
                      <div className="space-y-2">
                        {list.map((r) => (
                          <ResourceRow key={r.id} item={r} showType={false} isAdmin={admin} />
                        ))}
                      </div>
                    </section>
                  );
                })}
            </div>
          ) : (
            emptyFor("notes")
          ))}

        {(tab === "pyq" || tab === "internal") &&
          (of(tab).length ? (
            <div className="space-y-7">
              {groupBy(of(tab), (r) => (r.year ? String(r.year) : "Other"))
                .sort((a, b) => (a[0] === "Other" ? 1 : b[0] === "Other" ? -1 : Number(b[0]) - Number(a[0])))
                .map(([year, list]) => (
                  <section key={year}>
                    <h2 className="mb-3 flex items-center gap-2 font-bold text-slate-900">
                      {year}
                      <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs font-semibold text-slate-500">{list.length}</span>
                    </h2>
                    <div className="space-y-2">
                      {list.map((r) => (
                        <ResourceRow key={r.id} item={r} showType={false} isAdmin={admin} />
                      ))}
                    </div>
                  </section>
                ))}
            </div>
          ) : (
            emptyFor(tab)
          ))}

        {tab === "textbook" &&
          (of("textbook").length ? (
            <div className="grid gap-4 md:grid-cols-2">
              {of("textbook").map((r) => (
                <BookCard key={r.id} item={r} isAdmin={admin} />
              ))}
            </div>
          ) : (
            emptyFor("textbook")
          ))}
      </div>
    </div>
  );
}
