import { INTEGRATED_SEMESTERS } from "./seed-integrated";
import { MSC_SEMESTERS } from "./seed-msc";
import type { SeedProgram } from "./seed-helpers";

export * from "./seed-helpers";

const INSTITUTION = "Cochin University of Science and Technology (CUSAT)";
const DEPARTMENT = "Department of Statistics";

/** Order matters: a programme must be seeded before semesters that link to it. */
export const SEED_PROGRAMS: SeedProgram[] = [
  {
    slug: "msc-statistics",
    name: "M.Sc. Statistics",
    shortName: "M.Sc.",
    durationYears: 2,
    totalSemesters: 4,
    institution: INSTITUTION,
    department: DEPARTMENT,
    description:
      "Two-year, four-semester postgraduate programme under the Credit and Semester System (50 marks continuous evaluation + 50 marks end-semester exam per paper). Up to 15 of the 25 seats go to Integrated M.Sc. students who join after their sixth semester; the rest are filled through CAT.",
    roomPrefix: "PG",
    semesters: MSC_SEMESTERS,
  },
  {
    slug: "integrated-msc-statistics",
    name: "Integrated M.Sc. Statistics",
    shortName: "Int. M.Sc.",
    durationYears: 5,
    totalSemesters: 10,
    institution: INSTITUTION,
    department: DEPARTMENT,
    description:
      "Five-year, ten-semester integrated programme. Semesters 1-6 build the undergraduate foundation in statistics, mathematics and computing. From Semester 7 students join the M.Sc. Statistics batch, so Semesters 7-10 have the same papers, classes and exams as M.Sc. Semesters 1-4.",
    roomPrefix: "IMS",
    semesters: INTEGRATED_SEMESTERS,
  },
];
