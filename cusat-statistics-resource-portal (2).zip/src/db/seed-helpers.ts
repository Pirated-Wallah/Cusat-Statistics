export type SeedUnit = { title: string; hours: number; topics: string[] };
export type SeedBook = { title: string; author: string; publisher: string; edition?: string };
export type SeedOpenBook = { title: string; author: string; url: string };
export type SeedKind = "core" | "elective" | "lab" | "project" | "minor" | "aec" | "sec";

export type SeedSubject = {
  code: string;
  name: string;
  short: string;
  kind: SeedKind;
  credits: number;
  description: string;
  /** Elective slot, e.g. "Elective I" - options of the same slot share timetable slots and exam dates. */
  group?: string;
  units: SeedUnit[];
  books: SeedBook[];
  open?: SeedOpenBook[];
};

export type SeedOwnSemester = { number: number; title: string; description: string; subjects: SeedSubject[] };
export type SeedLinkedSemester = {
  number: number;
  title: string;
  description: string;
  linkTo: { program: string; number: number };
};
export type SeedSemester = SeedOwnSemester | SeedLinkedSemester;

export type SeedProgram = {
  slug: string;
  name: string;
  shortName: string;
  durationYears: number;
  totalSemesters: number;
  institution: string;
  department: string;
  description: string;
  roomPrefix: string;
  semesters: SeedSemester[];
};

export const isLinkedSeed = (s: SeedSemester): s is SeedLinkedSemester => "linkTo" in s;

/** Module helper: topics are separated by ";" */
export const u = (title: string, hours: number, topics: string): SeedUnit => ({
  title,
  hours,
  topics: topics
    .split(";")
    .map((t) => t.trim())
    .filter(Boolean),
});
export const b = (title: string, author: string, publisher: string, edition?: string): SeedBook => ({ title, author, publisher, edition });
export const o = (title: string, author: string, url: string): SeedOpenBook => ({ title, author, url });

/* ---- Frequently prescribed books ---- */
export const BK = {
  rohatgi: b("An Introduction to Probability and Statistics", "V.K. Rohatgi & A.K.Md.E. Saleh", "Wiley", "3rd ed."),
  bhat: b("Modern Probability Theory", "B.R. Bhat", "New Age International", "4th ed."),
  lahaRohatgi: b("Probability Theory", "R.G. Laha & V.K. Rohatgi", "Wiley"),
  hogg: b("Introduction to Mathematical Statistics", "R.V. Hogg, J.W. McKean & A.T. Craig", "Pearson", "8th ed."),
  guptaKapoor: b("Fundamentals of Mathematical Statistics", "S.C. Gupta & V.K. Kapoor", "Sultan Chand & Sons", "12th ed."),
  guptaKapoorApplied: b("Fundamentals of Applied Statistics", "S.C. Gupta & V.K. Kapoor", "Sultan Chand & Sons", "4th ed."),
  goon: b("Fundamentals of Statistics, Vol. I", "A.M. Goon, M.K. Gupta & B. Dasgupta", "World Press"),
  cochran: b("Sampling Techniques", "W.G. Cochran", "Wiley", "3rd ed."),
  montgomeryDoe: b("Design and Analysis of Experiments", "D.C. Montgomery", "Wiley", "10th ed."),
  dasGiri: b("Design and Analysis of Experiments", "M.N. Das & N.C. Giri", "New Age International", "3rd ed."),
  montgomerySqc: b("Introduction to Statistical Quality Control", "D.C. Montgomery", "Wiley", "8th ed."),
  montgomeryReg: b("Introduction to Linear Regression Analysis", "D.C. Montgomery, E.A. Peck & G.G. Vining", "Wiley", "6th ed."),
  taha: b("Operations Research: An Introduction", "H.A. Taha", "Pearson", "10th ed."),
  swarup: b("Operations Research", "Kanti Swarup, P.K. Gupta & Man Mohan", "Sultan Chand & Sons"),
  brauneMurdoch: b("A First Course in Statistical Programming with R", "W.J. Braun & D.J. Murdoch", "Cambridge University Press", "2nd ed."),
  islrBook: b("An Introduction to Statistical Learning", "G. James, D. Witten, T. Hastie & R. Tibshirani", "Springer", "2nd ed."),
  lawless: b("Statistical Models and Methods for Lifetime Data", "J.F. Lawless", "Wiley", "2nd ed."),
};

/* ---- Free, legally available books (links verified) ---- */
export const OA = {
  durrettPte: o("Probability: Theory and Examples", "Rick Durrett", "https://services.math.duke.edu/~rtd/PTE/PTE5_011119.pdf"),
  durrettEosp: o("Essentials of Stochastic Processes", "Rick Durrett", "https://services.math.duke.edu/~rtd/EOSP/EOSP2E.pdf"),
  grinstead: o("Introduction to Probability", "Charles M. Grinstead & J. Laurie Snell", "https://math.dartmouth.edu/~prob/prob/prob.pdf"),
  lebl: o("Basic Analysis: Introduction to Real Analysis", "Jiri Lebl", "https://www.jirka.org/ra/"),
  vmls: o("Introduction to Applied Linear Algebra (VMLS)", "Stephen Boyd & Lieven Vandenberghe", "https://web.stanford.edu/~boyd/vmls/vmls.pdf"),
  mml: o("Mathematics for Machine Learning", "M.P. Deisenroth, A.A. Faisal & C.S. Ong", "https://mml-book.github.io/book/mml-book.pdf"),
  shalabh: o("Sampling Theory - Lecture Notes", "Shalabh (IIT Kanpur)", "https://home.iitk.ac.in/~shalab/course1.htm"),
  islr: o("An Introduction to Statistical Learning", "G. James, D. Witten, T. Hastie & R. Tibshirani", "https://www.statlearning.com/"),
  esl: o("The Elements of Statistical Learning", "T. Hastie, R. Tibshirani & J. Friedman", "https://hastie.su.domains/ElemStatLearn/"),
  rIntro: o("An Introduction to R", "R Core Team (CRAN)", "https://cran.r-project.org/doc/manuals/r-release/R-intro.pdf"),
  r4ds: o("R for Data Science (2nd ed.)", "H. Wickham, M. Cetinkaya-Rundel & G. Grolemund", "https://r4ds.hadley.nz/"),
  peng: o("R Programming for Data Science", "Roger D. Peng", "https://bookdown.org/rdpeng/rprogdatascience/"),
  bayesRules: o("Bayes Rules! An Introduction to Applied Bayesian Modeling", "A.A. Johnson, M.Q. Ott & M. Dogucu", "https://www.bayesrulesbook.com/"),
  ros: o("Regression and Other Stories", "Andrew Gelman, Jennifer Hill & Aki Vehtari", "https://users.aalto.fi/~ave/ROS.pdf"),
  shalizi: o("Advanced Data Analysis from an Elementary Point of View", "Cosma Rohilla Shalizi", "https://www.stat.cmu.edu/~cshalizi/ADAfaEPoV/"),
  fpp3: o("Forecasting: Principles and Practice (3rd ed.)", "Rob J. Hyndman & George Athanasopoulos", "https://otexts.com/fpp3/"),
  nistDoe: o("NIST/SEMATECH e-Handbook - Process Improvement (DOE)", "NIST", "https://www.itl.nist.gov/div898/handbook/pri/pri.htm"),
  nistSpc: o("NIST/SEMATECH e-Handbook - Process Monitoring and Control", "NIST", "https://www.itl.nist.gov/div898/handbook/pmc/pmc.htm"),
  nistRel: o("NIST/SEMATECH e-Handbook - Assessing Product Reliability", "NIST", "https://www.itl.nist.gov/div898/handbook/apr/apr.htm"),
  openstaxStats: o("Introductory Statistics 2e", "OpenStax (Rice University)", "https://openstax.org/details/books/introductory-statistics-2e"),
  ims: o("Introduction to Modern Statistics", "M. Cetinkaya-Rundel & J. Hardin (OpenIntro)", "https://openintro-ims.netlify.app/"),
  thinkStats: o("Think Stats (2nd ed.)", "Allen B. Downey", "https://greenteapress.com/thinkstats2/thinkstats2.pdf"),
  thinkPython: o("Think Python (2nd ed.)", "Allen B. Downey", "https://greenteapress.com/thinkpython2/thinkpython2.pdf"),
  pdsh: o("Python Data Science Handbook", "Jake VanderPlas", "https://jakevdp.github.io/PythonDataScienceHandbook/"),
  py4da: o("Python for Data Analysis (3rd ed., open access)", "Wes McKinney", "https://wesmckinney.com/book/"),
  activeCalc: o("Active Calculus", "Matthew Boelkins", "https://activecalculus.org/single/"),
  openstaxCalc: o("Calculus Volume 1", "OpenStax (Rice University)", "https://openstax.org/details/books/calculus-volume-1"),
  writing: o("Writing Guide with Handbook", "OpenStax (Rice University)", "https://openstax.org/details/books/writing-guide"),
  hnm: o("Holistic Numerical Methods", "Autar Kaw (University of South Florida)", "https://nm.mathforcollege.com/"),
  stats21: o("Statistical Thinking for the 21st Century", "Russell A. Poldrack", "https://statsthinking21.org/"),
};
