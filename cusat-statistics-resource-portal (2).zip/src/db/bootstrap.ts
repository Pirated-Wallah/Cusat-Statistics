import { drizzle, type NodePgDatabase } from "drizzle-orm/node-postgres";
import { pool } from "@/db";
import { classSlots, exams, programs, resources, semesters, subjects, syllabusUnits } from "./schema";
import { SEED_PROGRAMS, isLinkedSeed, type SeedLinkedSemester, type SeedOwnSemester, type SeedProgram } from "./seed-data";
import { addDaysISO, internalUnitRange, semesterInSession, todayISO, toRoman, weekdayISO } from "@/lib/utils";

/**
 * Data from the first version of the portal (single programme, no `program_id`)
 * is placeholder content - it is replaced by the CUSAT Statistics programmes.
 */
const LEGACY_MIGRATION = `
DO $$
BEGIN
  IF to_regclass('public.semesters') IS NOT NULL AND NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_schema = 'public' AND table_name = 'semesters' AND column_name = 'program_id'
  ) THEN
    DROP TABLE IF EXISTS "exams", "class_slots", "resources", "syllabus_units", "subjects", "semesters", "files" CASCADE;
  END IF;
END $$;
`;

/** Mirrors `drizzle-kit export` (same constraint & index names) but idempotent. */
const DDL = `
CREATE TABLE IF NOT EXISTS "programs" (
  "id" serial PRIMARY KEY NOT NULL,
  "slug" text NOT NULL,
  "name" text NOT NULL,
  "short_name" text DEFAULT '' NOT NULL,
  "duration_years" integer DEFAULT 2 NOT NULL,
  "total_semesters" integer DEFAULT 4 NOT NULL,
  "institution" text DEFAULT '' NOT NULL,
  "department" text DEFAULT '' NOT NULL,
  "description" text DEFAULT '' NOT NULL,
  "sort_order" integer DEFAULT 0 NOT NULL,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  CONSTRAINT "programs_slug_unique" UNIQUE("slug")
);
CREATE TABLE IF NOT EXISTS "semesters" (
  "id" serial PRIMARY KEY NOT NULL,
  "program_id" integer NOT NULL,
  "number" integer NOT NULL,
  "title" text NOT NULL,
  "session" text DEFAULT '' NOT NULL,
  "description" text DEFAULT '' NOT NULL,
  "linked_semester_id" integer,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  CONSTRAINT "semesters_program_number_unique" UNIQUE("program_id","number"),
  CONSTRAINT "semesters_program_id_programs_id_fk" FOREIGN KEY ("program_id") REFERENCES "public"."programs"("id") ON DELETE cascade ON UPDATE no action,
  CONSTRAINT "semesters_linked_semester_id_semesters_id_fk" FOREIGN KEY ("linked_semester_id") REFERENCES "public"."semesters"("id") ON DELETE set null ON UPDATE no action
);
CREATE TABLE IF NOT EXISTS "files" (
  "id" serial PRIMARY KEY NOT NULL,
  "filename" text NOT NULL,
  "mime_type" text NOT NULL,
  "size" integer NOT NULL,
  "data" bytea NOT NULL,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL
);
CREATE TABLE IF NOT EXISTS "subjects" (
  "id" serial PRIMARY KEY NOT NULL,
  "semester_id" integer NOT NULL,
  "code" text NOT NULL,
  "name" text NOT NULL,
  "short_name" text DEFAULT '' NOT NULL,
  "kind" text DEFAULT 'core' NOT NULL,
  "credits" integer DEFAULT 4 NOT NULL,
  "faculty" text DEFAULT '' NOT NULL,
  "description" text DEFAULT '' NOT NULL,
  "sort_order" integer DEFAULT 0 NOT NULL,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  CONSTRAINT "subjects_semester_id_semesters_id_fk" FOREIGN KEY ("semester_id") REFERENCES "public"."semesters"("id") ON DELETE cascade ON UPDATE no action
);
CREATE TABLE IF NOT EXISTS "syllabus_units" (
  "id" serial PRIMARY KEY NOT NULL,
  "subject_id" integer NOT NULL,
  "unit_no" integer NOT NULL,
  "title" text NOT NULL,
  "topics" text DEFAULT '' NOT NULL,
  "hours" integer DEFAULT 0 NOT NULL,
  CONSTRAINT "syllabus_units_subject_id_subjects_id_fk" FOREIGN KEY ("subject_id") REFERENCES "public"."subjects"("id") ON DELETE cascade ON UPDATE no action
);
CREATE TABLE IF NOT EXISTS "resources" (
  "id" serial PRIMARY KEY NOT NULL,
  "semester_id" integer NOT NULL,
  "subject_id" integer,
  "type" text NOT NULL,
  "title" text NOT NULL,
  "description" text DEFAULT '' NOT NULL,
  "source" text DEFAULT 'none' NOT NULL,
  "file_id" integer,
  "external_url" text,
  "unit_no" integer,
  "year" integer,
  "exam_label" text,
  "author" text,
  "publisher" text,
  "edition" text,
  "is_sample" boolean DEFAULT false NOT NULL,
  "is_open_access" boolean DEFAULT false NOT NULL,
  "downloads" integer DEFAULT 0 NOT NULL,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL,
  CONSTRAINT "resources_semester_id_semesters_id_fk" FOREIGN KEY ("semester_id") REFERENCES "public"."semesters"("id") ON DELETE cascade ON UPDATE no action,
  CONSTRAINT "resources_subject_id_subjects_id_fk" FOREIGN KEY ("subject_id") REFERENCES "public"."subjects"("id") ON DELETE cascade ON UPDATE no action,
  CONSTRAINT "resources_file_id_files_id_fk" FOREIGN KEY ("file_id") REFERENCES "public"."files"("id") ON DELETE set null ON UPDATE no action
);
CREATE TABLE IF NOT EXISTS "class_slots" (
  "id" serial PRIMARY KEY NOT NULL,
  "semester_id" integer NOT NULL,
  "day" integer NOT NULL,
  "start_time" text NOT NULL,
  "end_time" text NOT NULL,
  "subject_id" integer,
  "label" text DEFAULT '' NOT NULL,
  "kind" text DEFAULT 'theory' NOT NULL,
  "room" text DEFAULT '' NOT NULL,
  CONSTRAINT "class_slots_semester_id_semesters_id_fk" FOREIGN KEY ("semester_id") REFERENCES "public"."semesters"("id") ON DELETE cascade ON UPDATE no action,
  CONSTRAINT "class_slots_subject_id_subjects_id_fk" FOREIGN KEY ("subject_id") REFERENCES "public"."subjects"("id") ON DELETE set null ON UPDATE no action
);
CREATE TABLE IF NOT EXISTS "exams" (
  "id" serial PRIMARY KEY NOT NULL,
  "semester_id" integer NOT NULL,
  "exam_type" text NOT NULL,
  "subject_id" integer,
  "title" text DEFAULT '' NOT NULL,
  "exam_date" date NOT NULL,
  "start_time" text NOT NULL,
  "end_time" text NOT NULL,
  "venue" text DEFAULT '' NOT NULL,
  CONSTRAINT "exams_semester_id_semesters_id_fk" FOREIGN KEY ("semester_id") REFERENCES "public"."semesters"("id") ON DELETE cascade ON UPDATE no action,
  CONSTRAINT "exams_subject_id_subjects_id_fk" FOREIGN KEY ("subject_id") REFERENCES "public"."subjects"("id") ON DELETE set null ON UPDATE no action
);
CREATE INDEX IF NOT EXISTS "class_slots_semester_idx" ON "class_slots" USING btree ("semester_id");
CREATE INDEX IF NOT EXISTS "exams_semester_idx" ON "exams" USING btree ("semester_id");
CREATE INDEX IF NOT EXISTS "resources_semester_idx" ON "resources" USING btree ("semester_id");
CREATE INDEX IF NOT EXISTS "resources_subject_idx" ON "resources" USING btree ("subject_id");
CREATE INDEX IF NOT EXISTS "resources_type_idx" ON "resources" USING btree ("type");
CREATE INDEX IF NOT EXISTS "subjects_semester_idx" ON "subjects" USING btree ("semester_id");
CREATE INDEX IF NOT EXISTS "syllabus_units_subject_idx" ON "syllabus_units" USING btree ("subject_id");
`;

const globalForBoot = globalThis as typeof globalThis & { __semhubReadyV2?: Promise<void> };

/** Creates/migrates tables and seeds the portal on first run. Memoised per process. */
export function ensureDb(): Promise<void> {
  if (!globalForBoot.__semhubReadyV2) {
    globalForBoot.__semhubReadyV2 = init().catch((err) => {
      globalForBoot.__semhubReadyV2 = undefined;
      throw err;
    });
  }
  return globalForBoot.__semhubReadyV2;
}

async function init() {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query("SELECT pg_advisory_xact_lock(724501)");
    await client.query(LEGACY_MIGRATION);
    await client.query(DDL);
    const { rows } = await client.query<{ n: number }>("SELECT count(*)::int AS n FROM programs");
    if ((rows[0]?.n ?? 0) === 0) await seed(drizzle(client));
    await client.query("COMMIT");
  } catch (err) {
    await client.query("ROLLBACK").catch(() => undefined);
    throw err;
  } finally {
    client.release();
  }
}

type NewResource = typeof resources.$inferInsert;
type NewSlot = typeof classSlots.$inferInsert;
type NewExam = typeof exams.$inferInsert;
type Ctx = { today: string; Y: number; M: number; ay: string };

const PERIODS: Array<[string, string]> = [
  ["09:30", "10:30"],
  ["10:30", "11:30"],
  ["11:45", "12:45"],
  ["13:30", "14:30"],
  ["14:30", "15:30"],
];

/** Dates starting at `start`, `gap` days apart, never on a Sunday. */
function scheduleDates(start: string, count: number, gap: number) {
  const out: string[] = [];
  let d = start;
  while (out.length < count) {
    while (weekdayISO(d) === 0) d = addDaysISO(d, 1);
    out.push(d);
    d = addDaysISO(d, gap);
  }
  return out;
}

const sessionLabel = (n: number, ay: string) => `${n % 2 === 1 ? "Odd" : "Even"} semester | AY ${ay}`;

async function seed(tx: NodePgDatabase) {
  const today = todayISO();
  const [Y, M] = today.split("-").map(Number);
  const ayStart = M >= 6 ? Y : Y - 1;
  const ctx: Ctx = { today, Y, M, ay: `${ayStart}-${String((ayStart + 1) % 100).padStart(2, "0")}` };
  const semIds = new Map<string, number>();
  const links: Array<{ programId: number; sem: SeedLinkedSemester }> = [];

  for (const [index, prog] of SEED_PROGRAMS.entries()) {
    const [p] = await tx
      .insert(programs)
      .values({
        slug: prog.slug,
        name: prog.name,
        shortName: prog.shortName,
        durationYears: prog.durationYears,
        totalSemesters: prog.totalSemesters,
        institution: prog.institution,
        department: prog.department,
        description: prog.description,
        sortOrder: index + 1,
      })
      .returning({ id: programs.id });
    for (const sem of prog.semesters) {
      if (isLinkedSeed(sem)) {
        links.push({ programId: p.id, sem });
        continue;
      }
      semIds.set(`${prog.slug}:${sem.number}`, await seedSemester(tx, p.id, prog, sem, ctx));
    }
  }

  for (const { programId, sem } of links) {
    await tx.insert(semesters).values({
      programId,
      number: sem.number,
      title: sem.title,
      session: sessionLabel(sem.number, ctx.ay),
      description: sem.description,
      linkedSemesterId: semIds.get(`${sem.linkTo.program}:${sem.linkTo.number}`) ?? null,
    });
  }
}

async function seedSemester(tx: NodePgDatabase, programId: number, prog: SeedProgram, sem: SeedOwnSemester, ctx: Ctx) {
  const odd = sem.number % 2 === 1;
  const [semRow] = await tx
    .insert(semesters)
    .values({ programId, number: sem.number, title: sem.title, session: sessionLabel(sem.number, ctx.ay), description: sem.description })
    .returning({ id: semesters.id });
  const semesterId = semRow.id;
  const room = `${prog.roomPrefix}-${sem.number}`;
  const labRoom = "Computer Lab";
  const latestExamYear = odd ? (ctx.M === 12 ? ctx.Y : ctx.Y - 1) : ctx.M >= 6 ? ctx.Y : ctx.Y - 1;
  const examMonth = odd ? "Nov/Dec" : "Apr/May";
  const label = `${prog.name} Semester ${sem.number}`;

  const res: NewResource[] = [
    {
      semesterId,
      type: "syllabus",
      title: `${label} - Complete Syllabus (all papers)`,
      description: "Every paper of the semester with module-wise topics and textbooks, in one PDF.",
      source: "generated",
    },
    {
      semesterId,
      type: "timetable",
      title: `${label} - Class & Exam Timetable`,
      description: "Weekly class schedule plus internal tests, practicals and end-semester exam dates.",
      source: "generated",
    },
  ];
  const created: Array<{ id: number; kind: string; short: string; group?: string }> = [];

  for (const [index, sub] of sem.subjects.entries()) {
    const [row] = await tx
      .insert(subjects)
      .values({
        semesterId,
        code: sub.code,
        name: sub.name,
        shortName: sub.short,
        kind: sub.kind,
        credits: sub.credits,
        faculty: "",
        description: sub.description,
        sortOrder: index + 1,
      })
      .returning({ id: subjects.id });
    const subjectId = row.id;
    created.push({ id: subjectId, kind: sub.kind, short: sub.short, group: sub.group });

    await tx.insert(syllabusUnits).values(
      sub.units.map((unit, k) => ({ subjectId, unitNo: k + 1, title: unit.title, hours: unit.hours, topics: unit.topics.join("\n") })),
    );

    const isLab = sub.kind === "lab";
    const isProject = sub.kind === "project";
    res.push({
      semesterId,
      subjectId,
      type: "syllabus",
      title: `${sub.code} ${sub.name} - Syllabus`,
      description: `Module-wise syllabus (${sub.units.length} ${isLab ? "parts" : sub.units.length === 1 ? "module" : "modules"}) with prescribed textbooks.`,
      source: "generated",
    });

    if (!isProject) {
      sub.units.forEach((unit, k) =>
        res.push({
          semesterId,
          subjectId,
          type: "notes",
          unitNo: k + 1,
          title: isLab ? `${unit.title} - Lab Record Index` : `Module ${toRoman(k + 1)}: ${unit.title}`,
          description: isLab ? "List of experiments with record-writing format." : "Revision guide: topic checklist, key points and important questions.",
          source: "generated",
          isSample: true,
        }),
      );
      for (let y = 0; y < 3; y++) {
        const year = latestExamYear - y;
        res.push({
          semesterId,
          subjectId,
          type: "pyq",
          year,
          examLabel: isLab ? `Practical Exam (${examMonth})` : `End Semester (${examMonth})`,
          title: `${sub.name} - ${isLab ? "Practical Exam" : "End Semester"} ${examMonth} ${year}`,
          description: isLab ? "Practical examination question set (50 marks)." : "End-semester question paper (3 hours, 50 marks).",
          source: "generated",
          isSample: true,
        });
      }
    }

    if (!isLab && !isProject) {
      for (let y = 0; y < 2; y++) {
        const year = latestExamYear - y;
        for (const t of [1, 2] as const) {
          const [from, to] = internalUnitRange(sub.units.length, t);
          res.push({
            semesterId,
            subjectId,
            type: "internal",
            year,
            examLabel: `Internal Test ${toRoman(t)}`,
            title: `${sub.code} Internal Test ${toRoman(t)} - ${year}`,
            description: `Covers Modules ${toRoman(from)} to ${toRoman(to)} (25 marks).`,
            source: "generated",
            isSample: true,
          });
        }
      }
    }

    sub.books.forEach((book, k) =>
      res.push({
        semesterId,
        subjectId,
        type: "textbook",
        title: book.title,
        author: book.author,
        publisher: book.publisher,
        edition: book.edition ?? null,
        description: k === 0 ? "Prescribed textbook" : "Reference book",
        source: "none",
      }),
    );
    sub.open?.forEach((book) =>
      res.push({
        semesterId,
        subjectId,
        type: "textbook",
        title: book.title,
        author: book.author,
        publisher: "Open access",
        externalUrl: book.url,
        description: "Free and legally available open-access book.",
        source: "link",
        isOpenAccess: true,
      }),
    );
  }

  await tx.insert(resources).values(res);

  // ---- Groups: electives of the same slot share timetable slots and exam dates ----
  const theory = created.filter((c) => c.kind !== "lab" && c.kind !== "project");
  const labs = created.filter((c) => c.kind === "lab");
  const project = created.find((c) => c.kind === "project");
  const units: Array<typeof created> = [];
  const groups = new Map<string, typeof created>();
  for (const c of theory) {
    if (c.kind === "elective" && c.group) {
      const g = groups.get(c.group);
      if (g) g.push(c);
      else {
        const fresh = [c];
        groups.set(c.group, fresh);
        units.push(fresh);
      }
    } else units.push([c]);
  }

  // ---- Weekly class timetable ----
  const pool = units.map((g) =>
    g.length === 1
      ? { subjectId: g[0].id as number | null, label: "" }
      : { subjectId: null, label: `${g[0].group}: ${g.map((x) => x.short).join(" / ")}` },
  );
  const labDays = odd ? [2, 4] : [3, 5];
  let rr = sem.number;
  const next = () => pool[rr++ % pool.length];
  const slots: NewSlot[] = [];
  const theorySlot = (day: number, p: number, kind = "theory") => {
    if (!pool.length) return;
    slots.push({ semesterId, day, startTime: PERIODS[p][0], endTime: PERIODS[p][1], ...next(), kind, room });
  };
  for (let day = 1; day <= 5; day++) {
    // Start each day at a different point of the rotation (7 is coprime with pool sizes 2-6),
    // otherwise a 5-paper semester with 5 periods a day repeats the same order every day.
    rr = sem.number + day * 7;
    for (let p = 0; p < 3; p++) theorySlot(day, p);
    const labIdx = labDays.indexOf(day);
    if (labs.length && labIdx >= 0) {
      slots.push({ semesterId, day, startTime: "13:30", endTime: "15:30", subjectId: labs[labIdx % labs.length].id, kind: "lab", room: labRoom });
    } else {
      theorySlot(day, 3);
      if (project) slots.push({ semesterId, day, startTime: PERIODS[4][0], endTime: PERIODS[4][1], subjectId: project.id, kind: "activity", room: "Seminar Hall" });
      else theorySlot(day, 4, "tutorial");
    }
  }
  rr = sem.number + 6 * 7;
  theorySlot(6, 0);
  theorySlot(6, 1);
  slots.push({ semesterId, day: 6, startTime: PERIODS[2][0], endTime: PERIODS[2][1], subjectId: null, label: "Library / Mentoring", kind: "activity", room: "Library" });
  if (slots.length) await tx.insert(classSlots).values(slots);

  // ---- Exam timetable: relative to today for semesters in session, last term otherwise ----
  const shift = semesterInSession(sem.number, ctx.today) ? 0 : -165;
  const base = (d: number) => addDaysISO(ctx.today, d + shift);
  const morning = prog.roomPrefix === "PG";
  const examRows: NewExam[] = [];
  const addUnitExams = (examType: string, dates: string[], start: string, end: string, venue: string) =>
    dates.forEach((examDate, i) =>
      units[i].forEach((c) => examRows.push({ semesterId, examType, subjectId: c.id, examDate, startTime: start, endTime: end, venue })),
    );
  addUnitExams("internal1", scheduleDates(base(-32), units.length, 1), "10:00", "11:30", room);
  addUnitExams("internal2", scheduleDates(base(6), units.length, 1), "10:00", "11:30", room);
  scheduleDates(base(24), labs.length, 1).forEach((examDate, i) =>
    examRows.push({ semesterId, examType: "practical", subjectId: labs[i].id, examDate, startTime: "09:30", endTime: "12:30", venue: labRoom }),
  );
  const eseDates = scheduleDates(base(30), units.length, 2);
  addUnitExams("semester", eseDates, morning ? "09:30" : "13:30", morning ? "12:30" : "16:30", morning ? "Exam Hall A" : "Exam Hall B");
  if (project) {
    const after = eseDates.length ? addDaysISO(eseDates[eseDates.length - 1], 3) : base(40);
    const [examDate] = scheduleDates(after, 1, 1);
    examRows.push({ semesterId, examType: "viva", subjectId: project.id, examDate, startTime: "10:00", endTime: "13:00", venue: "Seminar Hall" });
  }
  if (examRows.length) await tx.insert(exams).values(examRows);

  return semesterId;
}
