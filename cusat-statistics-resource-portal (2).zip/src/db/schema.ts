import {
  type AnyPgColumn,
  boolean,
  customType,
  date,
  index,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  unique,
} from "drizzle-orm/pg-core";

/** Binary column for uploaded PDFs / documents (stored directly in Postgres). */
const bytea = customType<{ data: Buffer; driverData: Buffer }>({
  dataType() {
    return "bytea";
  },
});

/** A degree programme, e.g. M.Sc. Statistics or Five-Year Integrated M.Sc. Statistics. */
export const programs = pgTable("programs", {
  id: serial("id").primaryKey(),
  slug: text("slug").notNull().unique(),
  name: text("name").notNull(),
  shortName: text("short_name").notNull().default(""),
  durationYears: integer("duration_years").notNull().default(2),
  totalSemesters: integer("total_semesters").notNull().default(4),
  institution: text("institution").notNull().default(""),
  department: text("department").notNull().default(""),
  description: text("description").notNull().default(""),
  sortOrder: integer("sort_order").notNull().default(0),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/**
 * A semester of a programme. When `linkedSemesterId` is set, the semester has no
 * content of its own and shares everything (papers, files, timetable, exams) with
 * the linked semester - e.g. Integrated M.Sc. Semester 7 = M.Sc. Semester 1.
 */
export const semesters = pgTable(
  "semesters",
  {
    id: serial("id").primaryKey(),
    programId: integer("program_id")
      .notNull()
      .references(() => programs.id, { onDelete: "cascade" }),
    number: integer("number").notNull(),
    title: text("title").notNull(),
    session: text("session").notNull().default(""),
    description: text("description").notNull().default(""),
    linkedSemesterId: integer("linked_semester_id").references((): AnyPgColumn => semesters.id, { onDelete: "set null" }),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [unique("semesters_program_number_unique").on(t.programId, t.number)],
);

/** A "paper" of a semester (core, elective, practical, project, minor, AEC, SEC ...). */
export const subjects = pgTable(
  "subjects",
  {
    id: serial("id").primaryKey(),
    semesterId: integer("semester_id")
      .notNull()
      .references(() => semesters.id, { onDelete: "cascade" }),
    code: text("code").notNull(),
    name: text("name").notNull(),
    shortName: text("short_name").notNull().default(""),
    kind: text("kind").notNull().default("core"),
    credits: integer("credits").notNull().default(4),
    faculty: text("faculty").notNull().default(""),
    description: text("description").notNull().default(""),
    sortOrder: integer("sort_order").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [index("subjects_semester_idx").on(t.semesterId)],
);

/** Syllabus modules of a paper. */
export const syllabusUnits = pgTable(
  "syllabus_units",
  {
    id: serial("id").primaryKey(),
    subjectId: integer("subject_id")
      .notNull()
      .references(() => subjects.id, { onDelete: "cascade" }),
    unitNo: integer("unit_no").notNull(),
    title: text("title").notNull(),
    /** One topic per line */
    topics: text("topics").notNull().default(""),
    hours: integer("hours").notNull().default(0),
  },
  (t) => [index("syllabus_units_subject_idx").on(t.subjectId)],
);

export const files = pgTable("files", {
  id: serial("id").primaryKey(),
  filename: text("filename").notNull(),
  mimeType: text("mime_type").notNull(),
  size: integer("size").notNull(),
  data: bytea("data").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

/**
 * Every study material: notes, pyq, internal, textbook, syllabus, timetable.
 * source = upload (file in `files`), link (external URL), generated (PDF rendered
 * on the fly from DB data) or none (metadata only, e.g. a recommended textbook).
 */
export const resources = pgTable(
  "resources",
  {
    id: serial("id").primaryKey(),
    semesterId: integer("semester_id")
      .notNull()
      .references(() => semesters.id, { onDelete: "cascade" }),
    subjectId: integer("subject_id").references(() => subjects.id, { onDelete: "cascade" }),
    type: text("type").notNull(),
    title: text("title").notNull(),
    description: text("description").notNull().default(""),
    source: text("source").notNull().default("none"),
    fileId: integer("file_id").references(() => files.id, { onDelete: "set null" }),
    externalUrl: text("external_url"),
    unitNo: integer("unit_no"),
    year: integer("year"),
    examLabel: text("exam_label"),
    author: text("author"),
    publisher: text("publisher"),
    edition: text("edition"),
    isSample: boolean("is_sample").notNull().default(false),
    isOpenAccess: boolean("is_open_access").notNull().default(false),
    downloads: integer("downloads").notNull().default(0),
    createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
  },
  (t) => [
    index("resources_semester_idx").on(t.semesterId),
    index("resources_subject_idx").on(t.subjectId),
    index("resources_type_idx").on(t.type),
  ],
);

/** Weekly class timetable. day: 1 = Monday ... 6 = Saturday. Times are "HH:MM". */
export const classSlots = pgTable(
  "class_slots",
  {
    id: serial("id").primaryKey(),
    semesterId: integer("semester_id")
      .notNull()
      .references(() => semesters.id, { onDelete: "cascade" }),
    day: integer("day").notNull(),
    startTime: text("start_time").notNull(),
    endTime: text("end_time").notNull(),
    subjectId: integer("subject_id").references(() => subjects.id, { onDelete: "set null" }),
    label: text("label").notNull().default(""),
    kind: text("kind").notNull().default("theory"),
    room: text("room").notNull().default(""),
  },
  (t) => [index("class_slots_semester_idx").on(t.semesterId)],
);

/** Exam timetable: internal tests, practicals, viva and end-semester exams. */
export const exams = pgTable(
  "exams",
  {
    id: serial("id").primaryKey(),
    semesterId: integer("semester_id")
      .notNull()
      .references(() => semesters.id, { onDelete: "cascade" }),
    examType: text("exam_type").notNull(),
    subjectId: integer("subject_id").references(() => subjects.id, { onDelete: "set null" }),
    title: text("title").notNull().default(""),
    examDate: date("exam_date", { mode: "string" }).notNull(),
    startTime: text("start_time").notNull(),
    endTime: text("end_time").notNull(),
    venue: text("venue").notNull().default(""),
  },
  (t) => [index("exams_semester_idx").on(t.semesterId)],
);

export type Program = typeof programs.$inferSelect;
export type Semester = typeof semesters.$inferSelect;
export type Subject = typeof subjects.$inferSelect;
export type SyllabusUnit = typeof syllabusUnits.$inferSelect;
export type Resource = typeof resources.$inferSelect;
export type ClassSlot = typeof classSlots.$inferSelect;
export type Exam = typeof exams.$inferSelect;
